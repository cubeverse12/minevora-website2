# MINEVORA MAP PACK 2.0 — Minecraft Java 1.21.4

Pakiet zawiera **prawdziwe mapy z bloków Minecraft** zapisane jako Sponge `.schem` v2, inspirowane wskazanym renderem. Nie są to dokładne modele 1:1 z ilustracji.

## Co znajdziesz w paczce

- **9 map** BedWars, SkyWars, TNT Run, Parkour, Build Battle, Spleef, Duels, Crystal PvP 1v1, Crystal PvP FFA.
- **1 lobby** z dziewięcioma portalami do tych trybów. Nie zawiera sklepów, Discorda, rang ani dodatków.
- Kod `MinevoraLobbyNavigator_2_0` dla Paper 1.21.4 — łączy gracza z nazwanym serwerem Velocity po podejściu do konkretnego portalu.
- `PUNKTY_MAP_I_LOBBY.json` — wszystkie punkty startowe, wymiary, łóżka, skrzynie, checkpointy i portale.
- Podglądy wygenerowane **bezpośrednio z map**, nie z modeli obrazowych.

## Instalacja map na hostingu

1. Zatrzymaj serwer. Utwórz kopię zapasową świata i `plugins`.
2. Ustaw **Java 21**, **Paper 1.21.4** i WorldEdit zgodny z tą wersją.
3. Wgraj pliki z `MAPY/worldedit_schematics/` do `plugins/WorldEdit/schematics/`.
4. Najlepiej utwórz osobny **pusty świat (void)** dla lobby i osobne światy/serwery dla minigier.
5. Wejdź na serwer jako administrator i w wybranym miejscu wklej mapę komendami (zwróć uwagę na miejsce, w którym znajduje się gracz):

   ```text
   //schem load 00_LOBBY_9_TRYBOW
   //paste -a
   ```

   `-a` pomija bloki powietrza; nie używaj tej opcji do czyszczenia istniejącej zabudowy. Schemat jest duży — wklejaj na serwerze testowym.
6. Po wklejeniu ustal dokładne współrzędne **minimalnego rogu schematu**. Podawane w pliku JSON współrzędne są względne wobec tego rogu. Jeśli minimum to `0,80,0`, spawn lobby wypada w `124.5,117,132.5`.
7. Ustaw spawn świata, np. na lobby po `//paste`: ` /tp 124.5 117 132.5`, potem `/mnavi setspawn` (po zainstalowaniu pluginu).

## Jak włączyć 9 portali

1. W folderze `plugin_lobby/MinevoraLobbyNavigator_2_0` uruchom `BUDUJ_WINDOWS.bat` (JDK 21, Maven).
2. Skopiuj wyprodukowany `target/MinevoraLobbyNavigator-2.0.0-beta.jar` do `plugins` na backendzie lobby, następnie uruchom serwer.
3. Ustaw `world: lobby`, `origin.x/y/z` = rzeczywisty **minimalny róg schematu** w świecie Minecraft; jeśli np. wklejasz od `0,80,0`, zostaw wartości domyślne.
4. W `config.yml` sekcja `servers` musi odpowiadać identyfikatorom serwerów z sekcji `[servers]` w `velocity.toml`.
5. W Velocity włącz `bungee-plugin-message-channel = true`; blokuj bezpośrednie połączenia z backendami i poprawnie skonfiguruj forwarding graczy.
6. Portal nie jest natywnym portalem Minecraft — wyzwala przeniesienie po podejściu do niego, gdy **działa plugin + Velocity + odpowiedni serwer**. Kompas otwiera również menu wszystkich trybów.

## Mapy — rozmieszczenie i wgrywanie

Każdą mapę zalecam wgrać do **osobnego świata lub backendu**. Zanim włączysz mecz, ustaw granice (`/mm pos1`, `/mm pos2`), spawny (`/mm setspawn`) i specjalne punkty trybu.

| Tryb | Nazwa mapy | Gracze / starty | Schemat |
|---|---|---:|---|
| BEDWARS | Emerald Isles | 4 | `01_BEDWARS_Emerald_Isles.schem` |
| SKYWARS | Cloudspire | 8 | `02_SKYWARS_Cloudspire.schem` |
| TNTRUN | Double Drop | 8 | `03_TNTRUN_Double_Drop.schem` |
| PARKOUR | Skytrail | 1 | `04_PARKOUR_Skytrail.schem` |
| BUILDBATTLE | Studio | 6 | `05_BUILD_BATTLE_Studio.schem` |
| SPLEEF | Frostfall | 8 | `06_SPLEEF_Frostfall.schem` |
| DUELS | Colosseum | 2 | `07_DUELS_Colosseum.schem` |
| CRYSTAL_1V1 | Obsidian Duel | 2 | `08_CRYSTAL_PVP_Obsidian_Duel.schem` |
| CRYSTAL_FFA | Nether Nexus | 12 | `09_CRYSTAL_PVP_FFA_Nether_Nexus.schem` |

## Konfiguracja MinevoraMinigames 0.3.1

Plugin **nie wykrywa i nie rejestruje aren automatycznie po wklejeniu**. Trzeba założyć je komendami opisanymi w `JAK_USTAWIC_KAZDA_ARENE.md`.

W SkyWars musisz skierować wzrok na skrzynie i użyć `/mm setchest <arena>` dla każdej skrzyni. W BedWars użyj `/mm setbed <arena> <nr>`, patrząc z bliska na łóżko. W Parkour ustaw `/mm setfinish <arena>`.

**Tryby wymagają testu na serwerze**: sprawdź skoki Parkour, ruch i granice aren, ochronę łóżek i chowanie/znikanie bloków TNT Run oraz Spleef, reset mapy po rundzie i wymianę graczy przez Velocity.

## Status techniczny

- Dziesięć `.schem` przeszło niezależną kontrolę danych NBT, palet, wymiarów i punktów startowych.
- Pliki źródłowe Python przeszły `compileall`. Kod Java przeszedł kontrolę składni parserem JDK.
- Nie ma potwierdzonej kompilacji z Paper API ani uruchomienia aren i portali na rzeczywistym serwerze.
- Efekty wolumetryczne, poświaty i woda z renderu zależą od shaderów/resourcepacków i nie są częścią `.schem`.
