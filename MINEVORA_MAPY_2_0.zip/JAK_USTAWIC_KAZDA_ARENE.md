# JAK USTAWIĆ KAŻDĄ ARENĘ (MinevoraMinigames 0.3.1)

Współrzędne przy założeniu, że MINIMUM schematu wklejono na (0,80,0). Jeśli to inny punkt, dodaj przesunięcie.
Nie wklejaj wszystkich aren w jednym świecie w to samo miejsce: każda arena -> osobny świat lub serwer.

Najpierw skonfiguruj plugin i wejdź do właściwego świata. Komendy /mm pos1/pos2/setspawn są wykonywane z pozycji gracza.

## BEDWARS | Emerald Isles
Schemat: `01_BEDWARS_Emerald_Isles.schem`
`/mm create emerald bedwars`
`/tp 0 80 0` → `/mm pos1 emerald`
`/tp 140 144 140` → `/mm pos2 emerald`

`/tp 25.5 109 77.5` → `/mm setspawn emerald 1`
`/tp 115.5 109 63.5` → `/mm setspawn emerald 2`
`/tp 74.5 109 28.5` → `/mm setspawn emerald 3`
`/tp 66.5 109 112.5` → `/mm setspawn emerald 4`
Łóżko 1: blok 21, 108, 70. Podejdź, spójrz na łóżko i wpisz `/mm setbed emerald 1`.
Łóżko 2: blok 119, 108, 70. Podejdź, spójrz na łóżko i wpisz `/mm setbed emerald 2`.
Łóżko 3: blok 70, 108, 21. Podejdź, spójrz na łóżko i wpisz `/mm setbed emerald 3`.
Łóżko 4: blok 70, 108, 119. Podejdź, spójrz na łóżko i wpisz `/mm setbed emerald 4`.
Skrzynia: 28, 108, 65. Spójrz na nią z <=5 bloków i wpisz `/mm setchest emerald` (SkyWars).
Skrzynia: 126, 108, 65. Spójrz na nią z <=5 bloków i wpisz `/mm setchest emerald` (SkyWars).
Skrzynia: 77, 108, 16. Spójrz na nią z <=5 bloków i wpisz `/mm setchest emerald` (SkyWars).
Skrzynia: 77, 108, 114. Spójrz na nią z <=5 bloków i wpisz `/mm setchest emerald` (SkyWars).
`/mm setvoid emerald 89` — próg eliminacji
`/mm save`

## SKYWARS | Cloudspire
Schemat: `02_SKYWARS_Cloudspire.schem`
`/mm create cloudspire skywars`
`/tp 0 80 0` → `/mm pos1 cloudspire`
`/tp 146 164 146` → `/mm pos2 cloudspire`

`/tp 124.5 116 78.5` → `/mm setspawn cloudspire 1`
`/tp 109.5 116 114.5` → `/mm setspawn cloudspire 2`
`/tp 73.5 116 129.5` → `/mm setspawn cloudspire 3`
`/tp 37.5 116 114.5` → `/mm setspawn cloudspire 4`
`/tp 22.5 116 78.5` → `/mm setspawn cloudspire 5`
`/tp 37.5 116 42.5` → `/mm setspawn cloudspire 6`
`/tp 73.5 116 27.5` → `/mm setspawn cloudspire 7`
`/tp 109.5 116 42.5` → `/mm setspawn cloudspire 8`
Skrzynia: 67, 115, 82. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 81, 115, 68. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 73, 115, 84. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 128, 115, 76. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 113, 115, 112. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 77, 115, 127. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 41, 115, 112. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 26, 115, 76. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 41, 115, 40. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 77, 115, 25. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
Skrzynia: 113, 115, 40. Spójrz na nią z <=5 bloków i wpisz `/mm setchest cloudspire` (SkyWars).
`/mm setvoid cloudspire 88` — próg eliminacji
`/mm save`

## TNT RUN | Double Drop
Schemat: `03_TNTRUN_Double_Drop.schem`
`/mm create doubledrop tntrun`
`/tp 0 80 0` → `/mm pos1 doubledrop`
`/tp 90 147 90` → `/mm pos2 doubledrop`

`/tp 64.5 122 45.5` → `/mm setspawn doubledrop 1`
`/tp 58.5 122 58.5` → `/mm setspawn doubledrop 2`
`/tp 45.5 122 64.5` → `/mm setspawn doubledrop 3`
`/tp 32.5 122 58.5` → `/mm setspawn doubledrop 4`
`/tp 26.5 122 45.5` → `/mm setspawn doubledrop 5`
`/tp 32.5 122 32.5` → `/mm setspawn doubledrop 6`
`/tp 45.5 122 26.5` → `/mm setspawn doubledrop 7`
`/tp 58.5 122 32.5` → `/mm setspawn doubledrop 8`
`/mm setvoid doubledrop 90` — próg eliminacji
`/mm save`

## PARKOUR | Skytrail
Schemat: `04_PARKOUR_Skytrail.schem`
`/mm create skytrail parkour`
`/tp 0 80 0` → `/mm pos1 skytrail`
`/tp 154 159 90` → `/mm pos2 skytrail`

`/tp 12.5 115 45.5` → `/mm setspawn skytrail 1`
`/tp 132.5 113 41.5` → `/mm setfinish skytrail`
`/mm setvoid skytrail 87` — próg eliminacji
`/mm save`

## BUILD BATTLE | Studio
Schemat: `05_BUILD_BATTLE_Studio.schem`
`/mm create studio buildbattle`
`/tp 0 80 0` → `/mm pos1 studio`
`/tp 124 139 98` → `/mm pos2 studio`

`/tp 25.5 108 29.5` → `/mm setspawn studio 1`
`/tp 25.5 108 69.5` → `/mm setspawn studio 2`
`/tp 62.5 108 29.5` → `/mm setspawn studio 3`
`/tp 62.5 108 69.5` → `/mm setspawn studio 4`
`/tp 99.5 108 29.5` → `/mm setspawn studio 5`
`/tp 99.5 108 69.5` → `/mm setspawn studio 6`
`/mm save`

## SPLEEF | Frostfall
Schemat: `06_SPLEEF_Frostfall.schem`
`/mm create frostfall spleef`
`/tp 0 80 0` → `/mm pos1 frostfall`
`/tp 90 146 90` → `/mm pos2 frostfall`

`/tp 61.5 121 45.5` → `/mm setspawn frostfall 1`
`/tp 56.5 121 56.5` → `/mm setspawn frostfall 2`
`/tp 45.5 121 61.5` → `/mm setspawn frostfall 3`
`/tp 34.5 121 56.5` → `/mm setspawn frostfall 4`
`/tp 29.5 121 45.5` → `/mm setspawn frostfall 5`
`/tp 34.5 121 34.5` → `/mm setspawn frostfall 6`
`/tp 45.5 121 29.5` → `/mm setspawn frostfall 7`
`/tp 56.5 121 34.5` → `/mm setspawn frostfall 8`
`/mm setvoid frostfall 88` — próg eliminacji
`/mm save`

## DUELS | Colosseum
Schemat: `07_DUELS_Colosseum.schem`
`/mm create colosseum duels`
`/tp 0 80 0` → `/mm pos1 colosseum`
`/tp 82 152 82` → `/mm pos2 colosseum`

`/tp 23.5 108 41.5` → `/mm setspawn colosseum 1`
`/tp 59.5 108 41.5` → `/mm setspawn colosseum 2`
`/mm save`

## CRYSTAL PVP 1v1 | Obsidian Duel
Schemat: `08_CRYSTAL_PVP_Obsidian_Duel.schem`
`/mm create obsidian_duel crystal_1v1`
`/tp 0 80 0` → `/mm pos1 obsidian_duel`
`/tp 78 145 78` → `/mm pos2 obsidian_duel`

`/tp 16.5 107 39.5` → `/mm setspawn obsidian_duel 1`
`/tp 62.5 107 39.5` → `/mm setspawn obsidian_duel 2`
`/mm setvoid obsidian_duel 89` — próg eliminacji
`/mm save`

## CRYSTAL PVP FFA | Nether Nexus
Schemat: `09_CRYSTAL_PVP_FFA_Nether_Nexus.schem`
`/mm create nether_nexus crystal_ffa`
`/tp 0 80 0` → `/mm pos1 nether_nexus`
`/tp 114 164 114` → `/mm pos2 nether_nexus`

`/tp 91.5 110 57.5` → `/mm setspawn nether_nexus 1`
`/tp 86.5 110 74.5` → `/mm setspawn nether_nexus 2`
`/tp 74.5 110 86.5` → `/mm setspawn nether_nexus 3`
`/tp 57.5 110 91.5` → `/mm setspawn nether_nexus 4`
`/tp 40.5 110 86.5` → `/mm setspawn nether_nexus 5`
`/tp 28.5 110 74.5` → `/mm setspawn nether_nexus 6`
`/tp 23.5 110 57.5` → `/mm setspawn nether_nexus 7`
`/tp 28.5 110 40.5` → `/mm setspawn nether_nexus 8`
`/tp 40.5 110 28.5` → `/mm setspawn nether_nexus 9`
`/tp 57.5 110 23.5` → `/mm setspawn nether_nexus 10`
`/tp 74.5 110 28.5` → `/mm setspawn nether_nexus 11`
`/tp 86.5 110 40.5` → `/mm setspawn nether_nexus 12`
`/mm setvoid nether_nexus 89` — próg eliminacji
`/mm save`
