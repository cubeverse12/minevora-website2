#!/usr/bin/env python3
"""Deterministyczne mapy proceduralne -> Sponge .schem v2 (Minecraft Java 1.21.4).
Nie wymaga zewnetrznych bibliotek do zapisu; podglady opcjonalnie: numpy, Pillow.
"""
from __future__ import annotations
import gzip, json, math, os, random, struct, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

BASE=Path(__file__).resolve().parent.parent
OUT=BASE/'MAPY/worldedit_schematics'
PREV=BASE/'MAPY/podglady'
OUT.mkdir(parents=True, exist_ok=True); PREV.mkdir(parents=True, exist_ok=True)
VERSION=4189 # Java 1.21.4
RNG=random.Random(412)
COLORS={
'air':(23,29,50),'stone_bricks':(142,145,159),'stone':(118,125,141),'mossy_stone_bricks':(88,111,100),
'polished_blackstone_bricks':(49,47,63),'blackstone':(45,42,53),'deepslate_tiles':(64,69,82),
'polished_deepslate':(86,94,106),'grass_block':(80,168,93),'dirt':(104,80,55),
'oak_planks':(184,139,78),'spruce_planks':(119,79,46),'spruce_log':(101,75,48),
'leaves':(67,142,76),'cherry_leaves':(216,154,180),'end_stone':(213,215,151),
'end_stone_bricks':(185,186,138),'purpur_block':(144,96,164),'purple_concrete':(112,55,152),
'magenta_concrete':(183,55,151),'cyan_concrete':(26,175,176),'light_blue_concrete':(97,174,213),
'white_concrete':(224,225,225),'black_concrete':(30,33,40),'yellow_concrete':(239,193,51),
'red_concrete':(181,57,52),'blue_concrete':(60,91,174),'green_concrete':(75,135,75),
'orange_concrete':(222,133,51),'snow_block':(247,250,253),'packed_ice':(151,203,225),
'blue_ice':(71,138,209),'ice':(154,207,232),'tnt':(201,68,54),'sand':(215,201,153),
'obisidian':(39,30,65),'obsidian':(39,30,65),'crying_obsidian':(58,42,105),
'amethyst_block':(154,118,208),'glowstone':(251,206,108),'sea_lantern':(190,235,225),
'quartz_block':(232,228,223),'quartz_pillar':(222,218,212),'glass':(162,207,217),
'oak_fence':(167,120,76),'barrel':(126,101,63),'chest':(177,118,60),'bed':(199,78,81)
}

def nbt_string(s):
 b=s.encode('utf-8'); return struct.pack('>H',len(b))+b

def nbt_tag(t,k,v):
 name=nbt_string(k)
 if t==3: payload=struct.pack('>i',v)
 elif t==2: payload=struct.pack('>h',v)
 elif t==7: payload=struct.pack('>i',len(v))+v
 elif t==8: payload=nbt_string(v)
 elif t==11: payload=struct.pack('>i',len(v))+b''.join(struct.pack('>i',x) for x in v)
 elif t==10: payload=v+b'\x00'
 elif t==9: payload=bytes([10])+struct.pack('>i',len(v)) +b''.join(o+b'\x00' for o in v)
 else: raise ValueError(t)
 return bytes([t])+name+payload

def varint(value):
 v=int(value); out=bytearray()
 while v>127: out.append((v & 0x7f)|0x80); v >>= 7
 out.append(v); return bytes(out)

class Map:
 def __init__(self,name,title,typ,w,h,l,description):
  self.name,self.title,self.typ,self.w,self.h,self.l=name,title,typ,w,h,l
  self.description=description
  self.pal={'minecraft:air':0}; self.arr=np.zeros((h,l,w),dtype=np.uint8)
  self.spawns=[];self.beds=[];self.chests=[];self.finish=None;self.checkpoints=[];self.void=5
 def val(self,b):
  b='minecraft:'+b if not b.startswith('minecraft:') else b
  if b not in self.pal: self.pal[b]=len(self.pal)
  return self.pal[b]
 def put(self,x,y,z,mat):
  if 0<=x<self.w and 0<=y<self.h and 0<=z<self.l: self.arr[y,z,x]=self.val(mat)
 def box(self,x1,y1,z1,x2,y2,z2,mat):
  x1,x2=sorted((max(0,x1),min(self.w-1,x2)));z1,z2=sorted((max(0,z1),min(self.l-1,z2)))
  y1,y2=sorted((max(0,y1),min(self.h-1,y2)))
  if x1<=x2 and y1<=y2 and z1<=z2: self.arr[y1:y2+1,z1:z2+1,x1:x2+1]=self.val(mat)
 def disc(self,x,z,r,y,mat,ry=None):
  ry=r if ry is None else ry
  for xx in range(max(0,int(x-r-1)),min(self.w,int(x+r+2))):
   for zz in range(max(0,int(z-ry-1)),min(self.l,int(z+ry+2))):
    if ((xx-x)/(r+0.1))**2+((zz-z)/(ry+0.1))**2<=1: self.put(xx,y,zz,mat)
 def island(self,x,z,r,y,top='grass_block',sub='dirt'):
  for thickness,rad,ma in [(4,r-5,'stone'),(3,r-3,sub),(2,r-1,sub),(1,r,top),(0,r,top)]:
   if rad>0: self.disc(x,z,rad,y-thickness,ma)
  self.disc(x,z,r,y-1,sub);self.disc(x,z,r,y,top)
 def border(self,x,z,r,y,mat='stone_bricks'):
  for theta in range(0,360,5):
   rad=math.radians(theta);xx=round(x+r*math.cos(rad));zz=round(z+r*math.sin(rad));self.put(xx,y,zz,mat)
 def tree(self,x,y,z,cherry=False):
  for y1 in range(y,y+5): self.put(x,y1,z,'cherry_log' if cherry else 'spruce_log')
  leaf='cherry_leaves[persistent=true]' if cherry else 'spruce_leaves[persistent=true]'
  for yy,rr in [(y+3,3),(y+4,2),(y+5,2),(y+6,1)]: self.disc(x,z,rr,yy,leaf)
 def lamp(self,x,y,z):
  self.put(x,y,z,'sea_lantern');self.put(x,y-1,z,'polished_blackstone_bricks')
 def save(self):
  palette=b''.join(nbt_tag(3,k,v) for k,v in self.pal.items())
  # varint every block, optimized for indices <128 (which these maps use)
  values=self.arr.ravel(order='C')
  raw=bytes(values) if values.max()<128 else b''.join(varint(i) for i in values)
  payload=b''.join([nbt_tag(3,'Version',2),nbt_tag(3,'DataVersion',VERSION),nbt_tag(2,'Width',self.w),nbt_tag(2,'Height',self.h),nbt_tag(2,'Length',self.l),nbt_tag(11,'Offset',[0,0,0]),nbt_tag(3,'PaletteMax',len(self.pal)),nbt_tag(10,'Palette',palette),nbt_tag(7,'BlockData',raw),nbt_tag(9,'BlockEntities',[]),nbt_tag(9,'Entities',[])])
  file=OUT/(self.name+'.schem')
  with gzip.open(file,'wb',compresslevel=7) as f:f.write(bytes([10])+nbt_string('Schematic')+payload+b'\x00')
  # preview top-down highest non-air, with tile outlines and spawn dots
  reverse={v:k.removeprefix('minecraft:') for k,v in self.pal.items()}
  image=np.zeros((self.l,self.w,3),dtype=np.uint8);image[:]=COLORS['air']
  hits=np.any(self.arr>0,axis=0)
  yi=(self.arr>0)[::-1].argmax(axis=0)
  highest=self.h-1-yi
  zz,xx=np.where(hits)
  for z,x in zip(zz,xx):
   m=reverse[int(self.arr[highest[z,x],z,x])].split('[')[0]
   if m.endswith('_bed'):m='bed'
   elif m.endswith('_leaves'):m='cherry_leaves' if m.startswith('cherry') else 'leaves'
   rgb=COLORS.get(m,(140,130,140))
   shade=1+(int(highest[z,x])-20)*0.009
   image[z,x]=tuple(max(0,min(255,int(c*shade))) for c in rgb)
  im=Image.fromarray(image,'RGB').resize((self.w*5,self.l*5),resample=Image.Resampling.NEAREST)
  dr=ImageDraw.Draw(im)
  for i,(x,y,z) in enumerate(self.spawns,1):
   x=x*5+2;z=z*5+2
   dr.ellipse((x-7,z-7,x+7,z+7),fill='#FFFFFF',outline='#19162D',width=2)
   dr.text((x-3,z-5),str(i),fill='#131329')
  for x,y,z in self.chests:
   dr.rectangle((x*5-2,z*5-2,x*5+5,z*5+5),fill='#FFC756',outline='#202025')
  if self.finish:
   x,y,z=self.finish;dr.rectangle((x*5-5,z*5-5,x*5+9,z*5+9),fill='#4ADE80',outline='#132321',width=2)
  h=55;canvas=Image.new('RGB',(im.width,im.height+h),(15,19,35));canvas.paste(im,(0,h));d=ImageDraw.Draw(canvas)
  d.text((12,8),self.title,fill='#F5F1FF',stroke_width=0)
  d.text((12,27),f'{self.w} x {self.h} x {self.l} | spawns: {len(self.spawns)} | MINEVORA',fill='#BFA7FA')
  canvas.save(PREV/(self.name+'.png'))
  return {'id':self.name,'title':self.title,'type':self.typ,'size':[self.w,self.h,self.l],'blocks':int(np.count_nonzero(self.arr)), 'palette_size':len(self.pal),'spawns':self.spawns,'beds':self.beds,'chests':self.chests,'checkpoints':self.checkpoints,'finish':self.finish,'voidY':self.void,'description':self.description,'file':file.name}

