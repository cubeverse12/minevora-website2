#!/usr/bin/env python3
"""Niezalezny parser NBT dla wykrywania bledow zapisu (Sponge v2)."""
import gzip,struct,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
class Reader:
 def __init__(self,bytes_):self.d=bytes_;self.i=0
 def read(self,n):
  b=self.d[self.i:self.i+n];self.i+=n
  assert len(b)==n
  return b
 def b(self):return self.read(1)[0]
 def short(self):return struct.unpack('>h',self.read(2))[0]
 def int(self):return struct.unpack('>i',self.read(4))[0]
 def string(self):return self.read(struct.unpack('>H',self.read(2))[0]).decode('utf-8')
 def compound(self):
  obj={}
  while True:
   t=self.b()
   if t==0:break
   name=self.string()
   obj[name]=self.payload(t)
  return obj
 def payload(self,t):
  if t==2:return self.short()
  if t==3:return self.int()
  if t==7:return self.read(self.int())
  if t==8:return self.string()
  if t==9:
   sub=self.b();length=self.int();return [self.payload(sub) for _ in range(length)]
  if t==10:return self.compound()
  if t==11:return [self.int() for _ in range(self.int())]
  raise ValueError('unsupported NBT '+str(t))

def decode_varints(bytes_):
 out=[];current=0;shift=0
 for b in bytes_:
  current|=(b & 127)<<shift
  if b&128:shift+=7
  else:out.append(current);current=0;shift=0
 assert shift==0
 return out

