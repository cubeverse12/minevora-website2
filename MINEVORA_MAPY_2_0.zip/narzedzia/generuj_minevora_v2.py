#!/usr/bin/env python3
"""Real 1.21.4 Sponge v2 schematic files. Output derived from generated voxel arrays, not an AI image.
Uses the earlier project's NBT writer and Minecraft-world palette, with more detailed builds.
"""
import math, random, json, copy
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
SRC=Path('/mnt/data/MINEVORA_GUARD_MAPS_BUILD/NARZEDZIA/generuj_mapy.py')
# Ship self-contained reusable block writer with this tool as well: local lib file.
LIB=Path(__file__).with_name('minevora_schem_lib.py')
ns={'__file__':str(LIB)}
exec(compile(LIB.read_text(encoding='utf8'),str(LIB),'exec'),ns)
Map=ns['Map']; OUT=ns['OUT']; PREV=ns['PREV']
ns['COLORS'].update({
 'spruce_fence':(116,85,57),'spruce_stairs':(100,74,53),'dark_oak_planks':(77,57,47),
 'dark_oak_stairs':(77,57,47),'stone_brick_stairs':(141,145,150),'moss_block':(83,128,89),
 'moss_carpet':(94,155,96),'emerald_block':(47,196,134),'diamond_block':(87,206,213),
 'gold_block':(245,208,68),'copper_block':(209,127,81),'orange_wool':(240,153,68),
 'purple_stained_glass':(167,94,220),'magenta_stained_glass':(223,88,205),
 'tinted_glass':(61,53,86),'light_blue_stained_glass':(132,194,229),
 'purple_wool':(137,65,180),'smooth_quartz':(234,231,223),
 'spruce_leaves':(56,112,71),'nether_bricks':(69,37,42),'red_nether_bricks':(136,46,59),
 'polished_blackstone':(54,52,67),'crimson_planks':(116,54,91),'soul_lantern':(116,192,242),
 'shroomlight':(233,143,70),'basalt':(81,78,82),'magma_block':(189,100,46),
 'prismarine_bricks':(88,164,162),'blue_concrete':(63,91,182),
 'lily_pad':(73,127,74),'sea_pickle':(171,224,143),'acacia_planks':(198,117,77),
 'lime_concrete':(133,200,63),'pink_concrete':(236,156,211)
})
random.seed(40421)

# Geometry utils operate on schematic blocks.
def box(m,x1,y1,z1,x2,y2,z2,mat):
 x1,x2=sorted((int(x1),int(x2)));y1,y2=sorted((int(y1),int(y2)));z1,z2=sorted((int(z1),int(z2)))
 x1=max(0,x1);x2=min(m.w-1,x2);y1=max(0,y1);y2=min(m.h-1,y2);z1=max(0,z1);z2=min(m.l-1,z2)
 if x1<=x2 and y1<=y2 and z1<=z2:m.arr[y1:y2+1,z1:z2+1,x1:x2+1]=m.val(mat)
def disc(m,x,z,r,y,mat):
 if y<0 or y>=m.h:return
 x,z=int(round(x)),int(round(z));r=int(r)
 xa,xb=max(0,x-r),min(m.w-1,x+r); za,zb=max(0,z-r),min(m.l-1,z+r)
 if xa>xb or za>zb:return
 xs=np.arange(xa,xb+1)[None,:];zs=np.arange(za,zb+1)[:,None]
 mask=(xs-x)**2+(zs-z)**2<=r*r
 v=m.arr[y,za:zb+1,xa:xb+1];v[mask]=m.val(mat)
def ring(m,x,z,r,y,mat,thick=1):
 for rr in range(r-thick+1,r+1):
  for a in range(0,360,2):m.put(round(x+rr*math.cos(math.radians(a))),y,round(z+rr*math.sin(math.radians(a))),mat)
def island(m,x,z,r,y,grass='grass_block',rock='stone'):
 for dy in range(12,0,-1):
  rr=max(2,int(r-(dy*0.85)));disc(m,x,z,rr,y-dy,'deepslate_tiles' if dy>6 else rock)
 disc(m,x,z,r,y-2,rock);disc(m,x,z,r,y-1,'dirt');disc(m,x,z,r,y,grass)
 ring(m,x,z,r,y,'moss_block')
def column(m,x,z,y0,y1,mat):box(m,x,y0,z,x,y1,z,mat)
def cone(m,x,z,y,r,mat,tip='gold_block'):
 for h in range(r+1):disc(m,x,z,max(0,r-h),y+h,mat)
 m.put(x,y+r+1,z,tip)
def castle_tower(m,x,z,y,r=3,h=13,stone='stone_bricks',roof='purple_concrete'):
 for yy in range(y,y+h):
  ring(m,x,z,r,yy,stone)
 disc(m,x,z,r,y+h-1,stone)
 for j in range(0,360,45):
  xx=round(x+r*math.cos(math.radians(j)));zz=round(z+r*math.sin(math.radians(j)))
  box(m,xx,y+h,zz,xx,y+h+1,zz,stone)
 cone(m,x,z,y+h+1,r,roof)
 for yy in (y+3,y+7):
  m.put(x,y+yy-y,z+r,'light_blue_stained_glass')
def tree(m,x,y,z,cherry=False):
 wood='cherry_log' if cherry else 'spruce_log'
 leaf='cherry_leaves[persistent=true]' if cherry else 'spruce_leaves[persistent=true]'
 column(m,x,z,y,y+6,wood)
 for ky,r in [(y+3,3),(y+4,4),(y+5,3),(y+6,3),(y+7,2),(y+8,1)]: disc(m,x,z,r,ky,leaf)
def arch(m,x,z,y,width=7,height=9,stone='polished_blackstone_bricks',bright='amethyst_block',axis='x'):
 for dx in range(-width//2,width//2+1):
  xx=x+dx if axis=='x' else x;zz=z if axis=='x' else z+dx
  top=y+height-max(0,int(abs(dx)*0.6))
  if abs(dx)>=width//2-1:column(m,xx,zz,y,top,stone)
  elif abs(dx)>=width//2-2:m.put(xx,top,zz,stone)
  else:m.put(xx,top,zz,bright)
 for a in range(0,3):m.put(x,y+height+a,z,bright)
def lantern(m,x,y,z):
 m.put(x,y,z,'sea_lantern');m.put(x,y+1,z,'purple_stained_glass')
def bridge(m,x1,z1,x2,z2,y,width=2,mat='stone_bricks',trim='amethyst_block'):
 dx=x2-x1;dz=z2-z1;length=max(1,math.hypot(dx,dz));nx=-dz/length;nz=dx/length
 for step in range(int(length*2)+1):
  t=step/(length*2);x=x1+t*dx;z=z1+t*dz
  for offset in range(-width-1,width+2):
   xx=round(x+offset*nx);zz=round(z+offset*nz)
   if abs(offset)<=width:m.put(xx,y,zz,trim if offset==0 and step%13<2 else mat)
   else:
    m.put(xx,y,zz,trim);m.put(xx,y+1,zz,'spruce_fence')
    if step%14==0:lantern(m,xx,y+2,zz)
def battlement(m,cx,cz,r,y):
 ring(m,cx,cz,r,y,'stone_bricks',2)
 for a in range(0,360,12):
  xx=round(cx+r*math.cos(math.radians(a)));zz=round(cz+r*math.sin(math.radians(a)))
  box(m,xx,y+1,zz,xx,y+2,zz,'polished_blackstone_bricks')
def hut(m,x,y,z,color='red_concrete'):
 box(m,x-5,y,z-4,x+5,y+4,z+4,'spruce_planks')
 box(m,x-4,y+1,z-3,x+4,y+3,z+3,'air')
 box(m,x-1,y+1,z+4,x+1,y+3,z+4,'air')
 for dx in (-5,5):
  for dz in (-4,4):column(m,x+dx,z+dz,y,y+6,'spruce_log')
 for dy in range(4):box(m,x-7+dy,y+6+dy,z-6+dy,x+7-dy,y+6+dy,z+6-dy,color)
 for dx in (-3,3):m.put(x+dx,y+3,z+4,'glass')

def map_bed():
 m=Map('01_BEDWARS_Emerald_Isles','BEDWARS | Emerald Isles','BEDWARS',141,65,141,'4 rozbudowane wyspy baz, centralny zamek, mosty, lozka i spawny')
 cx=cz=70;y=27
 island(m,cx,cz,25,y,'grass_block');disc(m,cx,cz,16,y,'stone_bricks');ring(m,cx,cz,20,y,'mossy_stone_bricks')
 # central castle: quadrangle with gate from every side
 for ox in (-12,12):
  for oz in (-12,12):castle_tower(m,cx+ox,cz+oz,y+1,3,11,'stone_bricks','purple_concrete')
 for ox in range(-11,12):
  for zdelta in (-12,12):
   if abs(ox)>3:box(m,cx+ox,y+1,cz+zdelta,cx+ox,y+7,cz+zdelta,'stone_bricks')
 for oz in range(-11,12):
  for xdelta in (-12,12):
   if abs(oz)>3:box(m,cx+xdelta,y+1,cz+oz,cx+xdelta,y+7,cz+oz,'stone_bricks')
 # old citadel gate windows and emerald spire
 castle_tower(m,cx,cz,y+1,4,16,'polished_deepslate','green_concrete')
 m.put(cx,y+23,cz,'emerald_block')
 bases=[(21,70,'red_concrete','red_bed','east'),(119,70,'blue_concrete','blue_bed','west'),(70,21,'yellow_concrete','yellow_bed','south'),(70,119,'green_concrete','green_bed','north')]
 for ix,(x,z,col,bed,direc) in enumerate(bases):
  island(m,x,z,17,y,'grass_block');disc(m,x,z,11,y,'oak_planks')
  hut(m,x,y+1,z,col)
  # bed in hut facing correctly, placed on y+1 floor
  bdx,bdz={'east':(1,0),'west':(-1,0),'south':(0,1),'north':(0,-1)}[direc]
  bx,bz=x,z;m.put(bx,y+1,bz,f'{bed}[facing={direc},part=foot,occupied=false]')
  m.put(bx+bdx,y+1,bz+bdz,f'{bed}[facing={direc},part=head,occupied=false]')
  m.beds.append([bx,y+1,bz]);m.spawns.append([x+4 if ix%2==0 else x-4,y+2,z+7 if ix%2==0 else z-7])
  m.put(x+7,y+1,z-5,'chest[facing=north,type=single,waterlogged=false]');m.chests.append([x+7,y+1,z-5])
  tree(m,x-11,y+1,z-9,ix%2==0)
  lantern(m,x+8,y+2,z+9)
  if x<cx:bridge(m,x+15,z,cx-23,cz,y,2,'spruce_planks',col)
  if x>cx:bridge(m,cx+23,cz,x-15,z,y,2,'spruce_planks',col)
  if z<cz:bridge(m,x,z+15,cx,cz-23,y,2,'spruce_planks',col)
  if z>cz:bridge(m,cx,cz+23,x,z-15,y,2,'spruce_planks',col)
 m.void=9
 return m

def map_sky():
 m=Map('02_SKYWARS_Cloudspire','SKYWARS | Cloudspire','SKYWARS',147,85,147,'8 niezaleznych wiszacych wysp, centralna cytadela, wieze i skrzynie')
 c=73;y=34
 island(m,c,c,21,y,'grass_block');disc(m,c,c,14,y,'stone_bricks');ring(m,c,c,20,y,'amethyst_block')
 castle_tower(m,c,c,y+1,5,24,'stone_bricks','purple_concrete')
 for a in (45,135,225,315):
  xx=round(c+15*math.cos(math.radians(a)));zz=round(c+15*math.sin(math.radians(a)))
  castle_tower(m,xx,zz,y+1,3,16,'polished_deepslate','purple_concrete')
 for xx,zz in [(c-6,c+9),(c+8,c-5),(c,c+11)]:
  m.put(xx,y+1,zz,'chest[facing=north,type=single,waterlogged=false]');m.chests.append([xx,y+1,zz])
 for i in range(8):
  a=2*math.pi*i/8;x=round(c+51*math.cos(a));z=round(c+51*math.sin(a))
  island(m,x,z,13,y,'grass_block');disc(m,x,z,6,y,'oak_planks')
  castle_tower(m,x,z-3,y+1,3,13,'stone_bricks','red_concrete' if i%2 else 'blue_concrete')
  if i%2==0:tree(m,x+6,y+1,z+6,cherry=i%4==0)
  chest=[x+4,y+1,z+3];m.put(*chest,'chest[facing=north,type=single,waterlogged=false]');m.chests.append(chest)
  m.spawns.append([x,y+2,z+5]);lantern(m,x-5,y+1,z+5)
  # short broken bridges (must NOT connect islands in SkyWars)
  vx=-math.cos(a);vz=-math.sin(a)
  for t in range(6):
   xx=round(x+(8+t)*vx);zz=round(z+(8+t)*vz)
   for off in (-1,0,1):m.put(xx+int(round(-vz*off)),y,zz+int(round(vx*off)),'spruce_planks' if t<4 else 'air')
 m.void=8
 return m

def map_tnt():
 m=Map('03_TNTRUN_Double_Drop','TNT RUN | Double Drop','TNTRUN',91,68,91,'Dwa wolne poziomy 2x znikajacej podlogi i dekoracyjne koloseum lawy')
 c=45; y=40
 for yy,r in [(40,30),(25,28)]:
  for x in range(c-r,c+r+1):
   for z in range(c-r,c+r+1):
    if (x-c)**2+(z-c)**2 < r*r:
     mat=('yellow_concrete' if (x//3+z//3)%2 else 'orange_concrete') if yy==40 else ('red_concrete' if (x//3+z//3)%2 else 'magenta_concrete')
     m.put(x,yy,z,mat)
  # outer fence is out of reachable playing surface
  ring(m,c,c,r+2,yy,'polished_blackstone_bricks',2)
  for a in range(0,360,15):
   xx=round(c+(r+2)*math.cos(math.radians(a)));zz=round(c+(r+2)*math.sin(math.radians(a)))
   box(m,xx,yy+1,zz,xx,yy+3,zz,'nether_bricks')
 # decorative wall at r 38, not connected to runnable floor
 ring(m,c,c,38,33,'stone_bricks',3)
 for a in range(0,360,30):
  xx=round(c+38*math.cos(math.radians(a)));zz=round(c+38*math.sin(math.radians(a)))
  column(m,xx,zz,34,51,'nether_bricks');m.put(xx,52,zz,'shroomlight')
 for a in range(0,360,45):
  x=round(c+19*math.cos(math.radians(a)));z=round(c+19*math.sin(math.radians(a)))
  m.spawns.append([x,42,z])
 m.void=10
 return m

def map_park():
 m=Map('04_PARKOUR_Skytrail','PARKOUR | Skytrail','PARKOUR',155,80,91,'Trasa 31 etapow nad chmurami, wiszace wieze, checkpointy i portal mety')
 c=45; path=[]
 for i in range(31):
  x=12+i*4;z=c+round(7*math.sin(i*0.40));y=33+int(3*math.sin(i*0.37))
  path.append((x,y,z))
  r=5 if i in (0,30,10,20) else (2 if i%3==0 else 1)
  disc(m,x,z,r,y-2,'polished_deepslate');disc(m,x,z,r,y-1,'purpur_block');disc(m,x,z,r,y,'amethyst_block' if i%4==0 else 'stone_bricks')
  if i in (0,10,20,30):
   for k in range(4,13):disc(m,x,z,max(1,5-(k//3)),y-k,'deepslate_tiles')
   castle_tower(m,x,z,y+1,3,10,'stone_bricks','purple_concrete') if i in (10,20) else None
  if i in (5,10,15,20,25):
   m.checkpoints.append([x,y+1,z]);m.put(x,y+1,z,'light_weighted_pressure_plate[powered=false]')
  if i%5==0:lantern(m,x,y+1,z-2)
  if i%6==0 and i not in (0,30):
   for xx,zz in [(x+8,z+14),(x-7,z-14)]:
    disc(m,xx,zz,3,y-7,'deepslate_tiles')
 m.spawns=[[path[0][0],path[0][1]+2,path[0][2]]];m.finish=[path[-1][0],path[-1][1]+2,path[-1][2]]
 x,y,z=path[-1];arch(m,x,z,y+1,9,12,'polished_blackstone_bricks','emerald_block')
 m.void=7
 return m

def map_build():
 m=Map('05_BUILD_BATTLE_Studio','BUILD BATTLE | Studio','BUILDBATTLE',125,60,99,'6 kreatywnych dzialek 23x23 z osobnymi miejscami budowy, galeria i kolumnami')
 # central plaza + 3x2 plots (no block obstruction overhead)
 box(m,3,22,3,121,24,95,'stone_bricks')
 for ix,x in enumerate([25,62,99]):
  for iz,z in enumerate([29,69]):
   box(m,x-15,25,z-15,x+15,25,z+15,'polished_deepslate')
   box(m,x-12,26,z-12,x+12,26,z+12,'smooth_quartz')
   for xx in range(x-14,x+15):
    for zz in (z-14,z+14):m.put(xx,26,zz,'purple_concrete')
   for zz in range(z-14,z+15):
    for xx in (x-14,x+14):m.put(xx,26,zz,'purple_concrete')
   for xx in (x-14,x+14):
    for zz in (z-14,z+14):column(m,xx,zz,27,39,'quartz_pillar');lantern(m,xx,40,zz)
   m.spawns.append([x,28,z]);
 for x in range(4,122,8):
  for z in (3,95):column(m,x,z,25,29,'stone_bricks');m.put(x,30,z,'amethyst_block')
 for z in range(4,96,8):
  for x in (3,121):column(m,x,z,25,29,'stone_bricks');m.put(x,30,z,'amethyst_block')
 for x in (8,116):
  for z in (9,89):castle_tower(m,x,z,25,3,16,'stone_bricks','purple_concrete')
 m.void=9
 return m

def map_spleef():
 m=Map('06_SPLEEF_Frostfall','SPLEEF | Frostfall','SPLEEF',91,67,91,'Dwupoziomowa sniezna arena w lodowym amfiteatrze')
 c=45
 for yy,r in [(39,28),(24,25)]:
  disc(m,c,c,r,yy,'snow_block')
  ring(m,c,c,r+2,yy-1,'packed_ice',2)
  for a in range(0,360,15):
   xx=round(c+(r+2)*math.cos(math.radians(a)));zz=round(c+(r+2)*math.sin(math.radians(a)))
   column(m,xx,zz,yy,yy+4,'packed_ice')
 for a in range(0,360,30):
  xx=round(c+37*math.cos(math.radians(a)));zz=round(c+37*math.sin(math.radians(a)))
  column(m,xx,zz,26,51,'blue_ice');cone(m,xx,zz,52,2,'packed_ice','snow_block')
 for a in range(0,360,45):
  xx=round(c+16*math.cos(math.radians(a)));zz=round(c+16*math.sin(math.radians(a)))
  m.spawns.append([xx,41,zz])
 m.void=8
 return m

def map_duels():
 m=Map('07_DUELS_Colosseum','DUELS | Colosseum','DUELS',83,73,83,'Rzymskie kamienne koloseum na 1v1, 3 poziomy trybun, monumentalne luki')
 c=41;y=26
 disc(m,c,c,32,y-3,'stone');disc(m,c,c,31,y-1,'stone_bricks');disc(m,c,c,29,y,'polished_deepslate')
 ring(m,c,c,30,y,'polished_blackstone_bricks',2)
 for r,yy in [(31,27),(33,29),(35,31),(37,33)]:ring(m,c,c,r,yy,'stone_bricks',2)
 for a in range(0,360,18):
  xx=round(c+36*math.cos(math.radians(a)));zz=round(c+36*math.sin(math.radians(a)))
  column(m,xx,zz,27,42,'quartz_pillar')
  m.put(xx,43,zz,'glowstone')
 for a in range(0,360,45):
  xx=round(c+32*math.cos(math.radians(a)));zz=round(c+32*math.sin(math.radians(a)))
  castle_tower(m,xx,zz,31,3,12,'stone_bricks','purple_concrete')
 for x in range(c-6,c+7):m.put(x,y,c,'purple_concrete')
 m.spawns=[[c-18,y+2,c],[c+18,y+2,c]]
 m.void=9
 return m

def map_crystal1():
 m=Map('08_CRYSTAL_PVP_Obsidian_Duel','CRYSTAL PVP 1v1 | Obsidian Duel','CRYSTAL_1V1',79,66,79,'Symetryczna arena pojedynkow z obsydianem i ametytsowymi pyloniami')
 c=39;y=25
 box(m,7,y-4,7,71,y-2,71,'polished_blackstone_bricks')
 box(m,8,y-1,8,70,y,70,'polished_deepslate')
 for x in range(9,71):
  for z in range(9,71):
   if (x//5+z//5)%2==0:m.put(x,y,z,'deepslate_tiles')
 ring(m,c,c,30,y,'amethyst_block')
 for xx in (20,39,58):
  for zz in (20,39,58):
   if (xx,zz)==(39,39):continue
   box(m,xx-1,y+1,zz-1,xx+1,y+1,zz+1,'obsidian')
 for xx,zz in ((10,10),(68,10),(10,68),(68,68)):
  column(m,xx,zz,y+1,y+15,'polished_blackstone_bricks');m.put(xx,y+16,zz,'amethyst_block')
  for off in (-3,3):column(m,xx+off,zz,y+1,y+9,'crying_obsidian')
 m.spawns=[[16,y+2,c],[62,y+2,c]]
 m.void=9
 return m

def map_crystalffa():
 m=Map('09_CRYSTAL_PVP_FFA_Nether_Nexus','CRYSTAL PVP FFA | Nether Nexus','CRYSTAL_FFA',115,85,115,'12 startow FFA, duza otwarta platforma i fioletowe ruiny Endu')
 c=57;y=28
 for dy in range(8,0,-1):disc(m,c,c,max(5,45-dy),y-dy,'deepslate_tiles')
 disc(m,c,c,45,y-1,'blackstone');disc(m,c,c,44,y,'polished_blackstone_bricks')
 for x in range(c-43,c+44):
  for z in range(c-43,c+44):
   if (x-c)**2+(z-c)**2<42**2 and (x//6+z//6)%3==0:m.put(x,y,z,'obsidian')
 for r in (15,30,44):ring(m,c,c,r,y,'crying_obsidian',2)
 for i in range(12):
  a=2*math.pi*i/12;xx=round(c+34*math.cos(a));zz=round(c+34*math.sin(a))
  m.spawns.append([xx,y+2,zz]);box(m,xx-1,y+1,zz-1,xx+1,y+1,zz+1,'obsidian')
 for a in range(0,360,45):
  x=round(c+48*math.cos(math.radians(a)));z=round(c+48*math.sin(math.radians(a)))
  castle_tower(m,x,z,y+1,3,22,'polished_blackstone_bricks','purple_concrete')
  for dx,dz in ((-4,0),(4,0),(0,-4),(0,4)):
   column(m,x+dx,z+dz,y+1,y+10,'crying_obsidian')
 m.void=9
 return m

# 3x5 glyph signage in actual Minecraft block materials.
FONT={
'A':['010','101','111','101','101'],'B':['110','101','110','101','110'],
'C':['011','100','100','100','011'],'D':['110','101','101','101','110'],
'E':['111','100','110','100','111'],'F':['111','100','110','100','100'],
'G':['011','100','101','101','011'],'H':['101','101','111','101','101'],
'I':['111','010','010','010','111'],'J':['111','001','001','101','010'],
'K':['101','101','110','101','101'],'L':['100','100','100','100','111'],
'M':['101','111','111','101','101'],'N':['101','111','111','111','101'],
'O':['010','101','101','101','010'],'P':['110','101','110','100','100'],
'R':['110','101','110','101','101'],'S':['011','100','010','001','110'],
'T':['111','010','010','010','010'],'U':['101','101','101','101','111'],
'V':['101','101','101','101','010'],'W':['101','101','111','111','101'],
'Y':['101','101','010','010','010'],'Z':['111','001','010','100','111'],
'1':['010','110','010','010','111'],'2':['110','001','010','100','111'],
' ':['000']*5,
}
def banner(m,name,x,y,z):
 name=name.upper();w=len(name)*4-1;left=x-w//2
 box(m,left-2,y-2,z,left+w+1,y+7,z+1,'polished_blackstone_bricks')
 for j,ch in enumerate(name):
  for row,code in enumerate(FONT.get(ch,FONT[' '])):
   for col,v in enumerate(code):
    if v=='1':m.put(left+j*4+col,y+5-row,z-1,'amethyst_block')

def map_lobby():
 m=Map('00_LOBBY_9_TRYBOW','MINEVORA | Lobby tylko minigry','LOBBY',249,90,249,'Lobby 9 osobnych portali dla 9 trybow, bez Discord, mods, sklepu i rankingu')
 c=124;y=35
 island(m,c,c,29,y,'polished_blackstone_bricks');ring(m,c,c,25,y,'amethyst_block',2);ring(m,c,c,15,y,'purple_concrete',2)
 disc(m,c,c,9,y,'polished_deepslate')
 for a in range(0,360,30):
  x=round(c+24*math.cos(math.radians(a)));z=round(c+24*math.sin(math.radians(a)))
  column(m,x,z,y+1,y+4,'polished_blackstone_bricks');lantern(m,x,y+5,z)
 # Spawn before centre portal, centre arch purely cosmetic
 arch(m,c,c-17,y+1,15,22,'polished_blackstone_bricks','purple_stained_glass')
 box(m,c-7,y+3,c-17,c+7,y+18,c-17,'purple_stained_glass')
 for xx in (c-8,c+8):column(m,xx,c-17,y+1,y+22,'crying_obsidian')
 banner(m,'MINEVORA',c,y+25,c-13)
 m.spawns=[[c,y+2,c+8]]
 names=[('bedwars','BEDWARS'),('skywars','SKYWARS'),('tntrun','TNT RUN'),('parkour','PARKOUR'),('buildbattle','BUILD'),('spleef','SPLEEF'),('duels','DUELS'),('crystal1v1','CRYSTAL 1'),('crystalffa','CRYSTAL 2')]
 ports={}
 for i,(key,title) in enumerate(names):
  ang=math.radians(-90+i*40);x=round(c+91*math.cos(ang));z=round(c+91*math.sin(ang))
  island(m,x,z,17,y,'polished_blackstone_bricks')
  ring(m,x,z,14,y,'amethyst_block',2);disc(m,x,z,10,y,'deepslate_tiles')
  # radial bridges; 9 walkable paths
  vx=(x-c)/max(1,math.hypot(x-c,z-c));vz=(z-c)/max(1,math.hypot(x-c,z-c))
  bridge(m,round(c+vx*25),round(c+vz*25),round(x-vx*16),round(z-vz*16),y,2,'stone_bricks','purple_concrete')
  # each is a small distinct-themed portal with simple colorful detail
  accent=['red_concrete','blue_concrete','orange_concrete','light_blue_concrete','quartz_block','snow_block','stone_bricks','obsidian','crying_obsidian'][i]
  for d in range(-3,4):
   for h in range(1,10):
    if abs(d)==3 or h==9 or h==1:m.put(x+d,y+h,z-4,'polished_blackstone_bricks')
    else:m.put(x+d,y+h,z-4,'purple_stained_glass' if (d+h)%2 else 'magenta_stained_glass')
  for xx in (x-4,x+4):
   column(m,xx,z-4,y+1,y+11,'crying_obsidian');m.put(xx,y+12,z-4,accent)
  box(m,x-3,y+1,z+3,x+3,y+1,z+5,accent)
  banner(m,title,x,y+15,z-4)
  for dx,dz in [(-12,-6),(12,-6),(-12,7),(12,7)]:
   if i in (0,1,3):tree(m,x+dx,y+1,z+dz,cherry=i==3)
   else:column(m,x+dx,z+dz,y+1,y+3,'polished_blackstone_bricks');lantern(m,x+dx,y+4,z+dz)
  ports[key]=dict(label=title,center=[x,y+1,z],portal=[x,y+2,z-2],velocity_server=key,world_relative=True)
 m.void=5
 return m,ports

builders=[map_bed,map_sky,map_tnt,map_park,map_build,map_spleef,map_duels,map_crystal1,map_crystalffa]
metadata=[]
for f in builders:
 m=f();d=m.save();metadata.append(d)
 print(d['file'],d['blocks'], 'pal',d['palette_size'],flush=True)
lobby,portals=map_lobby();lob=lobby.save();print(lob['file'],lob['blocks'],flush=True)
manifest={'version':'2.0','edition':'Minecraft Java 1.21.4','dataVersion':4189,'format':'Sponge schematic v2','maps':metadata,
          'lobby':lob,'lobbyFloorY':35,'lobbySpawnLocal':[124.5,37,132.5], 'lobbyPortals':portals,
          'warning':'In-game builds inspired by artwork, not pixel-perfect reproductions. Java plugins and portals require hosting setup, arenas config and tests.',
          'relative':'Map coordinates X/Y/Z are relative to the MINIMUM corner of schematic. Convert by adding WorldEdit paste minimum coordinates.'}
(ROOT/'PUNKTY_MAP_I_LOBBY.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
# full grid montage with real top-down raster from voxel data
ims=[Image.open(PREV/(d['id']+'.png')).convert('RGB') for d in metadata]
W,H=620,630
canvas=Image.new('RGB',(3*W+24,3*H+126),'#0c1020');draw=ImageDraw.Draw(canvas)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
fontpath=font
font=ImageFont.truetype(fontpath,39)
font2=ImageFont.truetype(fontpath,20)
draw.text((30,18),'MINEVORA   •   9 MAP Z PLIKOW .SCHEM',fill='#e6ceff',font=font)
draw.text((30,72),'Rzeczywiste rzuty map Minecraft. To nie sa rendery z shaderow.',fill='#ab93db',font=font2)
for i,im in enumerate(ims):
 im.thumbnail((W-22,H-20),Image.Resampling.NEAREST)
 col,row=i%3,i//3;x=col*W+12+(W-im.width)//2; y=120+row*H+10+(H-10-im.height)//2
 canvas.paste(im,(x,y))
canvas.save(ROOT/'PODGLAD_WSZYSTKIE_9_MAP.png',quality=95)
# Single lobby preview supplied from Map.save (top-down voxels)
from shutil import copy2
copy2(PREV/(lob['id']+'.png'),ROOT/'PODGLAD_LOBBY_9_PORTALI.png')
print('FINISHED, files',len(metadata)+1,flush=True)
