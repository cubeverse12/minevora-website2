import gzip,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
external=Path('/mnt/data/MINEVORA_GUARD_MAPS_BUILD/NARZEDZIA/sprawdz_schematy.py')
# Vendor tiny, standalone reader below, no external dependencies.
from minevora_nbt_reader import Reader, decode_varints
manifest=json.loads((ROOT/'PUNKTY_MAP_I_LOBBY.json').read_text())
files=manifest['maps']+[manifest['lobby']]; passed=[]
for e in files:
 path=ROOT/'MAPY/worldedit_schematics'/e['file']
 r=Reader(gzip.decompress(path.read_bytes()))
 assert r.b()==10 and r.string()=='Schematic'
 obj=r.compound();assert r.i==len(r.d)
 w,h,l=e['size'];assert obj['Version']==2 and obj['DataVersion']==4189
 assert [obj['Width'],obj['Height'],obj['Length']]==[w,h,l]
 assert len(obj['Palette'])==obj['PaletteMax']==e['palette_size']
 ints=decode_varints(obj['BlockData']);assert len(ints)==w*h*l
 assert max(ints)<obj['PaletteMax']
 assert sum(v!=0 for v in ints)==e['blocks']
 ids={v:k for k,v in obj['Palette'].items()}
 def block(x,y,z):return ids[ints[x+z*w+y*w*l]]
 for x,y,z in e['spawns']:
  assert 1<x<w-1 and 1<y<h-1 and 1<z<l-1,(e['id'],x,y,z)
  assert block(x,y,z)=='minecraft:air',(e['id'],'Blocked spawn',x,y,z,block(x,y,z))
  assert any(block(x,yy,z)!='minecraft:air' for yy in range(y-1,y-4,-1)),(e['id'],'Floating spawn',x,y,z)
 for x,y,z in e['beds']:assert '_bed[' in block(x,y,z)
 for x,y,z in e['chests']:assert 'chest[' in block(x,y,z)
 if e['finish']:assert block(*e['finish'])=='minecraft:air'
 if e['type'] in ['TNTRUN','SPLEEF']:
  cx,cz=w//2,l//2
  flooring=[y for y in range(5,h-1) if 'concrete' in block(cx,y,cz) or 'snow_block' in block(cx,y,cz)]
  for y in flooring:assert block(cx,y-1,cz)=='minecraft:air',(e['id'],'Solid under floor',y,block(cx,y-1,cz))
 passed.append({'file':e['file'],'status':'PASS','schematic_blocks':e['blocks'],'spawns':len(e['spawns'])})
print(json.dumps(passed,ensure_ascii=False,indent=2))
(ROOT/'WYNIKI_TESTOW_MAP.json').write_text(json.dumps(passed,ensure_ascii=False,indent=2))
