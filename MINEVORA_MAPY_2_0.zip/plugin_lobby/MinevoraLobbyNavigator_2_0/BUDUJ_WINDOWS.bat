@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Wymagane: JDK 21 i Maven 3.9+
mvn clean package
if errorlevel 1 (
 echo BLAD: kompilacja nieudana. Sprawdz JDK21, Maven i dostep do Paper API.
 pause
 exit /b 1
)
echo GOTOWE: target\MinevoraLobbyNavigator-1.0.0-beta.jar
pause
