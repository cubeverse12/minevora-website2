package pl.minevora.lobby;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class MinevoraLobbyNavigator extends JavaPlugin implements Listener {
    private static final String MENU_ALL = "MINEVORA | MINIGRY";
    private static final String MENU_PVP = "MINEVORA | PVP";
    private final Map<UUID, Long> portalCooldown = new HashMap<>();
    private NamespacedKey menuKey;

    private record Game(String name, String key, Material icon, int slot) {}
    private final List<Game> games = List.of(
        new Game("BedWars", "bedwars", Material.RED_BED, 9),
        new Game("SkyWars", "skywars", Material.ELYTRA, 10),
        new Game("TNT Run", "tntrun", Material.TNT, 11),
        new Game("Parkour", "parkour", Material.FEATHER, 12),
        new Game("Build Battle", "buildbattle", Material.BRICKS, 13),
        new Game("Spleef", "spleef", Material.SNOWBALL, 14),
        new Game("Duels", "duels", Material.IRON_SWORD, 15),
        new Game("Crystal PvP 1v1", "crystal1v1", Material.END_CRYSTAL, 16),
        new Game("Crystal PvP FFA", "crystalffa", Material.OBSIDIAN, 17)
    );

    @Override public void onEnable() {
        saveDefaultConfig();
        menuKey = new NamespacedKey(this, "navigator");
        Bukkit.getPluginManager().registerEvents(this, this);
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        getLogger().info("MINEVORA lobby navigator beta enabled; set spawn via /mnavi setspawn");
    }

    private boolean inLobby(Player p) { return p.getWorld().getName().equals(getConfig().getString("world", "lobby")); }
    private boolean inLobby(Location l) { return l.getWorld()!=null && l.getWorld().getName().equals(getConfig().getString("world", "lobby")); }
    private Location savedSpawn() {
        World w = Bukkit.getWorld(getConfig().getString("world", "lobby"));
        if (w == null) return null;
        return new Location(w, getConfig().getDouble("spawn.x", 100.5), getConfig().getDouble("spawn.y",120.0),
                getConfig().getDouble("spawn.z",111.5), (float)getConfig().getDouble("spawn.yaw",180),
                (float)getConfig().getDouble("spawn.pitch",0));
    }
    private ItemStack item(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + name);
        stack.setItemMeta(meta);
        return stack;
    }
    private void giveCompass(Player p) {
        ItemStack stack = item(Material.COMPASS, "MINEVORA | Wybierz gre");
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(menuKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
        p.getInventory().setItem(0, stack);
    }
    private boolean isCompass(ItemStack s) {
        if (s==null || s.getType()!=Material.COMPASS || !s.hasItemMeta()) return false;
        return s.getItemMeta().getPersistentDataContainer().has(menuKey, PersistentDataType.BYTE);
    }
    private void menu(Player p, boolean pvp) {
        Inventory inventory = Bukkit.createInventory(null, 27, pvp ? MENU_PVP : MENU_ALL);
        for (Game game : games) {
            if (!pvp || game.key().equals("duels") || game.key().startsWith("crystal")) {
                inventory.setItem(game.slot(), item(game.icon(), game.name()));
            }
        }
        p.openInventory(inventory);
    }
    private void sendToServer(Player p, Game g) {
        String server = getConfig().getString("servers." + g.key(), "").trim();
        if (server.isEmpty()) {
            p.sendMessage(ChatColor.RED + "Ten tryb nie jest jeszcze podlaczony do Velocity.");
            return;
        }
        try (ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeUTF("Connect"); out.writeUTF(server);
            p.sendPluginMessage(this, "BungeeCord", bytes.toByteArray());
            p.sendMessage(ChatColor.LIGHT_PURPLE + "Laczenie z " + g.name() + " ...");
        } catch(IOException ex) {
            getLogger().warning("Cannot forward " + p.getName() + ": " + ex.getMessage());
            p.sendMessage(ChatColor.RED + "Nie udalo sie wyslac zapytania do proxy.");
        }
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("hub")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Tylko gracz."); return true; }
            Location spawn = savedSpawn();
            if (spawn == null) { p.sendMessage(ChatColor.RED+"Nie znaleziono swiata lobby."); return true; }
            p.teleport(spawn); return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage("Polecenie dla gracza."); return true; }
        if (args.length>0 && (args[0].equalsIgnoreCase("setspawn") || args[0].equalsIgnoreCase("reload"))) {
            if (!p.hasPermission("minevora.lobby.admin")) {p.sendMessage(ChatColor.RED+"Brak uprawnien."); return true;}
            if (args[0].equalsIgnoreCase("reload")) {reloadConfig();p.sendMessage("Konfiguracja przeladowana.");return true;}
            Location l=p.getLocation();
            getConfig().set("world",l.getWorld().getName());
            getConfig().set("spawn.x",l.getX());getConfig().set("spawn.y",l.getY());getConfig().set("spawn.z",l.getZ());
            getConfig().set("spawn.yaw",l.getYaw());getConfig().set("spawn.pitch",l.getPitch());
            getConfig().set("teleport-on-join",true);
            saveConfig();p.sendMessage(ChatColor.GREEN+"Ustawiono lobby spawn.");return true;
        }
        menu(p,args.length>0 && args[0].equalsIgnoreCase("pvp"));return true;
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p=e.getPlayer();
        if (getConfig().getBoolean("teleport-on-join",false)) {
            Location spawn=savedSpawn();
            if (spawn!=null) Bukkit.getScheduler().runTask(this, ()->{ if (p.isOnline()) p.teleport(spawn); });
        }
        if (getConfig().getBoolean("compass-on-join",true)) {
            Bukkit.getScheduler().runTask(this, ()->{ if(p.isOnline() && inLobby(p))giveCompass(p); });
        }
    }
    @EventHandler public void clickItem(PlayerInteractEvent e) {
        Action a=e.getAction();
        if (a!=Action.RIGHT_CLICK_AIR && a!=Action.RIGHT_CLICK_BLOCK) return;
        if(isCompass(e.getItem())){e.setCancelled(true);menu(e.getPlayer(),false);}
    }
    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        String title=e.getView().getTitle();
        if(!title.equals(MENU_ALL) && !title.equals(MENU_PVP)) return;
        e.setCancelled(true);
        if (e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory())return;
        if(!(e.getWhoClicked() instanceof Player p))return;
        int slot=e.getRawSlot();
        for (Game g:games) if(g.slot()==slot){p.closeInventory();sendToServer(p,g);return;}
    }
    @EventHandler public void onMenuDrag(InventoryDragEvent e) {
        String title=e.getView().getTitle();
        if(title.equals(MENU_ALL) || title.equals(MENU_PVP))e.setCancelled(true);
    }
    private boolean protectedLobby(Location l) {return getConfig().getBoolean("lobby-protection",true)&&inLobby(l);}
    @EventHandler public void onBreak(BlockBreakEvent e) {
        if (protectedLobby(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("minevora.lobby.build"))e.setCancelled(true);
    }
    @EventHandler public void onPlace(BlockPlaceEvent e) {
        if (protectedLobby(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("minevora.lobby.build"))e.setCancelled(true);
    }
    @EventHandler public void onDamage(EntityDamageEvent e) {
        if(getConfig().getBoolean("prevent-damage",true) && e.getEntity() instanceof Player p && inLobby(p))e.setCancelled(true);
    }
    @EventHandler public void onNearPortal(PlayerMoveEvent e) {
        if (!getConfig().getBoolean("proximity-menus",true))return;
        Location to=e.getTo(); if (to==null || !inLobby(to)) return;
        if(e.getFrom().getBlockX()==to.getBlockX() && e.getFrom().getBlockZ()==to.getBlockZ()) return;
        long now=System.currentTimeMillis();Player p=e.getPlayer();
        if (now-portalCooldown.getOrDefault(p.getUniqueId(),0L)<5000)return;
        // Nine dedicated in-world portals. No extra lobby services.
        for (Game game : games) {
            List<Integer> loc = getConfig().getIntegerList("portals." + game.key());
            if (loc.size() != 3) continue;
            double x = loc.get(0) + getConfig().getInt("origin.x", 0) + 0.5;
            double y = loc.get(1) + getConfig().getInt("origin.y", 80);
            double z = loc.get(2) + getConfig().getInt("origin.z", 0) + 0.5;
            if (Math.abs(to.getX() - x) < 3 && Math.abs(to.getY() - y) < 5 && Math.abs(to.getZ() - z) < 3) {
                portalCooldown.put(p.getUniqueId(), now);
                sendToServer(p, game);
                return;
            }
        }
    }
}
