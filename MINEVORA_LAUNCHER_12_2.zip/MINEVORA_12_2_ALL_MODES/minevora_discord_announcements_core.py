"""Discord announcement sender for MINEVORA. Never persist webhook secrets."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

HISTORY_PATH = Path.home() / '.minevora' / 'discord_announcements_history.json'
WEBHOOK_RE = re.compile(r'/api/webhooks/([0-9]{15,22})/([A-Za-z0-9_-]{25,})/?')


def normalize_webhook(text):
    """Only allow official Discord webhook endpoints, without query/fragment/redirects."""
    value = str(text or '').strip()
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or (parsed.hostname or '').lower() != 'discord.com' or
            parsed.username or parsed.password or parsed.port or parsed.query or parsed.fragment or
            not WEBHOOK_RE.fullmatch(parsed.path)):
        raise ValueError('Wklej adres HTTPS webhooka z Discord: Ustawienia serwera → Integracje → Webhooki. Link zaproszenia discord.gg nie jest webhookiem.')
    return 'https://discord.com' + parsed.path.rstrip('/')


def validate_download_url(url):
    url = str(url or '').strip()
    if not url:
        return ''
    parsed = urlsplit(url)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or
            any(c.isspace() for c in url) or len(url) > 600):
        raise ValueError('Link do pobrania musi być poprawnym adresem HTTPS.')
    # Prevent accidentally passing local/sensitive URLs as a public link.
    host = parsed.hostname.lower()
    if host in ('localhost', '127.0.0.1', '::1') or host.endswith('.local'):
        raise ValueError('Link do pobrania musi być publiczny, nie lokalny.')
    return url


def build_announcement(version, title, changes, download_url='', category='Aktualizacja'):
    ver = str(version or '').strip()
    name = str(title or '').strip()
    notes = str(changes or '').strip()
    if not 1 <= len(ver) <= 40 or any(ch in ver for ch in '\r\n'):
        raise ValueError('Wpisz numer wersji (1–40 znaków).')
    if not 3 <= len(name) <= 180:
        raise ValueError('Tytuł musi mieć od 3 do 180 znaków.')
    if not notes or len(notes) > 3600:
        raise ValueError('Opis zmian jest wymagany (maks. 3600 znaków).')
    categories = {'Aktualizacja', 'Poprawka', 'Wydarzenie'}
    if category not in categories:
        raise ValueError('Nieznany typ ogłoszenia.')
    url = validate_download_url(download_url)
    descriptions = {'Aktualizacja':'🚀', 'Poprawka':'🛠️', 'Wydarzenie':'📣'}
    embed = {'title': f"{descriptions[category]} MINEVORA {ver} — {name}",
             'description': notes,
             'color': 0x9072E5,
             'footer': {'text': 'MINEVORA • Oficjalne ogłoszenia'},
             'timestamp': datetime.now(timezone.utc).isoformat()}
    if len(embed['title']) > 256:
        raise ValueError('Tytuł Discord jest za długi.')
    if url:
        embed['url'] = url
        embed['fields'] = [{'name': '🔗 Pobierz / Czytaj więcej', 'value': f'[Otwórz aktualizację]({url})', 'inline': False}]
    return {'username': 'MINEVORA • Aktualizacje', 'allowed_mentions': {'parse': []}, 'embeds': [embed]}


def announcement_fingerprint(payload):
    # Ignore dynamic timestamp so retries and previews identify the same post.
    p = dict(payload['embeds'][0]); p.pop('timestamp', None)
    return hashlib.sha256(json.dumps(p, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def read_history(path=HISTORY_PATH):
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        if isinstance(data, list): return [x for x in data if isinstance(x, dict)][:100]
    except (OSError, ValueError): pass
    return []


def already_posted(payload, path=HISTORY_PATH):
    signature = announcement_fingerprint(payload)
    return any(item.get('sha256') == signature for item in read_history(path))


def record_sent(payload, message_id='', path=HISTORY_PATH):
    embed = payload['embeds'][0]
    data = read_history(path)
    data.insert(0, {'sha256': announcement_fingerprint(payload),
                    'title': embed['title'][:256],
                    'time_utc': datetime.now(timezone.utc).isoformat(),
                    'message_id': str(message_id or '')[:25]})
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(data[:100], ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def post_webhook(webhook, payload, timeout=15, transport=None):
    """Send one post. Never expose/log the webhook token. No automatic retries."""
    endpoint = normalize_webhook(webhook) + '?wait=true'
    data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = Request(endpoint, data=data, headers={'Content-Type':'application/json',
                                                 'User-Agent':'MINEVORA-Announcements/1.0'}, method='POST')
    send = transport or urlopen
    try:
        with send(req, timeout=timeout) as response:
            code = response.getcode()
            if code not in (200, 204):
                raise RuntimeError('Discord odmówił publikacji (HTTP %d).' % code)
            body = response.read(100000)
            if not body:
                return ''
            try:
                message = json.loads(body)
                return str(message.get('id','')) if isinstance(message, dict) else ''
            except (ValueError, UnicodeDecodeError):
                return ''
    except HTTPError as err:
        # Avoid returning webhook URL or the full server response.
        codes = {400:'Niepoprawna treść ogłoszenia.', 401:'Webhook nie ma dostępu.',
                 403:'Brak uprawnień do publikacji.', 404:'Webhook nie istnieje lub został usunięty.',
                 429:'Limit wiadomości Discord. Spróbuj później.'}
        raise RuntimeError('Błąd Discord HTTP %d. %s' % (err.code, codes.get(err.code, 'Sprawdź ustawienia webhooka.'))) from None
    except (URLError, TimeoutError, OSError):
        raise RuntimeError('Nie udało się połączyć z Discordem. Sprawdź internet i spróbuj później.') from None
