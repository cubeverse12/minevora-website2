"""QThread adapter for MINEVORA's automatic required mod dependencies."""
from PySide6.QtCore import QThread, Signal
from minevora_auto_dependencies import install_missing_dependencies


class AutoDependenciesWorker(QThread):
    progress = Signal(str)
    done = Signal(object)
    error = Signal(str)

    def __init__(self, game_dir, mc_version, loader, parent=None):
        super().__init__(parent)
        self.game_dir = game_dir
        self.mc_version = mc_version
        self.loader = loader

    def run(self):
        try:
            self.done.emit(install_missing_dependencies(self.game_dir,
                self.mc_version, self.loader, progress=self.progress.emit))
        except Exception as exc:
            self.error.emit(str(exc))
