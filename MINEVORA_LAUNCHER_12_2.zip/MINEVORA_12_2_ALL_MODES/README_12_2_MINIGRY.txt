MINEVORA Launcher 12.2 — MINIGRY / 9 TRYBOW

Zmieniono opisy i wskazowki w zakladce Minigry.
BedWars, SkyWars, TNT Run, Parkour, Build Battle, Spleef, Duels,
Crystal PvP 1v1 i Crystal PvP FFA.

Wymagany MinevoraMinigames 0.3.0 na serwerze Paper 1.21.4.

WAŻNE: wskazanie minigry w launcherze samo nie wysyla komendy
/mm join do hostingu. Po wejsciu do gry skorzystaj z menu
/minigames lub wpisz komende wypisana pod kafelkami.
Automatyczne polaczenie wymaga osobnego API/tokenow i wdrozenia serwera.
Nie zmieniano logowania Microsoft ani mechaniki uruchamiania gry.
