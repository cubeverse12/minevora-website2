"""MINEVORA 10.9 preflight diagnosis, works without GUI dependencies."""
from pathlib import Path
import argparse
import ast
import importlib.util
import json
import os
import sys

BASE = Path(__file__).resolve().parent
CORE = ['minevora_qt.py','minevora_engine.py','minevora_modrinth.py','minevora_rewards.py',
        'minevora_easy_core.py','minevora_visuals.py','minevora_ai_qt.py','minevora_chat_plus.py',
        'minevora_fairplay.py','minevora_player_profile_core.py','minevora_player_profile_qt.py',
        'minevora_guard_presets.py','minevora_guard_import.py','minevora_profiles.py']
REQUIRED = [('PySide6','PySide6'),('minecraft-launcher-lib','minecraft_launcher_lib')]
OPTIONAL = [('Discord Rich Presence','pypresence'),('Pillow','PIL'),('Requests','requests')]

def diagnose(base=BASE,home=None):
    base = Path(base)
    home = Path(home) if home else Path.home()
    report = []
    errors = 0
    for name in CORE:
        file = base / name
        if not file.is_file():
            report.append(('BRAK',f'Brakuje pliku {name}'))
            errors += 1
        else:
            try:
                ast.parse(file.read_text(encoding='utf-8'),filename=str(file))
                report.append(('OK',f'{name} — składnia prawidłowa'))
            except (SyntaxError,UnicodeError,OSError) as exc:
                errors += 1
                report.append(('BŁĄD',f'{name}: {exc}'))
    for resource in ['minevora_logo.png', 'rank_icons']:
        if not (base/resource).exists():
            report.append(('BRAK',f'Brakuje zasobu {resource}'))
            errors += 1
        else:report.append(('OK',f'Zasób {resource} jest dostępny'))
    for name,module in REQUIRED:
        if importlib.util.find_spec(module) is None:
            errors += 1
            report.append(('BRAK',f'{name} — uruchom INSTALUJ_ZALEZNOSCI.bat'))
        else:report.append(('OK',f'Biblioteka {name} dostępna'))
    for name,module in OPTIONAL:
        present=importlib.util.find_spec(module) is not None
        report.append(('OK' if present else 'OPCJA',f'{name}: {"zainstalowano" if present else "niedostępne"}'))
    # Read structure only — do not output or collect stored auth tokens.
    prefs=home/'.minevora'/'preferences.json'
    if prefs.exists():
        try:
            parsed=json.loads(prefs.read_text(encoding='utf-8'))
            if not isinstance(parsed,dict):raise ValueError('ustawienia nie są słownikiem')
            report.append(('OK','Ustawienia użytkownika: prawidłowy format JSON'))
        except (OSError,ValueError,UnicodeError) as exc:
            report.append(('UWAGA',f'Ustawienia mogą być uszkodzone: {type(exc).__name__}'))
    else: report.append(('OK','Brak ustawień: pierwsze uruchomienie'))
    if os.name!='nt':report.append(('UWAGA','Środowisko nie jest Windows; sprawdź program na Windows 11'))
    report.append(('INFO',f'Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}'))
    if sys.version_info >= (3,15):
        report.append(('UWAGA','Python 3.15: sprawdź kompatybilność bibliotek PySide6 i minecraft-launcher-lib. W razie problemów użyj wspieranej wersji stabilnej Pythona.'))
    return errors,report

def main():
    parser=argparse.ArgumentParser(description='Sprawdź podstawowe pliki MINEVORA bez uruchamiania interfejsu')
    parser.add_argument('--quiet',action='store_true')
    args=parser.parse_args()
    errors,report=diagnose()
    if not args.quiet:
        print('=== MINEVORA 10.9 • DIAGNOSTYKA ===')
        for state,description in report:print(f'[{state}] {description}')
        print(f'\nBłędy uniemożliwiające uruchomienie: {errors}')
        print('Dane logowania i tokeny nie są odczytywane.')
    return 1 if errors else 0

if __name__=='__main__':sys.exit(main())
