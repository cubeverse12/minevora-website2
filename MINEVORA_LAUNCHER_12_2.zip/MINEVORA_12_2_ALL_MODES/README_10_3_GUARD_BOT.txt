MINEVORA 10.3 — GUARD BOT: AUTOMATYCZNA MODERACJA CZATU
=====================================================

CO NOWEGO
- Bot MINEVORA BOT ma wyrozniona karte wiadomosci z oznaczeniem BOT.
- Po wlaczeniu serwera pojawia sie powitalna wiadomosc bota.
- Polecenia gracza na czacie: /zasady, /pomoc, /bot.
- Analiza wysylanych wiadomosci po stronie serwera, zanim zostana opublikowane:
  * flood (zbyt duzo wiadomosci w krotkim oknie czasu),
  * powtarzanie podobnej/tej samej wiadomosci,
  * zbyt duzo linkow i oznaczen @,
  * dlugie teksty pisane WIELKIMI LITERAMI i nadmiar powtorzonych znakow,
  * frazy z listy recznie ustalonej przez moderatora.
- Blokada wiadomosci -> prywatne ostrzezenie -> automatyczne czasowe wyciszenie
  po ustalonej liczbie naruszen (domyslnie 3 ostrzezenia w ciagu 60 min, wyciszenie 10 min).
- Bot NIE naklada permanentnych banow. Moderator zawsze moze zdjac wyciszenie.
- Rejestr zdarzen i ustawienia bota w bazie SQLite serwera.
- Ustawienia filtrow i progi dostepne tylko po autoryzacji tokenem moderatora.

JAK URUCHOMIC
1. Rozpakuj cala paczke do nowego folderu. Zachowaj stara jako kopie bezpieczenstwa.
2. Zamknij poprzedni serwer czatu, jezeli jest uruchomiony na porcie 8766.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat, jezeli brakuje bibliotek.
4. Uruchom URUCHOM_SERWER_CZATU.bat i NIE zamykaj konsoli serwera.
5. Uruchom URUCHOM_MINEVORA.bat.
6. W launcherze: Czat -> Moderacja -> token z konsoli serwera.
7. Kliknij 'Guard Bot — ustawienia i dziennik'. Mozesz edytowac progi,
   dodac blokowane frazy (jedna w kazdej linii) i obejrzec historie interwencji.
8. Wyslij na czat /zasady, aby zobaczyc automatyczna odpowiedz bota.

MIGRACJA
- Uzywana jest ta sama baza minevora_chat.sqlite3 obok serwera.
- Istniejace wiadomosci, zgloszenia i blokady zostaja zachowane.
- Dla przeniesienia na nowy komputer zamknij serwer, skopiuj baze,
  ewentualnie z plikami -wal / -shm po poprawnym zamknieciu.

OGRANICZENIA
- Bot stosuje jasne heurystyki, nie rozumie kontekstu jak czlowiek.
- Nie wykrywa automatycznie wszystkich form obrazania ani nękania.
- Frazy blokowane sa domyslnie puste — ustaw je samodzielnie.
- Nick w lokalnym czacie nie jest zweryfikowany kontem Minecraft.
  Uzytkownik moze zmienic nick i ominac mute; to prototyp, nie produkcyjny system ochrony.
- Czat dziala tylko lokalnie na 127.0.0.1. Dla czatu publicznego potrzebne sa
  HTTPS, uwierzytelnianie kont, kontrola uprawnien, limity i testy penetracyjne.
- Nie zapisuj tokenu moderatora w kodzie udostepnianym innym osobom.
- Zdarzenia bota sa przechowywane przez maksymalnie 30 dni po kolejnym naruszeniu;
  przechowywany jest tez krotki fragment odrzuconej tresci dla moderatora.
- Guard Bot dotyczy czatu MINEVORA, nie wykrywania cheatow w samej grze.
- Nie uruchamiano graficznego interfejsu w Windows w tym srodowisku.

TESTY
python TESTY_CZATU.py
python TESTY_GUARD_BOT.py
python TESTY_BACKUP.py
python -m unittest discover -s tests -v
