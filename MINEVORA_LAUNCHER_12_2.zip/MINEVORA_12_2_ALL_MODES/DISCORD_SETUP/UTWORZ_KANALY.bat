@echo off
cd /d "%~dp0"
py setup_discord.py
if errorlevel 1 (
 echo Sprawdz instalacje Python i biblioteki discord.py.
)
pause
