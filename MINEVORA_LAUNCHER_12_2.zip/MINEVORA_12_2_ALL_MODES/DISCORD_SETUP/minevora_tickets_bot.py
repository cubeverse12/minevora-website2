"""MINEVORA Discord Ticket & Rules Bot.

Usage: python minevora_tickets_bot.py --install (once), then python ... (normal bot).
Requires bot token via MINEVORA_DISCORD_BOT_TOKEN or secure getpass input.
Do not use a personal Discord user token.
"""
import argparse
import asyncio
import getpass
import os

import discord
from minevora_tickets_core import (STAFF_ROLES, TICKET_CATEGORY,
    TICKET_PANEL_CHANNEL, RULES_CHANNEL, RULES,
    ticket_slug,ticket_topic,is_own_open_ticket)


def role_staff(guild):
    return [r for r in guild.roles if r.name in STAFF_ROLES]


def staff(member):
    return member.guild_permissions.manage_channels or any(r.name in STAFF_ROLES for r in member.roles)


def locale_for(guild):
    if discord.utils.get(guild.text_channels,name='open-ticket') or discord.utils.get(guild.text_channels,name='rules'):
        return 'en'
    return 'pl'


class TicketClose(discord.ui.View):
    def __init__(self):super().__init__(timeout=None)

    @discord.ui.button(label='Zamknij ticket / Close',style=discord.ButtonStyle.danger,
                       emoji='🔒',custom_id='minevora:ticket:close:v1')
    async def close(self, interaction:discord.Interaction, button:discord.ui.Button):
        channel=interaction.channel
        if not interaction.guild or not isinstance(channel,discord.TextChannel):
            await interaction.response.send_message('Ta opcja działa tylko w kanale zgłoszenia.',ephemeral=True);return
        topic=channel.topic or ''
        if not topic.startswith('minevora_ticket_owner_id=') or not topic.endswith(';open'):
            await interaction.response.send_message('To nie jest otwarty ticket.',ephemeral=True);return
        try: owner=int(topic.split(';')[0].split('=',1)[1])
        except (ValueError,IndexError):
            await interaction.response.send_message('Błędny identyfikator zgłoszenia.',ephemeral=True);return
        if interaction.user.id!=owner and not staff(interaction.user):
            await interaction.response.send_message('Tylko autor lub moderator może zamknąć zgłoszenie.',ephemeral=True);return
        me=interaction.guild.me
        if not me or not channel.permissions_for(me).manage_channels:
            await interaction.response.send_message('Bot nie ma uprawnień do zamknięcia ticketu.',ephemeral=True);return
        await interaction.response.defer(ephemeral=True)
        try:
            # Explicit channel overwrites take precedence; remove the author's allow.
            # @everyone is denied view_channel in every generated ticket.
            for target in list(channel.overwrites):
                if target.id==owner:
                    await channel.set_permissions(target,overwrite=None,reason='MINEVORA ticket closed')
            await channel.edit(topic=ticket_topic(owner,True),name=('closed-'+channel.name)[:100],reason='MINEVORA ticket closed')
            await channel.send(f'🔒 Zgłoszenie zamknięte przez <@{interaction.user.id}>. Tylko obsługa ma dostęp do archiwum.',allowed_mentions=discord.AllowedMentions.none())
            await interaction.followup.send('Zgłoszenie zamknięte. Obsługa nadal ma dostęp do historii.',ephemeral=True)
            log=discord.utils.get(interaction.guild.text_channels,name='mod-log')
            if log:
                try:await log.send(f'🔒 Ticket #{channel.name} zamknięty. Autor ID: `{owner}`; moderator/użytkownik: `{interaction.user.id}`.',allowed_mentions=discord.AllowedMentions.none())
                except discord.Forbidden: pass
        except discord.Forbidden:
            await interaction.followup.send('Brak uprawnień do zamknięcia zgłoszenia.',ephemeral=True)
        except discord.HTTPException:
            await interaction.followup.send('Błąd Discord API. Spróbuj ponownie.',ephemeral=True)


class TicketPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.locks={}

    @discord.ui.button(label='Otwórz zgłoszenie / Open ticket',style=discord.ButtonStyle.primary,
                       emoji='🎫',custom_id='minevora:ticket:open:v1')
    async def open_ticket(self, interaction:discord.Interaction,button:discord.ui.Button):
        guild=interaction.guild
        if not guild:
            await interaction.response.send_message('Użyj przycisku na serwerze Discord MINEVORA.',ephemeral=True);return
        me=guild.me
        if not me or not me.guild_permissions.manage_channels:
            await interaction.response.send_message('Bot potrzebuje uprawnienia Zarządzanie kanałami.',ephemeral=True);return
        # One open channel per member, protected against double-click races.
        lock=self.locks.setdefault((guild.id,interaction.user.id),asyncio.Lock())
        async with lock:
            category=next((c for c in guild.categories if c.name in TICKET_CATEGORY.values()),None)
            if not category:
                await interaction.response.send_message('Brak kategorii TICKETY. Uruchom instalator bota.',ephemeral=True);return
            for channel in category.text_channels:
                if is_own_open_ticket(channel.topic,interaction.user.id):
                    await interaction.response.send_message(f'Masz już otwarte zgłoszenie: {channel.mention}',ephemeral=True);return
            staff_roles=role_staff(guild)
            if not staff_roles:
                await interaction.response.send_message('Brak ról obsługi. Najpierw uruchom instalator kanałów MINEVORA.',ephemeral=True);return
            overwrites={guild.default_role:discord.PermissionOverwrite(view_channel=False),
                interaction.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True,attach_files=True),
                me:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True,manage_channels=True)}
            for role in staff_roles:
                overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
            await interaction.response.defer(ephemeral=True)
            try:
                channel=await guild.create_text_channel(ticket_slug(interaction.user.name,interaction.user.id),
                    category=category,overwrites=overwrites,topic=ticket_topic(interaction.user.id),reason='MINEVORA: new private support ticket')
                await channel.send(f'🎫 Witaj <@{interaction.user.id}>! Opisz problem z launcherem lub zgłoszenie.\n'
                    'Nie wysyłaj haseł, tokenów, danych osobowych ani prywatnych dokumentów. '
                    'Obsługa MINEVORA będzie mogła przeczytać zgłoszenie.',
                    view=TicketClose(),allowed_mentions=discord.AllowedMentions(users=True,roles=False,everyone=False))
                await interaction.followup.send(f'Utworzono prywatne zgłoszenie: {channel.mention}',ephemeral=True)
            except (discord.Forbidden,discord.HTTPException):
                await interaction.followup.send('Nie udało się utworzyć zgłoszenia. Sprawdź uprawnienia bota.',ephemeral=True)


async def publish_rules(guild,language):
    name=RULES_CHANNEL[language]
    channel=discord.utils.get(guild.text_channels,name=name)
    if not channel:
        channel=await guild.create_text_channel(name,reason='MINEVORA rules')
    me=guild.me
    if not me: raise PermissionError('Bot identity not resolved')
    # Explicit bot permission works even when @everyone is already read-only.
    await channel.set_permissions(me,send_messages=True,view_channel=True,read_message_history=True,reason='MINEVORA rules bot access')
    # Make the rules read-only without disturbing the channel's message history.
    await channel.set_permissions(guild.default_role,send_messages=False,view_channel=True,read_message_history=True,reason='MINEVORA rules read-only')
    for role in role_staff(guild):
        await channel.set_permissions(role,send_messages=True,view_channel=True,read_message_history=True,reason='MINEVORA staff rules access')
    content=RULES[language]
    marker='# 📜'
    async for message in channel.history(limit=30):
        if message.author.id==guild.me.id and message.content.startswith(marker):
            if message.content!=content:await message.edit(content=content,allowed_mentions=discord.AllowedMentions.none())
            return channel
    await channel.send(content,allowed_mentions=discord.AllowedMentions.none())
    return channel


async def setup(guild, language):
    me=guild.me
    if not me or not me.guild_permissions.manage_channels:
        raise PermissionError('Requires Manage Channels')
    if not role_staff(guild):
        raise PermissionError('Roles missing: run Discord channel installer first')
    category=next((c for c in guild.categories if c.name in TICKET_CATEGORY.values()),None)
    if not category:
        category=await guild.create_category(TICKET_CATEGORY[language],overwrites={
            guild.default_role:discord.PermissionOverwrite(view_channel=False),
            me:discord.PermissionOverwrite(view_channel=True)},reason='MINEVORA ticket category')
    panel=next((c for c in guild.text_channels if c.name in TICKET_PANEL_CHANNEL.values()),None)
    if not panel:
        panel=await guild.create_text_channel(TICKET_PANEL_CHANNEL[language],
            overwrites={guild.default_role:discord.PermissionOverwrite(view_channel=True,send_messages=False,read_message_history=True),
                        me:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)},
            reason='MINEVORA ticket panel')
    else:
        # Existing panel: do not delete or alter other overwrites.
        await panel.set_permissions(guild.default_role,view_channel=True,send_messages=False,read_message_history=True,
             reason='MINEVORA ticket panel read-only')
    async for message in panel.history(limit=30):
        if message.author.id==me.id and 'MINEVORA • ZGŁOSZENIA' in message.content:
            break
    else:
        await panel.send('🎫 **MINEVORA • ZGŁOSZENIA**\nKliknij przycisk, aby otworzyć prywatny ticket do obsługi launchera, błędów i odwołań.\n'
            'Ticket zobaczysz tylko Ty oraz uprawniony zespół. Nie udostępniaj haseł ani tokenów.',
            view=TicketPanel(),allowed_mentions=discord.AllowedMentions.none())
    await publish_rules(guild,language)
    return category,panel


class MinevoraTickets(discord.Client):
    def __init__(self,install_mode=False, **kwargs):
        super().__init__(**kwargs);self.install_mode=install_mode;self.started=False
    async def setup_hook(self):
        self.add_view(TicketPanel())
        self.add_view(TicketClose())
    async def on_ready(self):
        if self.started:return
        self.started=True
        print('MINEVORA Discord bot online:',self.user)
        if self.install_mode:
            guilds=list(self.guilds)
            for i,guild in enumerate(guilds,1): print(f'{i}. {guild.name} ({guild.id})')
            try:
                index=int(await asyncio.to_thread(input,'Numer serwera do konfiguracji: '))-1
                if index<0 or index>=len(guilds):raise ValueError
                guild=guilds[index]
                language=locale_for(guild)
                print(f'PLAN: prywatna kategoria ticketów, #otworz-ticket/#open-ticket i regulamin w języku {language}.')
                if (await asyncio.to_thread(input,'Zatwierdź zmiany [tak/NIE]: ')).strip().lower() != 'tak':
                    print('Anulowano.');await self.close();return
                category,panel=await setup(guild,language)
                print('Utworzono/skonfigurowano:',category.name,panel.name,'oraz regulamin.')
            except (ValueError,IndexError,PermissionError,discord.Forbidden,discord.HTTPException,EOFError) as exc:
                print('Instalacja nie powiodła się:',exc);await self.close();return
        print('Bot nasłuchuje kliknięć przycisków. Aby tickety działały stale, pozostaw bota uruchomionego.')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--install',action='store_true')
    args=parser.parse_args()
    token=os.getenv('MINEVORA_DISCORD_BOT_TOKEN','').strip() or getpass.getpass('Discord bot token (tylko w tym oknie): ').strip()
    if not token:raise SystemExit('Brak tokenu')
    intents=discord.Intents.none();intents.guilds=True
    client=MinevoraTickets(install_mode=args.install,intents=intents)
    client.run(token,log_handler=None)

if __name__=='__main__':main()
