@echo off
cd /d "%~dp0"
py -3 setup_discord.py --language-only
pause
