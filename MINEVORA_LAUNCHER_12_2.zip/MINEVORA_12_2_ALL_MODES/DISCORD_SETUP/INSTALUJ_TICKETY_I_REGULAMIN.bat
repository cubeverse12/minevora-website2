@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
py minevora_tickets_bot.py --install
pause
