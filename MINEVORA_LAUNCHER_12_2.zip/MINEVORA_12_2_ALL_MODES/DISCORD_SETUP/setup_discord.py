"""Jednorazowy instalator struktury serwera Discord MINEVORA.

Nie przechowuje tokenu. Nie usuwa kanałów ani ról. Istniejące kanały
pozostają bez zmian (w tym ich uprawnienia).
"""
from __future__ import annotations

import asyncio
import getpass
import os
import sys
from discord_languages import planned_name, TOPICS_EN, SEED_EN
from dataclasses import dataclass

try:
    import discord
except ImportError:
    print('Brak biblioteki discord.py. Uruchom INSTALUJ.bat lub: py -m pip install -r requirements.txt')
    sys.exit(1)


@dataclass(frozen=True)
class Channel:
    name: str
    kind: str = 'text'   # text lub voice
    topic: str | None = None


@dataclass(frozen=True)
class Category:
    name: str
    access: str  # readonly, public, staff, voice
    channels: tuple[Channel, ...]


PLAN = (
    Category('📌 START', 'readonly', (
        Channel('witaj', topic='Witamy na oficjalnym Discordzie MINEVORA!'),
        Channel('regulamin', topic='Zasady i bezpieczeństwo społeczności.'),
        Channel('ogloszenia', topic='Oficjalne ogłoszenia zespołu.'),
        Channel('aktualizacje-minevora', topic='Nowe wersje launchera i changelogi — kanał dla bota ogłoszeń.'),
        Channel('role-info', topic='Opis ról. Nadawanie ról przez uprawniony zespół.'),
        Channel('jak-zglosic', topic='Jak prywatnie zgłosić problem moderatorom.'),
    )),
    Category('💬 SPOŁECZNOŚĆ', 'public', (
        Channel('chat-ogolny', topic='Rozmowy społeczności MINEVORA.'),
        Channel('przedstaw-sie', topic='Przywitaj się z innymi.'),
        Channel('screeny', topic='Zrzuty ekranu i twórczość Minecraft.'),
        Channel('pomoc', topic='Pomoc w obsłudze launchera.'),
        Channel('pomysly', topic='Pomysły na następne funkcje MINEVORA.'),
    )),
    Category('⚔️ PVP I SERWERY', 'public', (
        Channel('pvp-chat', topic='Dyskusje PvP.'),
        Channel('szukam-duelu', topic='Szukasz osoby do pojedynku?'),
        Channel('wyniki-pvp', topic='Wyniki i osiągnięcia — nie są oficjalnym rankingiem.'),
        Channel('serwery-minecraft', topic='Serwery Minecraft społeczności.'),
    )),
    Category('🧱 STREFA TWÓRCÓW', 'public', (
        Channel('mapy-i-budowle', topic='Pochwal się mapą lub budowlą.'),
        Channel('modele-i-rigi', topic='Projekty Blender, Blockbench i rigi Minecraft.'),
        Channel('marketplace', topic='Dyskusje o projektach w Marketplace.'),
        Channel('porady-tworcow', topic='Pomoc techniczna i wskazówki twórców.'),
    )),
    Category('🔊 GŁOSOWE', 'voice', (
        Channel('Ogólny', 'voice'),
        Channel('PvP 1', 'voice'),
        Channel('PvP 2', 'voice'),
    )),
    Category('🛡️ MODERACJA', 'staff', (
        Channel('mod-chat', topic='Prywatny czat moderatorów.'),
        Channel('mod-log', topic='Dziennik decyzji moderatorskich.'),
        Channel('zgloszenia-wewnetrzne', topic='Prywatna obsługa zgłoszeń.'),
        Channel('reklamy-do-weryfikacji', topic='Weryfikacja reklam i zgłoszeń.'),
        Channel('plan-ogloszen', topic='Plan publikacji i wersji MINEVORA.'),
    )),
)

SEED_MESSAGES = {
    'witaj': ('# Witaj na Discordzie MINEVORA! 👋\n'
              'Zacznij od #regulamin, zajrzyj do #ogloszenia i #aktualizacje-minevora. '
              'Pomoc znajdziesz na #pomoc. Miłej zabawy!'),
    'regulamin': ('# Regulamin MINEVORA\n'
                  '1. Szanuj innych użytkowników. Nie obrażaj i nie nękaj.\n'
                  '2. Nie spamuj i nie publikuj oszustw, podejrzanych linków ani szkodliwych plików.\n'
                  '3. Nie udostępniaj cudzych danych prywatnych.\n'
                  '4. Reklamy i oferty publikuj tylko w miejscach wskazanych przez administrację.\n'
                  '5. Problemy zgłaszaj prywatnie moderatorom.\n'
                  '6. Stosuj się do zasad Discorda i decyzji moderatorów.\n'
                  'Od decyzji moderatora możesz się odwołać przez prywatny kontakt z zespołem.'),
    'role-info': ('# Role MINEVORA\n'
                  '🛡 Moderator MINEVORA — moderacja kanałów i czasowe wyciszenia.\n'
                  '🔧 Zespół MINEVORA — organizacja i ogłoszenia.\n'
                  '🎨 Twórca — projekty map, modeli i rigów.\n'
                  '⚔️ Gracz PvP — społeczność PvP.\n'
                  '🤝 Partner — współpraca.\n'
                  'Role nadaje administracja; ten instalator nie uruchamia samodzielnego wybierania ról.'),
    'jak-zglosic': ('# Zgłaszanie problemów\n'
                    'Nie publikuj publicznie danych osobowych, dowodów z prywatnych rozmów ani informacji o kontach. '
                    'Skontaktuj się prywatnie z moderatorem lub skorzystaj z oficjalnej funkcji zgłaszania Discorda. '
                    'Kanał #zgloszenia-wewnetrzne jest widoczny wyłącznie dla zespołu.'),
    'aktualizacje-minevora': ('# Aktualizacje MINEVORA 🚀\n'
                             'Tutaj pojawią się informacje o kolejnych wersjach launchera. '
                             'Do automatycznych ogłoszeń możesz podłączyć webhook z MINEVORA 10.4.'),
}


def roles_spec() -> list[tuple[str, dict]]:
    return [
        ('🔧 Zespół MINEVORA', {'manage_messages': True}),
        ('🛡 Moderator MINEVORA', {'manage_messages': True, 'moderate_members': True}),
        ('🎨 Twórca', {}),
        ('⚔️ Gracz PvP', {}),
        ('🤝 Partner', {}),
    ]


def category_overwrites(guild: discord.Guild, roles: dict[str, discord.Role], access: str):
    everyone = guild.default_role
    team = roles['🔧 Zespół MINEVORA']
    mod = roles['🛡 Moderator MINEVORA']
    if access == 'staff':
        return {
            everyone: discord.PermissionOverwrite(view_channel=False),
            team: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            mod: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        }
    if access == 'readonly':
        return {
            everyone: discord.PermissionOverwrite(view_channel=True, send_messages=False, read_message_history=True),
            team: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            mod: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_messages=True),
        }
    if access == 'voice':
        return {
            everyone: discord.PermissionOverwrite(view_channel=True, connect=True, speak=True),
            mod: discord.PermissionOverwrite(view_channel=True, connect=True, speak=True, move_members=True),
        }
    return {
        everyone: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        team: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_messages=True),
        mod: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_messages=True),
    }


def confirm(text: str) -> bool:
    return input(text).strip().lower() in ('tak', 't', 'yes', 'y')


async def run_setup(guild: discord.Guild, language='pl', translate_only=False):
    me = guild.me
    if not me or not me.guild_permissions.manage_channels or (
        not translate_only and not me.guild_permissions.manage_roles
    ):
        print('BŁĄD: Bot potrzebuje Manage Channels (a do instalacji również Manage Roles).')
        return
    mode = 'Zmiana języka istniejących kanałów' if translate_only else 'Instalacja kanałów'
    print(f'\nSerwer: {guild.name} (ID {guild.id}) | {mode} | Język: {language.upper()}')
    print('Nie usuwamy żadnych kanałów ani ról. Uprawnienia istniejących kanałów pozostają bez zmian.')
    print('Zostaną zmienione nazwy WYŁĄCZNIE elementów rozpoznanych po nazwach PL/EN i kategorii.')
    if not confirm('Czy potwierdzasz zmiany na tym serwerze? [tak/NIE]: '):
        print('Anulowano.')
        return
    roles: dict[str, discord.Role] = {}
    created_roles = created_categories = created_channels = renamed = 0
    if not translate_only:
        for name, perms in roles_spec():
            role = discord.utils.get(guild.roles, name=name)
            if not role:
                permissions = discord.Permissions.none()
                for key, value in perms.items():
                    setattr(permissions, key, value)
                role = await guild.create_role(name=name, permissions=permissions, mentionable=False, hoist=False,
                                               reason='MINEVORA Discord - setup')
                created_roles += 1
            roles[name] = role
    for ci, plan in enumerate(PLAN):
        old_name = planned_name(PLAN, ci, language='pl')
        en_name = planned_name(PLAN, ci, language='en')
        target_name = planned_name(PLAN, ci, language=language)
        # Prefer existing category with desired name and do not rename when both names exist.
        target_category = discord.utils.get(guild.categories, name=target_name)
        other_category = discord.utils.get(guild.categories, name=en_name if language == 'pl' else old_name)
        category = target_category or other_category
        if category:
            if target_category is None and category.name != target_name:
                await category.edit(name=target_name, reason='MINEVORA - zmiana języka')
                renamed += 1
                print(f'  ~ kategoria: {target_name}')
        elif translate_only:
            print(f'  - nie znaleziono kategorii: {target_name}')
            continue
        else:
            category = await guild.create_category(
                target_name, overwrites=category_overwrites(guild, roles, plan.access),
                reason='MINEVORA Discord - setup')
            created_categories += 1
            print(f'  + kategoria: {target_name}')

        for ch_i, item in enumerate(plan.channels):
            pl_name = planned_name(PLAN, ci, ch_i, 'pl')
            en_ch_name = planned_name(PLAN, ci, ch_i, 'en')
            target = planned_name(PLAN, ci, ch_i, language)
            collection = guild.voice_channels if item.kind == 'voice' else guild.text_channels
            existing_target = discord.utils.get(collection, name=target, category=category)
            existing_other = discord.utils.get(collection,
                name=en_ch_name if language == 'pl' else pl_name, category=category)
            existing = existing_target or existing_other
            if existing:
                if existing_target is None and existing.name != target:
                    await existing.edit(name=target, reason='MINEVORA - zmiana języka')
                    renamed += 1
                    print(f'    ~ kanał: {target}')
                continue
            if translate_only:
                continue
            overwrites = category_overwrites(guild, roles, plan.access)
            if item.kind == 'voice':
                channel = await guild.create_voice_channel(target, category=category, overwrites=overwrites,
                                                           reason='MINEVORA Discord - setup')
            else:
                topic = TOPICS_EN[ci][ch_i] if language == 'en' else item.topic
                channel = await guild.create_text_channel(target, category=category, topic=topic,
                                                          overwrites=overwrites, reason='MINEVORA Discord - setup')
            created_channels += 1
            print(f'    + kanał: {target}')
            seed = SEED_EN if language == 'en' else SEED_MESSAGES
            if item.kind == 'text' and target in seed:
                try:
                    await channel.send(seed[target], allowed_mentions=discord.AllowedMentions.none())
                except discord.Forbidden:
                    print('      UWAGA: Bot nie może wysłać wiadomości powitalnej.')
    print(f'\nGOTOWE: role +{created_roles}; kategorie +{created_categories}; kanały +{created_channels}; zmienione nazwy {renamed}')
    print('Sprawdź ręcznie prywatność MODERACJA i uprawnienia już istniejących kanałów.')
    print('Zmiana nazwy nie tłumaczy treści wiadomości ani nie zmienia uprawnień.')


class MinevoraInstaller(discord.Client):
    def __init__(self, language='pl', translate_only=False, **kwargs):
        super().__init__(**kwargs)
        self.language = language
        self.translate_only = translate_only
        self.completed = False

    async def on_ready(self):
        if self.completed:
            return
        self.completed = True
        print(f'Zalogowano jako bot {self.user}.')
        guilds = list(self.guilds)
        if not guilds:
            print('Bot nie jest na żadnym serwerze. Dodaj go do Discord MINEVORA i uruchom instalator ponownie.')
            await self.close()
            return
        for index, guild in enumerate(guilds, start=1):
            print(f'{index}. {guild.name} (ID {guild.id})')
        try:
            selection = input('Wybierz numer WŁAŚCIWEGO serwera Discord: ').strip()
            index = int(selection) - 1
            if not (0 <= index < len(guilds)):
                raise ValueError
            await run_setup(guilds[index], self.language, self.translate_only)
        except (ValueError, KeyboardInterrupt, EOFError):
            print('Anulowano. Nie wybrano poprawnego serwera.')
        except discord.Forbidden as exc:
            print(f'Brak uprawnień bota: {exc}')
        except discord.HTTPException as exc:
            print(f'Błąd Discord API: {exc}')
        finally:
            await self.close()


def main():
    print('=== MINEVORA — instalator kanałów Discord ===')
    print('Token bota wpisz wyłącznie w tym oknie. Nie wysyłaj go nikomu i nie wklejaj na czat.')
    token = os.environ.get('MINEVORA_DISCORD_BOT_TOKEN')
    if not token:
        token = getpass.getpass('Token bota Discord (znaki nie będą widoczne): ').strip()
    if not token:
        print('Brak tokenu.')
        return
    print('Język nazw kanałów: 1 = Polski, 2 = English')
    selected_language = input('Wybierz język [1/2]: ').strip()
    if selected_language not in ('1', '2'):
        print('Anulowano: nie wybrano języka.')
        return
    language = 'en' if selected_language == '2' else 'pl'
    translate_only = '--language-only' in sys.argv
    intents = discord.Intents.none()
    intents.guilds = True
    app = MinevoraInstaller(intents=intents, language=language, translate_only=translate_only)
    try:
        app.run(token, log_handler=None)
    except discord.LoginFailure:
        print('Nieprawidłowy token bota.')
    except KeyboardInterrupt:
        print('Przerwano.')


if __name__ == '__main__':
    main()
