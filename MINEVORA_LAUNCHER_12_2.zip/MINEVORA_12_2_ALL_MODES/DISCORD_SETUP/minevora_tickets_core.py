"""Names, permissions policy and rules shared by the Discord ticket bot."""
import re

STAFF_ROLES = ('🔧 Zespół MINEVORA', '🛡 Moderator MINEVORA')
TICKET_CATEGORY = {'pl':'🎫 TICKETY','en':'🎫 TICKETS'}
TICKET_PANEL_CHANNEL = {'pl':'otworz-ticket','en':'open-ticket'}
RULES_CHANNEL = {'pl':'regulamin','en':'rules'}
RULES = {
'pl': """# 📜 REGULAMIN DISCORD MINEVORA
1. **Szanuj innych.** Zakazane są obrażanie, nękanie, groźby i dyskryminacja.
2. **Bez spamu i floodu.** Nie zaśmiecaj kanałów i nie wysyłaj powtarzających się wiadomości.
3. **Chroń prywatność.** Nie publikuj danych osobowych, haseł, tokenów, prywatnych rozmów ani cudzych zdjęć bez zgody.
4. **Bez oszustw.** Nie publikuj phishingu, złośliwych plików, fałszywych konkursów i podejrzanych linków.
5. **Treści odpowiednie dla społeczności.** Nie udostępniaj materiałów dla dorosłych, szokujących ani niebezpiecznych.
6. **Reklama za zgodą.** Promowanie serwerów i ofert tylko w wyznaczonych kanałach i na zasadach administracji.
7. **Uczciwe PvP.** Nie propaguj cheatów, exploitów ani obchodzenia zabezpieczeń oficjalnych serwerów.
8. **Szanuj twórców.** Publikuj tylko własne lub legalnie udostępniane mapy, modele, rigi i pliki; podawaj autorów i licencje.
9. **Właściwe kanały.** Pomoc i zgłoszenia zgłaszaj przez 🎫 ticket. Nie publikuj wrażliwych informacji w publicznych kanałach.
10. **Moderacja.** Przestrzegaj zasad Discorda. Moderatorzy mogą usuwać treści, wyciszać i blokować z podaniem powodu. Decyzje można spokojnie odwołać w ticketach.
11. **Nie podszywaj się** pod ekipę MINEVORA, moderatorów i innych użytkowników.

**Zgłoszenia:** kanał #otworz-ticket → przycisk **Otwórz zgłoszenie**.
**Informacja:** pisząc na serwerze, akceptujesz regulamin. Administracja powinna ogłaszać istotne zmiany zasad.
""",
'en': """# 📜 MINEVORA DISCORD RULES
1. **Respect others.** No harassment, threats, hateful or discriminatory behavior.
2. **No spam or flooding.** Keep messages relevant and avoid repetitions.
3. **Protect privacy.** Never share passwords, tokens, personal information, or others' private content.
4. **No scams.** No phishing, malicious files, misleading giveaways or suspicious links.
5. **Community-safe content.** No adult, shocking or dangerous content.
6. **Advertising requires permission.** Use approved channels and follow staff guidance.
7. **Fair PvP.** No promotion of cheats, exploits or bypassing protections on official servers.
8. **Respect creators.** Share only content you have rights to share; credit creators and comply with licenses.
9. **Use the correct channels.** Ask for private help via tickets, not public disclosures.
10. **Moderation.** Follow Discord's rules. Staff may remove content, timeout, or ban with reasons. Appeals may be filed through tickets.
11. **No impersonation** of MINEVORA staff or other users.

**Support:** #open-ticket → **Open ticket**. Important rules changes should be announced by staff.
"""
}

def ticket_topic(user_id, closed=False):
    if not isinstance(user_id,int) or user_id <= 0: raise ValueError('invalid Discord user ID')
    return f'minevora_ticket_owner_id={user_id};'+('closed' if closed else 'open')

def is_own_open_ticket(topic,user_id):
    return isinstance(topic,str) and topic.strip() == ticket_topic(user_id,False)

def ticket_slug(name, user_id):
    name = re.sub(r'[^a-z0-9-]+','-',str(name).lower()).strip('-')[:25] or 'gracz'
    return f'ticket-{name}-{int(user_id)}'[:95]
