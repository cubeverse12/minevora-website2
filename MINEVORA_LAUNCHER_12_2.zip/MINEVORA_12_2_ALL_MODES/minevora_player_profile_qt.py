"""MINEVORA: inspect locally recorded player bans, account links and anticheat signals."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QTabWidget, QVBoxLayout, QWidget, QComboBox, QLineEdit,
)
from minevora_player_profile_core import profile_snapshot
from minevora_fairplay_core import STATUSES, update_record_status


LABELS = {'ban': 'Zgłoszenie bana', 'linked': 'Powiązane konto', 'alert': 'Sygnał antycheat'}


def caption(text, size=12, bold=False):
    item = QLabel(text)
    item.setWordWrap(True)
    item.setTextFormat(Qt.PlainText)
    item.setStyleSheet('background:transparent;color:#e8e8f7;font-size:%dpx;font-weight:%d' % (size, 700 if bold else 400))
    return item


class PlayerProfileDialog(QDialog):
    """Detailed profile — no network lookups or automatic moderation decisions."""
    def __init__(self, player, remove_report=None, remove_player=None, update_report=None, parent=None):
        super().__init__(parent)
        self.player = player
        self.remove_report_callback = remove_report
        self.remove_player_callback = remove_player
        self.update_report_callback = update_report
        self.setWindowTitle('MINEVORA • Profil gracza: ' + str(player.get('name','')))
        self.resize(690, 570)
        self.setMinimumWidth(550)
        v = QVBoxLayout(self)
        v.setSpacing(12)
        snapshot = profile_snapshot(player)
        v.addWidget(caption('👤  ' + snapshot['name'], 25, True))
        v.addWidget(caption('Panel moderatora • dane lokalne • bez automatycznej oceny uczciwości', 11))
        v.addWidget(caption('UUID: ' + (snapshot['uuid'] or 'niepodany / profil niezweryfikowany')))
        warning = QFrame()
        warning.setObjectName('panel')
        w = QVBoxLayout(warning)
        w.addWidget(caption('ℹ  To lokalna karta zgłoszeń. Nie ma publicznej bazy wszystkich banów i multikont.', 12, True))
        w.addWidget(caption('Wpisy z innych serwerów muszą pochodzić od uprawnionej administracji. Importowany plik może być podmieniony, dlatego sprawdź źródło.'))
        v.addWidget(warning)
        s = snapshot['stats']
        self.header_stats = caption('⛔ Zgłoszone bany: %d (aktywne: %d)  •  Powiązania kont: %d  •  Alerty do sprawdzenia: %d' %
                           (s['bans_total'], s['bans_active'], s['linked_reports'], s['alerts_open']), 13, True)
        v.addWidget(self.header_stats)
        self.tabs = QTabWidget()
        v.addWidget(self.tabs, 1)
        self.tabs.addTab(self.summary_tab(snapshot), 'Podsumowanie')
        self.record_lists = {}
        self.status_selectors = {}
        self.record_details = {}
        for kind, title in [('ban', 'Bany'), ('linked', 'Powiązane konta'), ('alert', 'Antycheat')]:
            self.tabs.addTab(self.report_tab(kind, snapshot['groups'][kind]), title + ' (' + str(len(snapshot['groups'][kind])) + ')')
        action = QHBoxLayout()
        close = QPushButton('Zamknij profil')
        close.clicked.connect(self.accept)
        action.addWidget(close)
        action.addStretch()
        delete = QPushButton('🗑  Usuń profil i raporty')
        delete.setToolTip('Usuwa wyłącznie dane tego profilu zapisane lokalnie w MINEVORA.')
        delete.clicked.connect(self.remove_player)
        action.addWidget(delete)
        v.addLayout(action)

    def summary_tab(self, snapshot):
        area = QWidget()
        col = QVBoxLayout(area)
        col.setSpacing(11)
        s = snapshot['stats']
        col.addWidget(caption('⛔  Historia banów', 15, True))
        col.addWidget(caption('W lokalnej bazie: %d wpisów, w tym %d aktywnych, z %d zgłoszonych sieci.' %
                              (s['bans_total'], s['bans_active'], s['servers_reported'])))
        if snapshot['ban_servers']:
            col.addWidget(caption('Zgłoszone serwery: ' + ', '.join(snapshot['ban_servers'])))
        else:
            col.addWidget(caption('Nie ma zgłoszeń banów. To NIE oznacza potwierdzenia braku banów na innych serwerach.'))
        col.addWidget(caption('◈  Powiązane konta', 15, True))
        col.addWidget(caption('Zgłoszone: %d  •  Oznaczone przez moderatora jako sprawdzone lokalnie: %d' %
                              (snapshot['links_reported'], snapshot['links_checked_locally'])))
        col.addWidget(caption('Brak wpisów nie dowodzi, że gracz nie ma innych kont. Bez potwierdzenia nie przypisuj mu multikont.'))
        col.addWidget(caption('⚠  Sygnały antycheat', 15, True))
        col.addWidget(caption('Do weryfikacji przez moderatora: %d. Sygnał nie jest dowodem oszukiwania.' % s['alerts_open']))
        col.addStretch()
        return area

    def report_tab(self, kind, reports):
        area = QWidget()
        col = QVBoxLayout(area)
        col.addWidget(caption('Lista zapisanych wpisów. Kliknij raport, aby zobaczyć jego źródło.'))
        entries = QListWidget()
        entries.setMinimumHeight(155)
        self.record_lists[kind] = entries
        for report in reversed(reports):
            name = report.get('account', '') if kind == 'linked' else report.get('server', '')
            item = QListWidgetItem('%s  ·  %s  ·  %s' % (name, report.get('server', '') if kind == 'linked' else LABELS[kind], report.get('status', '')))
            item.setData(Qt.UserRole, report)
            entries.addItem(item)
        col.addWidget(entries, 1)
        detail = caption('Wybierz raport, aby zobaczyć szczegóły.')
        col.addWidget(detail)
        self.record_details[kind] = detail
        def selection_changed():
            it = entries.currentItem()
            if not it:
                detail.setText('Brak raportów w tej kategorii.')
                return
            r = it.data(Qt.UserRole)
            detail.setText('Serwer: %s\nStatus: %s\nData: %s\nŹródło: %s\n%s\nOpis: %s' % (
                r.get('server', ''), r.get('status', ''), r.get('created_at', ''),
                r.get('source', 'nieznane'),
                'Zgłoszone konto: ' + r.get('account', '') if kind == 'linked' else '',
                (r.get('detail', '') or '(brak szczegółów)') +"\nHistoria decyzji: " + (" | ".join(str(x.get('from',''))+' → '+str(x.get('to',''))+' ('+str(x.get('at',''))[:10]+')' for x in r.get('review_history', [])[-3:]) or 'brak')))
        entries.currentItemChanged.connect(lambda *_: selection_changed())
        if entries.count(): entries.setCurrentRow(0)
        else: selection_changed()
        change = QHBoxLayout()
        change.addWidget(caption('Status:', 11))
        status_selector = QComboBox()
        status_selector.addItems(STATUSES[kind])
        self.status_selectors[kind] = status_selector
        change.addWidget(status_selector)
        note = QLineEdit()
        note.setMaxLength(180)
        note.setPlaceholderText('Notatka moderatora (opcjonalnie)')
        change.addWidget(note, 1)
        col.addLayout(change)
        def sync_selector():
            it = entries.currentItem()
            if it:
                index = status_selector.findText(str(it.data(Qt.UserRole).get('status', '')))
                if index >= 0:status_selector.setCurrentIndex(index)
        entries.currentItemChanged.connect(lambda *_:sync_selector())
        sync_selector()
        confirm = QPushButton('✓ Zapisz decyzję')
        confirm.setEnabled(self.update_report_callback is not None)
        confirm.clicked.connect(lambda checked=False, k=kind, n=note: self.change_status(k, n))
        col.addWidget(confirm)
        delete = QPushButton('Usuń wybrany raport')
        delete.clicked.connect(lambda checked=False, k=kind: self.remove_report(k))
        col.addWidget(delete)
        return area

    def change_status(self, kind, note):
        selected = self.record_lists[kind].currentItem()
        if not selected or self.update_report_callback is None:
            return
        report = selected.data(Qt.UserRole)
        selected_status = self.status_selectors[kind].currentText()
        if selected_status == report.get('status'):
            QMessageBox.information(self, 'Fair Play', 'Ten raport ma już wybrany status.')
            return
        if self.update_report_callback(self.player['id'], report['id'], selected_status, note.text()):
            update_record_status(self.player, report['id'], selected_status, note.text())
            selected.setText('%s  ·  %s  ·  %s' %
                (report.get('account','') if kind == 'linked' else report.get('server',''),
                 report.get('server','') if kind == 'linked' else LABELS[kind], selected_status))
            note.clear()
            s = profile_snapshot(self.player)['stats']
            self.header_stats.setText('⛔ Zgłoszone bany: %d (aktywne: %d)  •  Powiązania kont: %d  •  Alerty do sprawdzenia: %d' %
                    (s['bans_total'], s['bans_active'], s['linked_reports'], s['alerts_open']))
            self.record_details[kind].setText('Decyzja zapisana lokalnie. Wybierz ponownie raport, aby odświeżyć szczegóły.')
            QMessageBox.information(self, 'Fair Play', 'Zmieniono lokalny status. To nie jest automatyczna kara na serwerze.')

    def remove_report(self, kind):
        selected = self.record_lists[kind].currentItem()
        if not selected or self.remove_report_callback is None:
            return
        r = selected.data(Qt.UserRole)
        if QMessageBox.question(self, 'Usuń raport', 'Usunąć lokalny wpis z wybranego profilu?') != QMessageBox.Yes:
            return
        if self.remove_report_callback(self.player['id'], r['id']):
            self.accept()

    def remove_player(self):
        if self.remove_player_callback is None:
            return
        if QMessageBox.question(self, 'Usuń profil',
            'Usunąć profil i całą lokalną historię zgłoszeń? Ta czynność jest nieodwracalna.') != QMessageBox.Yes:
            return
        if self.remove_player_callback(self.player['id']):
            self.accept()
