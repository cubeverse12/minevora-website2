"""Embedded Discord control panel for MINEVORA launcher (PySide6)."""
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QWidget, QScrollArea, QVBoxLayout, QHBoxLayout, QGridLayout,
    QFrame, QLabel, QPushButton, QLineEdit, QCheckBox, QMessageBox, QSizePolicy)
from minevora_discord_core import normalize_invite, OFFICIAL_MINEVORA_DISCORD_INVITE
from minevora_discord_announcements import DiscordAnnouncements


def _label(value, size=13, muted=False, bold=False):
    label = QLabel(value)
    label.setWordWrap(True)
    label.setStyleSheet('background:transparent;color:%s;font-size:%dpx;font-weight:%d;' %
                        ('#b6c4e0' if muted else '#faf6ff', size, 750 if bold else 450))
    return label


def _button(label, action, prominent=False):
    widget = QPushButton(label)
    if prominent:
        widget.setObjectName('primary')
    widget.clicked.connect(lambda _checked=False: action())
    widget.setCursor(Qt.PointingHandCursor)
    return widget


def _panel():
    obj = QFrame()
    obj.setObjectName('panel')
    return obj


class DiscordHub(QWidget):
    def __init__(self, prefs_getter, save, connect, status, is_playing, version, parent=None):
        super().__init__(parent)
        self._prefs = prefs_getter
        self._save = save
        self._connect = connect
        self._status = status
        self._is_playing = is_playing
        self._version = version
        self._make_ui()
        self.load_preferences()
        self.refresh_status()

    def _make_ui(self):
        frame = QVBoxLayout(self)
        frame.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        frame.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        root = QVBoxLayout(content)
        root.setContentsMargins(25, 20, 25, 25)
        root.setSpacing(16)

        root.addWidget(_label('◈  DISCORD • MINEVORA', 29, bold=True))
        root.addWidget(_label('Aktywność Minecraft na Twoim profilu Discord oraz dostęp do społeczności.', 13, muted=True))

        self.hero = _panel()
        hv = QVBoxLayout(self.hero)
        hv.setContentsMargins(23, 20, 23, 20)
        hv.setSpacing(10)
        hv.addWidget(_label('✦  STATUS POŁĄCZENIA', 13, bold=True))
        self.status_text = _label('Niepołączono', 22, bold=True)
        hv.addWidget(self.status_text)
        self.status_detail = _label('', 12, muted=True)
        hv.addWidget(self.status_detail)
        actions = QHBoxLayout()
        actions.addWidget(_button('↻  Połącz / Sprawdź', self.try_connect, prominent=True))
        actions.addWidget(_button('🌐  Otwórz Discord', lambda: QDesktopServices.openUrl(QUrl('https://discord.com/app'))))
        hv.addLayout(actions)
        root.addWidget(self.hero)

        settings = _panel()
        sv = QVBoxLayout(settings)
        sv.setContentsMargins(23, 20, 23, 20)
        sv.setSpacing(11)
        sv.addWidget(_label('⚙  DISCORD RICH PRESENCE', 20, bold=True))
        sv.addWidget(_label('Rich Presence pokazuje, że grasz lub przeglądasz launcher. Nie loguje Cię do Discorda w MINEVORA.', 12, muted=True))
        sv.addWidget(_label('Discord Application ID:', 12, bold=True))
        self.client_id = QLineEdit()
        self.client_id.setMaxLength(22)
        self.client_id.setPlaceholderText('Wklej Application ID z Discord Developer Portal')
        sv.addWidget(self.client_id)
        self.enabled = QCheckBox('Włącz Discord Rich Presence')
        self.game_only = QCheckBox('Pokazuj aktywność tylko podczas grania')
        self.version_enabled = QCheckBox('Pokazuj wersję Minecraft (bez adresu serwera)')
        for cb in (self.enabled, self.game_only, self.version_enabled):
            sv.addWidget(cb)
        preview = _panel()
        pv = QVBoxLayout(preview)
        pv.addWidget(_label('PODGLĄD AKTYWNOŚCI', 11, muted=True, bold=True))
        self.preview_details = _label('Gra w Minecraft Java', 16, bold=True)
        self.preview_state = _label('MINEVORA', 12, muted=True)
        pv.addWidget(self.preview_details)
        pv.addWidget(self.preview_state)
        sv.addWidget(preview)
        self.game_only.toggled.connect(self.update_preview)
        self.version_enabled.toggled.connect(self.update_preview)
        save_row = QHBoxLayout()
        save_row.addWidget(_button('💾  Zapisz ustawienia', self.save_preferences, prominent=True))
        save_row.addWidget(_button('🔑  Utwórz Application ID', lambda: QDesktopServices.openUrl(QUrl('https://discord.com/developers/applications'))))
        sv.addLayout(save_row)
        sv.addWidget(_label('Wymagane: uruchomiony Discord na Windows oraz pakiet pypresence. Application ID jest publicznym identyfikatorem aplikacji, nie hasłem.', 11, muted=True))
        root.addWidget(settings)

        community = _panel()
        cv = QVBoxLayout(community)
        cv.setContentsMargins(23, 20, 23, 20)
        cv.setSpacing(11)
        cv.addWidget(_label('💬  DISCORD SPOŁECZNOŚCI MINEVORA', 20, bold=True))
        cv.addWidget(_label('Dołącz do społeczności naszego launchera Minecraft. Rozmawiaj o modach, PvP, mapach i aktualizacjach!', 13, muted=True))
        official = _panel()
        official.setStyleSheet('QFrame#panel { background:#171c37; border:1px solid #8365cd; border-radius:12px; }')
        ov = QVBoxLayout(official)
        ov.setContentsMargins(18, 15, 18, 15)
        ov.setSpacing(9)
        ov.addWidget(_label('✦  DISCORD MINEVORA', 17, bold=True))
        self.official_invite_label = _label(OFFICIAL_MINEVORA_DISCORD_INVITE, 13, muted=True)
        self.official_invite_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        ov.addWidget(self.official_invite_label)
        official_buttons = QHBoxLayout()
        official_buttons.addWidget(_button('🚀  DOŁĄCZ DO NASZEGO DISCORDA', self.open_official_invite, prominent=True))
        official_buttons.addWidget(_button('📋  Kopiuj link', self.copy_official_invite))
        ov.addLayout(official_buttons)
        cv.addWidget(official)
        cv.addWidget(_label('INNY ZAPISANY SERWER (OPCJONALNIE)', 11, muted=True, bold=True))
        cv.addWidget(_label('Możesz także przechowywać link do innej społeczności. Nie zmienia to przycisku oficjalnego Discorda MINEVORA.', 11, muted=True))
        self.invite = QLineEdit()
        self.invite.setPlaceholderText('https://discord.gg/inny-serwer')
        cv.addWidget(self.invite)
        community_buttons = QHBoxLayout()
        community_buttons.addWidget(_button('🔗  Otwórz inny serwer', self.open_invite))
        community_buttons.addWidget(_button('📋  Kopiuj inny link', self.copy_invite))
        cv.addLayout(community_buttons)
        root.addWidget(community)

        self.announcements = DiscordAnnouncements(self)
        root.addWidget(self.announcements)

        root.addWidget(_label('PRYWATNOŚĆ  •  Ta integracja nie czyta prywatnych wiadomości, listy znajomych ani Twojego hasła. Nie wyświetla IP serwera Minecraft.', 11, muted=True))
        root.addStretch()

    def load_preferences(self):
        prefs = self._prefs()
        self.client_id.setText(str(prefs.get('discord_app_id', '')))
        self.enabled.setChecked(bool(prefs.get('discord_enabled', False)))
        self.game_only.setChecked(bool(prefs.get('discord_only_in_game', True)))
        self.version_enabled.setChecked(bool(prefs.get('discord_show_version', False)))
        self.invite.setText(str(prefs.get('discord_invite_url', '')))
        self.update_preview()

    def update_preview(self, *_args):
        from minevora_discord_core import presence_payload
        playing = self._is_playing()
        prefs = {'discord_show_version': self.version_enabled.isChecked()}
        payload = presence_payload(prefs, playing, self._version())
        self.preview_details.setText(payload['details'])
        self.preview_state.setText(payload['state'])

    def refresh_status(self):
        value = self._status()
        self.status_text.setText('●  Połączono' if value.get('connected') else '○  Niepołączono')
        self.status_text.setStyleSheet('background:transparent;color:%s;font-size:22px;font-weight:750;' %
                                      ('#7fe6c0' if value.get('connected') else '#f7c38b'))
        self.status_detail.setText(value.get('message', 'Brak informacji'))
        self.update_preview()

    def save_preferences(self):
        values = {'discord_app_id': self.client_id.text().strip(),
                  'discord_enabled': self.enabled.isChecked(),
                  'discord_only_in_game': self.game_only.isChecked(),
                  'discord_show_version': self.version_enabled.isChecked(),
                  'discord_invite_url': self.invite.text().strip()}
        success, explanation = self._save(values)
        if success:
            self.load_preferences()
            self.refresh_status()
            QMessageBox.information(self, 'MINEVORA Discord', explanation)
        else:
            QMessageBox.warning(self, 'MINEVORA Discord', explanation)

    def try_connect(self):
        if self.enabled.isChecked() != bool(self._prefs().get('discord_enabled', False)) or \
                self.client_id.text().strip() != str(self._prefs().get('discord_app_id', '')) or \
                self.game_only.isChecked() != bool(self._prefs().get('discord_only_in_game', True)) or \
                self.version_enabled.isChecked() != bool(self._prefs().get('discord_show_version', False)):
            QMessageBox.information(self, 'Discord', 'Najpierw zapisz ustawienia Discorda.')
            return
        self._connect()
        self.refresh_status()

    def open_official_invite(self):
        QDesktopServices.openUrl(QUrl(OFFICIAL_MINEVORA_DISCORD_INVITE))

    def copy_official_invite(self):
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(OFFICIAL_MINEVORA_DISCORD_INVITE)
        QMessageBox.information(self, 'MINEVORA Discord', 'Oficjalny link zaproszenia skopiowany.')

    def _invite_url(self):
        try:
            return normalize_invite(self.invite.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'Link Discorda', str(exc))
            return None

    def open_invite(self):
        url = self._invite_url()
        if not url:
            if url is not None:
                QMessageBox.information(self, 'Serwer Discord', 'Najpierw wpisz link zaproszenia do serwera.')
            return
        QDesktopServices.openUrl(QUrl(url))

    def copy_invite(self):
        from PySide6.QtWidgets import QApplication
        url = self._invite_url()
        if url:
            QApplication.clipboard().setText(url)
            QMessageBox.information(self, 'Discord', 'Link zaproszenia skopiowany.')
