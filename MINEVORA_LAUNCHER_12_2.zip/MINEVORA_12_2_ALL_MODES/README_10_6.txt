MINEVORA 10.6 — AI, BONUSY XP, TICKETY I REGULAMIN DISCORD
==========================================================

INSTALACJA WINDOWS
1. Zamknij Minecraft i wszystkie okna poprzedniego launchera.
2. Wykonaj kopię folderu %USERPROFILE%\.minevora (postęp Marketplace i XP).
3. Rozpakuj ten ZIP do NOWEGO folderu, bez usuwania starego launchera.
4. Uruchom INSTALUJ_ZALEZNOSCI.bat, potem URUCHOM_MINEVORA.bat.
5. Nowości: zakładka ✧ MINEVORA AI oraz 🏆 Rangi twórcy → bonusy XP.
6. DISCORD_SETUP zawiera instalator prywatnych ticketów i kanału z regulaminem.

ASYSTENT MINEVORA
- Pomoc offline działa bez internetu i bez opłat: odpowiada na popularne pytania
  o launcher, Minecraft, Modrinth, Marketplace, PvP i Discord.
- To baza porad, NIE model ChatGPT. Nie zastępuje pełnego asystenta AI.
- OPCJONALNY model online: prywatny backend. Nie wklejaj kluczy API do launchera.
  Możesz uruchomić MINEVORA_AI_LOCAL_SERVER.py na własnym komputerze.
  Backend wymaga osobno pakietu openai i prywatnego OPENAI_API_KEY.
  Jego użycie może wiązać się z opłatami za API — potrzebna jest odpowiednia
  zgoda właściciela konta rozliczeniowego. Nie publikuj API key.
  W PowerShell, w tej samej sesji, w której uruchamiasz launcher, ustaw:
    $env:MINEVORA_AI_ENDPOINT = "http://127.0.0.1:8767/ask"
  Uruchom MINEVORA_AI_LOCAL_SERVER.py w osobnym oknie (po ustawieniu klucza
  w zmiennej środowiskowej TYLKO dla lokalnego serwera). Potem uruchom launcher
  i zaznacz opcję wysłania pytania online.
  Dla PUBLICZNEGO launchera: osobny chroniony backend, logowanie użytkowników,
  limit zapytań, moderacja, HTTPS i zgody dotyczące danych.
- Nigdy nie wysyłaj na czat haseł, tokenów ani danych osobowych.

BONUS TYGODNIOWY I ×2 XP
- Otwórz zakładkę 🏆 Rangi twórcy.
- Raz na tydzień UTC: odbierz 100 MVC (DEMO) i 1 voucher ×2 XP.
- Kliknij "Aktywuj ×2 XP": booster działa przez 30 minut zegarowych.
- W trakcie działania za unikalną nową mapę: 240 XP zamiast 120,
  za budowlę: 160 XP zamiast 80, za rig: 50 XP zamiast 25,
  za model Blender/Blockbench: 40 XP zamiast 20.
- Każdy projekt daje XP tylko raz na konto lokalne (ta sama kategoria,
  ten sam twórca i nazwa = brak ponownego XP).
- Migrowane stare projekty nie dostają mnożnika. Jeden aktywny booster naraz.
- Czas liczy się także, gdy launcher jest zamknięty. Nie łączy się z PvP.
- To lokalny prototyp, nie ranking i nie waluta z prawdziwą wartością.

DISCORD — TICKETY I REGULAMIN
1. Jeśli jeszcze nie masz ról/kanalów na Discordzie: w folderze DISCORD_SETUP
   najpierw uruchom UTWORZ_KANALY.bat z poprzedniej funkcji (instalator kanałów).
2. Utwórz bota na https://discord.com/developers/applications (lub użyj już
   stworzonego bota; NIE używaj tokenu konta użytkownika).
3. Zaproś bota na SWÓJ serwer: uprawnienia Manage Channels, View Channels,
   Send Messages i Read Message History. Bot musi mieć rolę umieszczoną na
   odpowiedniej pozycji oraz możliwość ustawiania uprawnień.
4. Uruchom DISCORD_SETUP\INSTALUJ_TICKETY_I_REGULAMIN.bat. Po wpisaniu tokenu
   w lokalnym oknie wybierz prawidłowy serwer i wpisz "tak".
5. Skrypt utworzy prywatną kategorię 🎫 TICKETY i publiczny tylko-do-odczytu
   #otworz-ticket z przyciskiem. Zaktualizuje/opublikuje #regulamin.
6. Upewnij się, że masz przypisaną rolę 🔧 Zespół MINEVORA albo
   🛡 Moderator MINEVORA oraz że kanał ticketu jest niewidoczny dla innych.
7. W przyszłości włącz DISCORD_SETUP\URUCHOM_BOTA_TICKETOW.bat i POZOSTAW
   bota uruchomionego przez cały czas obsługi ticketów. Aby działał 24/7,
   potrzebuje hostingu. Nie wystarczy sam statyczny GitHub Pages.
8. Jeden otwarty ticket na użytkownika; zamknięte zgłoszenia pozostają
   dostępne tylko dla zespołu i nie są automatycznie usuwane.
9. Nie wysyłaj tokenu bota do wiadomości Discord ani do czatu ChatGPT.
10. Regulaminy PL/EN dostępne jako pliki tekstowe w DISCORD_SETUP.

OGRANICZENIA
- Nie podłączono do Twojego żywego serwera Discord. Zmiany zajdą dopiero po
  uruchomieniu instalatora z botem na Twoim koncie i zatwierdzeniu.
- Prywatność ticketów: członkowie z uprawnieniami Administrator na
  serwerze Discord mogą mieć dostęp niezależnie od uprawnień kanału.
- Nie testowano renderowania PySide6 na Windows ani działania bota Discord na
  prawdziwym serwerze. Przed udostępnieniem wszystkim przetestuj prywatność
  ticketów i zachowaj kopie ważnych ustawień.
