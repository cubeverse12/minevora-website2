import importlib.util
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

MODULE=Path(__file__).with_name('minevora_chat_server.py')
spec=importlib.util.spec_from_file_location('chat_tested', MODULE)
srv=importlib.util.module_from_spec(spec)
spec.loader.exec_module(srv)

class ChatTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory()
  srv.DB=Path(cls.tmp.name)/'chat.sqlite3'
  srv.TOKEN='unit-test-secret'
  srv.initialize()
  cls.http=ThreadingHTTPServer(('127.0.0.1',0),srv.Handler)
  cls.base='http://127.0.0.1:'+str(cls.http.server_port)
  cls.worker=threading.Thread(target=cls.http.serve_forever,daemon=True)
  cls.worker.start()
 @classmethod
 def tearDownClass(cls):
  cls.http.shutdown();cls.http.server_close();cls.tmp.cleanup()
 def api(self,path,data=None,admin=False):
  payload=json.dumps(data).encode() if data is not None else None
  headers={'Content-Type':'application/json'}
  if admin:headers['Authorization']='Bearer unit-test-secret'
  req=urllib.request.Request(self.base+path,payload,headers,method='POST' if payload is not None else 'GET')
  try:
   with urllib.request.urlopen(req,timeout=3) as res:return res.status,json.loads(res.read())
  except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
 def test_01_health(self):self.assertEqual(self.api('/health')[0],200)
 def test_02_no_admin(self):
  self.assertEqual(self.api('/admin/status')[0],403)
  self.assertEqual(self.api('/admin/delete',{'message_id':1})[0],403)
 def test_03_send_and_flag(self):
  code,_=self.api('/send',{'name':'TestSteve','country':'Polska','body':'Hej'})
  self.assertEqual(code,200)
  code,data=self.api('/messages');self.assertEqual(code,200)
  self.assertEqual(data['messages'][-1]['country'],'Polska')
  self.__class__.message_id=data['messages'][-1]['id']
 def test_04_report(self):
  self.assertEqual(self.api('/report',{'message_id':self.message_id,'reason':'Spam'})[0],200)
  code,reports=self.api('/admin/reports',admin=True)
  self.assertEqual(code,200)
  self.assertEqual(reports['reports'][0]['reason'],'Spam')
  self.assertEqual(self.api('/admin/resolve',{'report_id':reports['reports'][0]['id']},admin=True)[0],200)
 def test_05_mute(self):
  self.assertEqual(self.api('/admin/mute',{'name':'TestSteve','minutes':10},admin=True)[0],200)
  code,_=self.api('/send',{'name':'TestSteve','country':'Polska','body':'Test2'})
  self.assertEqual(code,403)
  self.assertEqual(self.api('/admin/unmute',{'name':'TestSteve'},admin=True)[0],200)
 def test_06_ban_case_insensitive(self):
  self.assertEqual(self.api('/admin/ban',{'name':'TestSteve'},admin=True)[0],200)
  code,_=self.api('/send',{'name':'teststeve','country':'Polska','body':'Test3'})
  self.assertEqual(code,403)
  self.assertEqual(self.api('/admin/unban',{'name':'TestSteve'},admin=True)[0],200)
 def test_07_delete(self):
  self.assertEqual(self.api('/admin/delete',{'message_id':self.message_id},admin=True)[0],200)
  code,data=self.api('/messages')
  self.assertTrue(all(x['id'] != self.message_id for x in data['messages']))
 def test_08_validation(self):
  self.assertEqual(self.api('/send',{'name':'<b>','country':'Polska','body':'hej'})[0],400)
  self.assertEqual(self.api('/send',{'name':'TestSteve','country':'Polska','body':'x'*301})[0],400)
 def test_09_mute_limits(self):self.assertEqual(self.api('/admin/mute',{'name':'TestSteve','minutes':-1},admin=True)[0],400)
 def test_10_migration(self):
  import sqlite3
  old=Path(self.tmp.name)/'old.sqlite3'
  with sqlite3.connect(old) as c:
   c.execute('CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, country TEXT, body TEXT, stamp TEXT)')
   c.execute('CREATE TABLE reports (id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER, reason TEXT, stamp TEXT)')
   c.execute("INSERT INTO messages(name,country,body,stamp) VALUES('Old','Polska','test','12:00')")
  srv.initialize(old)
  with sqlite3.connect(old) as c:
   self.assertEqual(c.execute('SELECT deleted FROM messages').fetchone()[0],0)
   self.assertIn('status',{col[1] for col in c.execute('PRAGMA table_info(reports)')})

if __name__=='__main__':unittest.main(verbosity=2)
