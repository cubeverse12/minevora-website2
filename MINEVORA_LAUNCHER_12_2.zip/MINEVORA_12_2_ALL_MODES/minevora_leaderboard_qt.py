"""MINEVORA 11.0 – local, privacy-first leaderboard editor/view."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFrame, QComboBox,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QDialog, QFormLayout, QSpinBox, QDialogButtonBox, QMessageBox, QFileDialog)
from minevora_leaderboard_core import (load_local, save_local, put_player, delete_player,
    ranked, export_public, clean_nick)
from minevora_rewards import ensure as ensure_creator, level_of, rank_of


def action(title, callback):
    button=QPushButton(title)
    button.clicked.connect(callback)
    return button


class PlayerEditor(QDialog):
    def __init__(self, parent=None, row=None):
        super().__init__(parent)
        self.setWindowTitle('Gracz w lokalnym rankingu')
        self.setMinimumWidth(360)
        layout=QVBoxLayout(self)
        form=QFormLayout()
        self.nick=QLineEdit(str((row or {}).get('nick','')))
        self.nick.setPlaceholderText('Nick Minecraft (3–16 znaków)')
        form.addRow('Nick:',self.nick)
        self.scores={}
        labels={'xp':'XP twórcy','wins':'Wygrane PvP','losses':'Przegrane PvP',
                'kills':'Eliminacje PvP','deaths':'Zgony PvP'}
        for name,label in labels.items():
            spin=QSpinBox();spin.setRange(0,1000000000)
            spin.setValue((row or {}).get(name,0))
            self.scores[name]=spin
            form.addRow(label+':',spin)
        layout.addLayout(form)
        buttons=QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    def entry(self):
        return {'nick':clean_nick(self.nick.text()),
                **{key:spin.value() for key,spin in self.scores.items()}}


class LeaderboardPage(QWidget):
    def __init__(self, get_market, get_pvp, get_nick, parent=None):
        super().__init__(parent)
        self.get_market=get_market
        self.get_pvp=get_pvp
        self.get_nick=get_nick
        self.data=load_local()
        root=QVBoxLayout(self);root.setContentsMargins(26,22,26,20);root.setSpacing(12)
        title=QLabel('🏆  RANKING GRACZY MINEVORA')
        title.setStyleSheet('font-size:25px;font-weight:800')
        root.addWidget(title)
        intro=QLabel('Twój profil aktualizuje się sam po zalogowaniu Microsoft i zdobyciu XP za projekty. '+
                     'PvP synchronizuje zapisane lokalnie wyniki treningów; nie pobiera ich bezpośrednio z serwerów. '+
                     'Starsze ręczne wpisy pozostają lokalne i nie są zweryfikowane.')
        intro.setWordWrap(True)
        intro.setStyleSheet('color:#c4bddc')
        root.addWidget(intro)
        bar=QHBoxLayout()
        self.mode=QComboBox();self.mode.addItems(['🏗  Twórcy • XP', '⚔  PvP • Wygrane'])
        self.mode.currentIndexChanged.connect(self.refresh_table)
        self.search=QLineEdit();self.search.setPlaceholderText('Szukaj gracza...')
        self.search.textChanged.connect(self.refresh_table)
        bar.addWidget(self.mode);bar.addWidget(self.search,1)
        root.addLayout(bar)
        self.top=QLabel('TOP 3 • brak danych')
        self.top.setWordWrap(True)
        self.top.setStyleSheet('color:#e9d19d;font-size:15px;font-weight:700;padding:8px')
        root.addWidget(self.top)
        self.table=QTableWidget(0,7)
        self.table.setHorizontalHeaderLabels(['#','Nick','XP / poziom','Ranga','Wygrane','Przegrane','K/D'])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        root.addWidget(self.table,1)
        actions=QHBoxLayout()
        actions.addWidget(action('↻ Odśwież ranking',self.refresh_table))
        actions.addWidget(action('↓ Eksport na stronę',self.export_for_site))
        root.addLayout(actions)
        hint=QLabel('Twój XP jest naliczany automatycznie za dodane projekty, gdy jesteś zalogowany. '+
                    'Statystyki PvP są lokalnym dziennikiem, nie zweryfikowaną telemetrią serwera. '+
                    'Eksport tworzy ranking.json z publicznymi nickami i statystykami. '+
                    'Przed publikacją uzyskaj zgodę osób widocznych w rankingu. '+
                    'Na GitHub Pages trzeba wgrać nowy plik po każdej zmianie.')
        hint.setWordWrap(True);hint.setStyleSheet('color:#adb9d0;font-size:11px')
        root.addWidget(hint)
        self.refresh_table()

    def selected_nick(self):
        selected=self.table.selectedItems()
        return selected[1].text() if len(selected)>1 else None

    def refresh_table(self, *_):
        mode='pvp' if self.mode.currentIndex()==1 else 'xp'
        all_rows=ranked(self.data,mode)
        rows=[row for row in all_rows if self.search.text().strip().casefold() in row['nick'].casefold()]
        if all_rows:
            medals=['🥇','🥈','🥉']
            self.top.setText('    '.join(f'{medals[i]} {row["nick"]} — '+
                          (str(row['wins'])+' wygr.' if mode=='pvp' else str(row['xp'])+' XP')
                          for i,row in enumerate(all_rows[:3])))
        else:self.top.setText('TOP 3 • brak wpisów — dodaj gracza albo pobierz własny postęp')
        self.table.setRowCount(len(rows))
        for i,row in enumerate(rows):
            level=level_of(row['xp']);rank=rank_of(level)['name']
            kd=('∞' if row['deaths']==0 and row['kills'] else
                 f'{row["kills"]/max(1,row["deaths"]):.2f}')
            data=[str(i+1),row['nick'],f'{row["xp"]} / Lv {level}',rank,
                  str(row['wins']),str(row['losses']),kd]
            for j,value in enumerate(data):
                item=QTableWidgetItem(value)
                if j in (0,2,4,5,6):item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i,j,item)

    def _save(self, updated):
        try:
            self.data=save_local(updated)
        except OSError as exc:
            QMessageBox.warning(self,'Błąd zapisu',str(exc));return False
        self.refresh_table();return True

    def edit_player(self):
        name=self.selected_nick()
        selected=next((row for row in self.data['players'] if row['nick']==name),None)
        dialog=PlayerEditor(self,selected)
        if dialog.exec()!=QDialog.Accepted:return
        try:updated=put_player(self.data,dialog.entry())
        except ValueError as exc:
            QMessageBox.warning(self,'Nieprawidłowe dane',str(exc));return
        self._save(updated)

    def remove_player(self):
        name=self.selected_nick()
        if not name:
            QMessageBox.information(self,'Ranking','Najpierw wybierz gracza z tabeli.');return
        if QMessageBox.question(self,'Usuń wpis',f'Usunąć lokalny wpis gracza {name}?')!=QMessageBox.Yes:return
        self._save(delete_player(self.data,name))

    def import_my_progress(self):
        suggested=self.get_nick() or ''
        from PySide6.QtWidgets import QInputDialog
        nick,ok=QInputDialog.getText(self,'Mój postęp','Nick, który chcesz pokazywać w rankingu:',text=suggested)
        if not ok:return
        try:nick=clean_nick(nick)
        except ValueError as exc:
            QMessageBox.warning(self,'Nick',str(exc));return
        if QMessageBox.question(self,'Importuj swój postęp',
                f'Dodać do lokalnej listy wyniki zapisane na tym komputerze jako {nick}? '+
                'To dane lokalne, niepotwierdzone przez serwer.')!=QMessageBox.Yes:return
        progress=ensure_creator(self.get_market());stats=self.get_pvp().get('stats',{})
        player={'nick':nick,'xp':progress['xp'],
                **{k:max(0,stats.get(k,0)) if type(stats.get(k)) is int else 0
                   for k in ('wins','losses','kills','deaths')}}
        try: self._save(put_player(self.data,player))
        except ValueError as exc:QMessageBox.warning(self,'Błąd',str(exc))

    def export_for_site(self):
        if not self.data['players']:
            QMessageBox.information(self,'Ranking','Najpierw dodaj przynajmniej jednego gracza.');return
        if QMessageBox.question(self,'Udostępnienie danych',
                'Ranking będzie zawierał publiczne nicki Minecraft i statystyki. '+
                'Upewnij się, że masz zgodę graczy. Utworzyć plik do publikacji?')!=QMessageBox.Yes:return
        path,_=QFileDialog.getSaveFileName(self,'Zapisz ranking dla strony',
                                           'ranking.json','Pliki JSON (*.json)')
        if not path:return
        try:count=export_public(self.data,path)
        except OSError as exc:
            QMessageBox.warning(self,'Błąd eksportu',str(exc));return
        QMessageBox.information(self,'Eksport gotowy',
                f'Zapisano {count} wpisów. Przenieś ranking.json do głównego folderu strony '+
                'MINEVORA obok pliku ranking.html i wgraj na hosting.')
