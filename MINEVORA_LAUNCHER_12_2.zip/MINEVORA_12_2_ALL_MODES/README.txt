MINEVORA 9.0 — Fantasy Edition

1. Rozpakuj caly ZIP do nowego folderu.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat.
3. Uruchom URUCHOM_MINEVORA.bat.

Nowosci: diagnostyka systemu, eksport ustawien, poprawki logowania i katalogow gry, spojny numer wersji 9.0.
Zachowano: marketplace demo, Modrinth, HUD, Discord RPC, chat, skiny, instalacje Minecraft.
Ograniczenia: FPS i ping wymagaja moda; marketplace nie realizuje prawdziwych platnosci; konto Microsoft wymaga Client ID i poprawnej konfiguracji OAuth.
Nie testowano interfejsu na Windows.

WERSJA 11.0: ranking graczy (lokalny) — README_RANKING_11_0.txt

MINEVORA 11.3: instalowanie wymaganych zaleznosci modow z Modrinth. Szczegoly w README_11_3_AUTO_MODS.txt.
