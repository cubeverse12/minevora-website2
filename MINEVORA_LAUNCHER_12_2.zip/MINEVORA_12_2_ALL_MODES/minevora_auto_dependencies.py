"""MINEVORA 11.3: installs required Modrinth mod dependencies safely.

Only metadata for installed Modrinth-recognised JARs is inspected. Required
references are followed recursively. Existing files are never overwritten and
already-installed mods are never updated by this module. Network code runs in
QThread workers, not on the main Qt thread.
"""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

API = 'https://api.modrinth.com/v2'
HEADERS = {'User-Agent': 'MINEVORA/11.3 (Minecraft launcher; auto dependency resolver)', 'Accept': 'application/json'}
LOADERS = ('fabric', 'forge', 'neoforge', 'quilt')
MAX_MOD_BYTES = 100 * 1024 * 1024
MAX_INSTALLED_JARS = 250
MAX_AUTO_DOWNLOADS = 40
ID_PATTERN = re.compile(r'[a-zA-Z0-9_-]{1,80}\Z')
NAME_PATTERN = re.compile(r'[a-zA-Z0-9_.+()\[\] -]{1,180}\.jar\Z', re.I)


class DependencyError(RuntimeError):
    pass


def detect_loader_and_version(installed_version):
    """Return (Minecraft version, loader), or ('', '') for vanilla/unknown."""
    value = str(installed_version or '').lower()
    loader = re.search(r'(?<![a-z])(neoforge|fabric|forge|quilt)(?![a-z])', value)
    game = re.search(r'(?<!\d)1\.\d+(?:\.\d+)?(?!\d)', value)
    return (game.group() if game else '', loader.group(1) if loader else '')


def _sha512(path):
    digest = hashlib.sha512()
    with path.open('rb') as fd:
        for chunk in iter(lambda: fd.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _valid_identifier(value):
    return isinstance(value, str) and bool(ID_PATTERN.fullmatch(value))


def _get_json(endpoint, *, params=None, opener=None, unknown_ok=False):
    url = API + endpoint
    if params:
        url += '?' + urllib.parse.urlencode(params)
    try:
        with (opener or urllib.request.urlopen)(urllib.request.Request(url, headers=HEADERS), timeout=18) as response:
            if response.geturl().split('?', 1)[0].startswith(API + '/') is False:
                raise DependencyError('Nieprawidłowe przekierowanie Modrinth API.')
            raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise DependencyError('Zbyt duża odpowiedź Modrinth.')
            return json.loads(raw.decode('utf-8'))
    except urllib.error.HTTPError as exc:
        if unknown_ok and exc.code == 404:
            return None
        raise DependencyError(f'Modrinth API: HTTP {exc.code}.') from exc
    except (OSError, ValueError) as exc:
        raise DependencyError(f'Nie można połączyć się z Modrinth: {exc}') from exc


def _candidate_jar(version):
    files = version.get('files') or []
    valid = [f for f in files if isinstance(f, dict) and isinstance(f.get('filename'), str)
             and NAME_PATTERN.fullmatch(f['filename'])
             and f.get('file_type') not in ('sources-jar', 'dev-jar', 'javadoc-jar')]
    file = next((f for f in valid if f.get('primary')), valid[0] if valid else None)
    if not file:
        raise DependencyError('Nie znaleziono pliku .jar wymaganej biblioteki.')
    sha = (file.get('hashes') or {}).get('sha512', '').lower()
    size = file.get('size')
    url = file.get('url', '')
    parsed = urllib.parse.urlparse(url)
    if not re.fullmatch(r'[a-f0-9]{128}', sha) or type(size) is not int or not 1 <= size <= MAX_MOD_BYTES:
        raise DependencyError('Błędna suma SHA-512 lub rozmiar pliku zależności.')
    if parsed.scheme != 'https' or parsed.hostname != 'cdn.modrinth.com' or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise DependencyError('Pobieranie zależności dozwolone wyłącznie z CDN Modrinth.')
    return {'filename': file['filename'], 'url': url, 'sha512': sha, 'size': size,
            'project_id': version['project_id'], 'version_id': version['id'],
            'name': version.get('name', file['filename'])}


def _compatible(version, mc_version, loader):
    return isinstance(version, dict) and mc_version in version.get('game_versions', []) and loader in version.get('loaders', [])


def _resolve_dependency(ref, mc_version, loader, opener):
    version_id = ref.get('version_id')
    project_id = ref.get('project_id')
    if version_id:
        if not _valid_identifier(version_id):
            raise DependencyError('Błędny identyfikator wersji zależności.')
        v = _get_json('/version/' + version_id, opener=opener)
        if not _compatible(v, mc_version, loader):
            raise DependencyError('Wymagana wersja zależności jest niezgodna z Minecraft/loaderem: ' + version_id)
        return v
    if not _valid_identifier(project_id):
        raise DependencyError('Zależność nie ma identyfikatora Modrinth i wymaga instalacji ręcznej: '
                              + str(ref.get('file_name') or '?'))
    versions = _get_json('/project/' + project_id + '/version', params={
        'loaders': json.dumps([loader]), 'game_versions': json.dumps([mc_version]),
        'include_changelog': 'false'}, opener=opener)
    if not isinstance(versions, list) or not versions:
        raise DependencyError('Brak zgodnego wydania wymaganej zależności: ' + project_id)
    release = next((v for v in versions if v.get('version_type') == 'release'), versions[0])
    if not _compatible(release, mc_version, loader):
        raise DependencyError('Nieprawidłowa zgodność wymaganej zależności: ' + project_id)
    return release


def _safe_mod_folder(game_dir):
    root = Path(game_dir)
    folder = root / 'mods'
    if root.is_symlink() or folder.is_symlink():
        raise DependencyError('Folder gry lub mods jest dowiązaniem symbolicznym.')
    if folder.exists() and not folder.is_dir():
        raise DependencyError('Ścieżka mods nie jest folderem.')
    return folder


def plan_missing_dependencies(game_dir, mc_version, loader, *, opener=None, progress=None):
    """Return missing Modrinth JAR metadata; leave the filesystem unchanged."""
    if not re.fullmatch(r'1\.\d+(?:\.\d+)?', str(mc_version)) or loader not in LOADERS:
        raise DependencyError('Wybierz zgodną wersję Minecraft i loader.')
    folder = _safe_mod_folder(game_dir)
    if not folder.is_dir():
        return [], 0, 0
    jars = [p for p in folder.iterdir() if p.is_file() and not p.is_symlink() and p.suffix.lower() == '.jar']
    if len(jars) > MAX_INSTALLED_JARS:
        raise DependencyError('Zbyt wiele modów w folderze (limit: 250).')
    if not jars:
        return [], 0, 0
    known = {}
    unknown = 0
    for p in jars:
        if p.stat().st_size > MAX_MOD_BYTES:
            raise DependencyError('Mod przekracza limit 100 MB: ' + p.name)
        if progress:
            progress('Sprawdzanie: ' + p.name)
        version = _get_json('/version_file/' + _sha512(p), params={'algorithm': 'sha512'}, opener=opener, unknown_ok=True)
        if isinstance(version, dict) and _valid_identifier(version.get('project_id')):
            if not _compatible(version, mc_version, loader):
                raise DependencyError('Mod nie pasuje do wersji Minecraft lub loadera: ' + p.name)
            known[version['project_id']] = version
        else:
            unknown += 1
    # Only the installed Modrinth versions need to be examined. Non-Modrinth
    # .jar mods are never removed or modified.
    queue = list(known.values())
    planned = {}
    considered = set()
    occupied = {p.name.casefold() for p in jars}
    while queue:
        version = queue.pop(0)
        version_id = version.get('id')
        if version_id in considered:
            continue
        considered.add(version_id)
        for dep in version.get('dependencies') or []:
            if not isinstance(dep, dict) or dep.get('dependency_type') != 'required':
                continue
            project_id = dep.get('project_id')
            version_id = dep.get('version_id')
            if project_id in known or project_id in planned:
                # Already installed means satisfied for non-pinned requirements.
                if version_id and project_id in known and known[project_id].get('id') != version_id:
                    raise DependencyError('Konflikt wersji wymaganej biblioteki: ' + str(project_id))
                if version_id and project_id in planned and planned[project_id]['version_id'] != version_id:
                    raise DependencyError('Konflikt wersji wymaganej biblioteki: ' + str(project_id))
                continue
            resolved = _resolve_dependency(dep, mc_version, loader, opener)
            resolved_id = resolved.get('project_id')
            if not _valid_identifier(resolved_id):
                raise DependencyError('Zależność nie ma prawidłowego Project ID.')
            if resolved_id in known:
                if version_id and known[resolved_id].get('id') != version_id:
                    raise DependencyError('Konflikt wymaganej wersji: ' + resolved_id)
                continue
            if resolved_id in planned:
                if version_id and planned[resolved_id]['version_id'] != resolved.get('id'):
                    raise DependencyError('Sprzeczne wersje zależności: ' + resolved_id)
                continue
            item = _candidate_jar(resolved)
            if item['filename'].casefold() in occupied:
                raise DependencyError('Plik zależności już istnieje z inną zawartością: ' + item['filename'])
            occupied.add(item['filename'].casefold())
            planned[resolved_id] = item
            if len(planned) > MAX_AUTO_DOWNLOADS:
                raise DependencyError('Przekroczono limit 40 automatycznie pobieranych zależności.')
            queue.append(resolved)
    return list(planned.values()), len(known), unknown


def _download_verified(item, folder, *, opener=None):
    request = urllib.request.Request(item['url'], headers=HEADERS)
    with tempfile.NamedTemporaryFile(dir=folder, suffix='.minevora-part', delete=False) as output:
        temp = Path(output.name)
        try:
            h = hashlib.sha512()
            size = 0
            with (opener or urllib.request.urlopen)(request, timeout=60) as response:
                url = urllib.parse.urlparse(response.geturl())
                if url.scheme != 'https' or url.hostname != 'cdn.modrinth.com' or url.username or url.password or url.port not in (None, 443):
                    raise DependencyError('Niedozwolone przekierowanie pobierania moda.')
                for chunk in iter(lambda: response.read(128 * 1024), b''):
                    size += len(chunk)
                    if size > MAX_MOD_BYTES or size > item['size']:
                        raise DependencyError('Plik zależności przekroczył deklarowany rozmiar.')
                    output.write(chunk)
                    h.update(chunk)
            if size != item['size'] or h.hexdigest() != item['sha512']:
                raise DependencyError('SHA-512 lub rozmiar zależności nie jest poprawny: ' + item['filename'])
            return temp
        except Exception:
            temp.unlink(missing_ok=True)
            raise


def install_missing_dependencies(game_dir, mc_version, loader, *, opener=None, progress=None):
    """Return {installed, examined, unrecognized}; rollback new files on errors."""
    items, known, unknown = plan_missing_dependencies(game_dir, mc_version, loader,
                                                        opener=opener, progress=progress)
    if not items:
        return {'installed': [], 'examined': known, 'unrecognized': unknown}
    folder = _safe_mod_folder(game_dir)
    folder.mkdir(parents=True, exist_ok=True)
    staged = []
    installed = []
    try:
        for index, item in enumerate(items, 1):
            if progress:
                progress(f'Pobieranie zależności {index}/{len(items)}: {item["name"]}')
            dest = folder / item['filename']
            if dest.exists() or dest.is_symlink():
                raise DependencyError('Plik pojawił się podczas pobierania: ' + dest.name)
            staged.append((_download_verified(item, folder, opener=opener), dest))
        for temp, dest in staged:
            if dest.exists() or dest.is_symlink():
                raise DependencyError('Plik pojawił się podczas instalacji: ' + dest.name)
            # Exclusive create: do not overwrite even if another process writes
            # the same filename between the exists() check and the open().
            with dest.open('xb') as out, temp.open('rb') as src:
                installed.append(dest)
                for chunk in iter(lambda: src.read(1024 * 1024), b''):
                    out.write(chunk)
        if progress:
            progress(f'Zainstalowano {len(installed)} wymaganych modów.')
        return {'installed': [p.name for p in installed], 'examined': known, 'unrecognized': unknown}
    except Exception:
        for dest in installed:
            dest.unlink(missing_ok=True)
        raise
    finally:
        for temp, _ in staged:
            temp.unlink(missing_ok=True)
