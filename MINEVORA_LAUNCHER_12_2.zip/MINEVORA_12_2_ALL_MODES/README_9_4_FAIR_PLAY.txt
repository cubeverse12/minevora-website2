MINEVORA 9.4 — FAIR PLAY (PANEL MODERATORA)
=========================================

NOWOSCI
- Nowa zakladka "🛡 Fair Play" w lewym menu launchera oraz skrot na stronie glownej.
- Lokalne profile graczy (nick, opcjonalnie UUID Minecraft Java).
- Reczne wpisy o banach: nazwa serwera, status aktywny/wygasly/cofniety, powod, numer raportu.
- Recznie zglaszane powiazania kont (MULTIKONTA); nigdy nie stwierdzamy ich automatycznie.
- Reczne raporty sygnalow antycheat: do sprawdzenia / wyjasniony / zamkniety.
- Czytelny panel podsumowania: liczba wszystkich/aktywnych banow w lokalnej bazie,
  liczba serwerow wymienionych przy banach, zgloszone powiazania i otwarte sygnaly.
- Wyszukiwanie graczy, szczegoly pochodzenia raportow, usuwanie wpisow i profili.
- Automatyczny zapis w %USERPROFILE%\.minevora\fairplay_notes.json.
- Wyglad spójny z MINEVORA (ciemny granat i fiolet).

JAK ZAINSTALOWAC NA WINDOWS 11
1. Zamknij stary launcher.
2. Rozpakuj ZIP do NOWEGO folderu (zachowaj cala zawartosc folderu).
3. Uruchom INSTALUJ_ZALEZNOSCI.bat, jezeli nie masz zainstalowanych bibliotek.
4. Uruchom URUCHOM_MINEVORA.bat.
5. W lewym menu kliknij "🛡 Fair Play".
6. Kliknij "+ Dodaj gracza", a potem "+ Nowy raport".

UWAGA — ZAKRES DZIALANIA
- To narzedzie DO WEWNETRZNYCH notatek moderacyjnych. Brak bazy wszystkich banow w Minecraft.
- Wszystkie raporty to WPISY RECZNE. Launcher nie weryfikuje ich niezaleznie i nie pobiera
  informacji o banach z innych sieci. Samo wskazanie "sprawdzone lokalnie" to deklaracja.
- Nie ma analizy IP, identyfikatorow urzadzen ani automatycznego wykrywania multikont.
- Nie ma wiarygodnego „prawdopodobienstwa oszukiwania” w %. Panel zlicza otwarte sygnaly,
  ale nie przesadza o winie i nie wykonuje automatycznych banow.
- Nalezy uzywac tylko uprawnionych danych administracyjnych i umożliwiac odwolania.
- Nie przechowuj adresow IP, prywatnych danych, haseł ani dowodow zawierajacych dane osobowe.
- Zgromadzone notatki pozostaja lokalne; kopia zapasowa i usuniecie pliku lezy po stronie uzytkownika.
- Do automatycznego pobierania zdarzen z oficjalnych lub partnerskich serwerow
  wymagany bylby BEZPIECZNY backend i plugin serwerowy z uprawnieniami oraz zgoda operatorow.
- Nowa wersja zachowuje MINEVORA 9.3 PvP Arena, rangi tworcow, HUD i dotychczasowe funkcje.
- Przetestowano logike raportow i skladnie, ale nie mozna bylo uruchomic GUI na Windows w tym srodowisku.
