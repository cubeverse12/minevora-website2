@echo off
cd /d "%~dp0"
title MINEVORA - instalacja bibliotek
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Instalacja nie powiodla sie. Sprawdz wersje Pythona i polaczenie z internetem.
) else (
  echo.
  echo Biblioteki zainstalowane. Uruchom URUCHOM_MINEVORA.bat
)
pause
