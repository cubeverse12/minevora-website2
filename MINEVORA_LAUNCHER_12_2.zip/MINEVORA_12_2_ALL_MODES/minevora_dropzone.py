"""Accessible drag-and-drop input for MINEVORA's local Marketplace.

Files are only selected here: save/copy happens after the user confirms the form.
"""
from pathlib import Path
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog
from minevora_assets import accepted_suffixes, validate_asset, ASSET_SUFFIXES


class AssetDropZone(QFrame):
    fileSelected = Signal(str)

    def __init__(self, category_provider, *, thumbnail=False, before_validate=None, parent=None):
        super().__init__(parent)
        self.category_provider = category_provider
        self.thumbnail = thumbnail
        self.before_validate = before_validate
        self._path = ''
        self.setObjectName('assetDropZone')
        self.setAcceptDrops(True)
        self.setMinimumHeight(103 if thumbnail else 139)
        self.setStyleSheet("""
            QFrame#assetDropZone {background:#151b37;border:2px dashed #8a70d2;
                border-radius:16px;}
            QFrame#assetDropZone[dragging="true"] {background:#332657;border:2px solid #dfb4ff;}
            QLabel {color:#f2e7ff;background:transparent;border:0;}
            QPushButton {background:#4d3a85;border:1px solid #aa89e8;
                border-radius:9px;padding:8px 12px;font-weight:700;}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16,12,16,12)
        layout.setSpacing(5)
        first = QHBoxLayout()
        self.preview = QLabel('🖼' if thumbnail else '📦')
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setFixedSize(44,44)
        self.preview.setStyleSheet('font-size:25px;')
        first.addWidget(self.preview)
        text_column=QVBoxLayout()
        self.head = QLabel('Upuść miniaturę tutaj' if thumbnail else 'PRZECIĄGNIJ TUTAJ SWÓJ PLIK')
        self.head.setStyleSheet('font-weight:800;font-size:14px;color:#f9eeff;')
        self.head.setWordWrap(True)
        text_column.addWidget(self.head)
        self.note=QLabel('PNG, JPG lub WebP • opcjonalne' if thumbnail else 'Rig, Blender, Blockbench lub paczka ZIP')
        self.note.setWordWrap(True)
        self.note.setStyleSheet('font-size:11px;color:#b8abd9;')
        text_column.addWidget(self.note)
        first.addLayout(text_column,1)
        layout.addLayout(first)
        actions=QHBoxLayout()
        self.pick_btn=QPushButton('📁  Wybierz obraz' if thumbnail else '📁  Wybierz plik z komputera')
        self.pick_btn.clicked.connect(self.browse)
        actions.addWidget(self.pick_btn)
        self.clear_btn=QPushButton('✕  Usuń')
        self.clear_btn.clicked.connect(self.clear)
        self.clear_btn.setEnabled(False)
        actions.addWidget(self.clear_btn)
        actions.addStretch()
        layout.addLayout(actions)
        self.feedback=QLabel('')
        self.feedback.setWordWrap(True)
        self.feedback.setStyleSheet('font-size:11px;color:#ffb1b7;')
        layout.addWidget(self.feedback)
        if thumbnail:
            self.setMinimumHeight(133)

    def path(self):
        return self._path

    def browse(self):
        category = 'miniatura' if self.thumbnail else self.category_provider()
        allowed = accepted_suffixes(category)
        if not self.thumbnail:
            allowed = tuple(sorted(set(allowed) | ASSET_SUFFIXES))
        filter_text = 'Obsługiwane pliki ('+' '.join('*'+ext for ext in allowed)+')'
        filename, _ = QFileDialog.getOpenFileName(self, 'Wybierz miniaturę' if self.thumbnail else 'Wybierz projekt', '', filter_text+';;Wszystkie pliki (*)')
        if filename:
            self.set_file(filename)

    def set_file(self, filename):
        path = Path(filename)
        try:
            if not path.is_file():
                raise ValueError('Można dodać tylko jeden istniejący plik (nie cały folder).')
            if self.before_validate:
                self.before_validate(path)
            validate_asset(path, 'miniatura' if self.thumbnail else self.category_provider())
            if self.thumbnail:
                image=QPixmap(str(path))
                if image.isNull():
                    raise ValueError('Nie udało się odczytać obrazu. Wybierz poprawny PNG/JPG/WebP.')
            self._path = str(path)
            self.head.setText('✓  '+path.name)
            self.note.setText(self._size_label(path))
            if self.thumbnail:
                self.preview.setPixmap(image.scaled(44,44,Qt.KeepAspectRatio,Qt.SmoothTransformation))
            else:
                self.preview.setText('✅')
            self.clear_btn.setEnabled(True)
            self.feedback.setText('')
            self.fileSelected.emit(self._path)
            return True
        except (OSError, ValueError) as exc:
            self.feedback.setText('⚠ '+str(exc))
            return False

    @staticmethod
    def _size_label(path):
        return f'{path.suffix.lower()}  •  {path.stat().st_size/1024/1024:.1f} MB  •  gotowe do dodania'

    def clear(self):
        self._path = ''
        self.head.setText('Upuść miniaturę tutaj' if self.thumbnail else 'PRZECIĄGNIJ TUTAJ SWÓJ PLIK')
        self.note.setText('PNG, JPG lub WebP • opcjonalne' if self.thumbnail else 'Rig, Blender, Blockbench lub paczka ZIP')
        self.preview.setPixmap(QPixmap())
        self.preview.setText('🖼' if self.thumbnail else '📦')
        self.clear_btn.setEnabled(False)
        self.feedback.setText('')
        self.fileSelected.emit('')

    def refresh_category(self):
        if self._path:
            try:
                validate_asset(self._path, 'miniatura' if self.thumbnail else self.category_provider())
            except (ValueError,OSError):
                self.clear()
                self.feedback.setText('Zmieniono kategorię. Wybierz plik pasujący do nowej kategorii.')

    def _local_urls(self, event):
        data = event.mimeData()
        if not data or not data.hasUrls():
            return []
        return [u.toLocalFile() for u in data.urls() if u.isLocalFile()]

    def dragEnterEvent(self,event):
        files=self._local_urls(event)
        if len(files)==1 and len(event.mimeData().urls())==1:
            event.acceptProposedAction()
            self.setProperty('dragging',True)
            self.style().unpolish(self);self.style().polish(self)
        else:
            event.ignore()

    def dragLeaveEvent(self,event):
        self.setProperty('dragging',False)
        self.style().unpolish(self);self.style().polish(self)
        event.accept()

    def dropEvent(self,event):
        self.setProperty('dragging',False)
        self.style().unpolish(self);self.style().polish(self)
        files=self._local_urls(event)
        if len(files)!=1 or len(event.mimeData().urls())!=1:
            self.feedback.setText('Przeciągnij tylko jeden plik z komputera.')
            event.ignore()
            return
        if self.set_file(files[0]):
            event.acceptProposedAction()
        else:
            event.ignore()
