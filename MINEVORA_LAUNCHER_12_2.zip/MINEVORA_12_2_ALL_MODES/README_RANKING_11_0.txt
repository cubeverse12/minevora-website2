MINEVORA 11.0 — RANKING GRACZY

Nowa pozycja „🏆 Ranking” w menu. Dwa widoki: XP twórców i wygrane PvP.
Wyniki pochodzą z lokalnego pliku %USERPROFILE%\.minevora\ranking_local.json.
Możesz ręcznie dodać wpis albo zaimportować własny zapisany XP i PvP.
Kliknij „Eksport na stronę” i zapisz plik ranking.json.
Prześlij go do folderu strony zawierającego ranking.html.
Po zmianie wyników powtórz eksport; nie ma automatycznej synchronizacji.
Bez weryfikacji serwerowej wyniki są tylko demonstracyjne.
Przed publicznym eksportem uzyskaj zgodę zainteresowanych graczy.

Instalacja: uruchom URUCHOM_MINEVORA.bat w rozpakowanym folderze.
Zachowaj %USERPROFILE%\.minevora (dane, Marketplace i postęp).
Testy GUI na Windows nadal wymagane.
