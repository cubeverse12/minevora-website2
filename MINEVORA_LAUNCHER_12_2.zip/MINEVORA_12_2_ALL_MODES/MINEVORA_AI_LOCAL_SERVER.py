"""Optional OpenAI-powered MINEVORA helper, local-only and opt-in.

Requires: pip install openai
Set OPENAI_API_KEY in your PRIVATE local environment (never commit it).
Use MINEVORA_AI_ENDPOINT=http://127.0.0.1:8767/ask on the SAME PC.
This is a development demo. For a public launcher use a secured backend,
user authentication, quotas, moderation and privacy safeguards.
"""
import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class Handler(BaseHTTPRequestHandler):
    last_request = 0.0
    def do_POST(self):
        if self.path != '/ask':
            self.send_error(404); return
        if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            self.send_error(415); return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<2 or size>5500: self.send_error(413); return
            payload=json.loads(self.rfile.read(size))
            query=payload.get('question','')
            if not isinstance(query,str) or not 1<=len(query)<=2500: self.send_error(400);return
            if time.monotonic()-Handler.last_request<2: self.send_error(429);return
            Handler.last_request=time.monotonic()
            from openai import OpenAI
            client=OpenAI(api_key=os.environ['OPENAI_API_KEY'],timeout=20.0)
            response=client.responses.create(model=os.getenv('MINEVORA_AI_MODEL','gpt-4.1-mini'),
                instructions='You are a concise Polish/English support assistant for the MINEVORA Minecraft Java launcher. Never request passwords, tokens, private keys, or unnecessary personal data. Do not pretend to access the game or user computer.',
                input=query,max_output_tokens=350)
            answer=response.output_text
            body=json.dumps({'answer':answer},ensure_ascii=False).encode('utf-8')
            self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        except Exception:
            body=json.dumps({'answer':'Backend AI nie odpowiedział. Sprawdź konfigurację i logi na swoim komputerze.'}).encode('utf-8')
            self.send_response(503);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass

if __name__=='__main__':
    if not os.getenv('OPENAI_API_KEY'):
        raise SystemExit('Brak OPENAI_API_KEY. Bez niego korzystaj z lokalnego pomocnika offline.')
    print('MINEVORA AI local server: http://127.0.0.1:8767/ask')
    ThreadingHTTPServer(('127.0.0.1',8767),Handler).serve_forever()
