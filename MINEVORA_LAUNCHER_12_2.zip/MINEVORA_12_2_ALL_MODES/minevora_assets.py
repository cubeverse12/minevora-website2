"""Safe-ish local 3D asset handling for MINEVORA's offline demo marketplace.

No uploads, archive extraction, execution, online publishing or automatic installs.
"""
import json
import shutil
import zipfile
from pathlib import Path
from uuid import UUID

MODEL_CATEGORIES = ('Rigi Minecraft', 'Modele Blender', 'Modele Blockbench')
FORMAT_BY_CATEGORY = {
    'Rigi Minecraft': ('.bbmodel', '.blend', '.json', '.fbx', '.glb', '.gltf', '.zip'),
    'Modele Blender': ('.blend', '.obj', '.fbx', '.glb', '.gltf', '.zip'),
    'Modele Blockbench': ('.bbmodel', '.json', '.obj', '.glb', '.gltf', '.zip'),
}
ASSET_SUFFIXES = frozenset(s for choices in FORMAT_BY_CATEGORY.values() for s in choices)
LEGACY_SUFFIXES = frozenset(('.zip', '.schem', '.schematic', '.litematic', '.mcworld', '.jar', '.png', '.json', '.mcpack'))
IMAGE_SUFFIXES = frozenset(('.png', '.jpg', '.jpeg', '.webp'))
ASSETS_DIR = Path.home() / '.minevora' / 'market_assets'
MAX_FILE_SIZE = 128 * 1024 * 1024
MAX_IMAGE_SIZE = 12 * 1024 * 1024


def accepted_suffixes(category):
    """Return ordered suffixes for the file-picker and validation."""
    if category in FORMAT_BY_CATEGORY:
        return FORMAT_BY_CATEGORY[category]
    if category == 'miniatura':
        return tuple(sorted(IMAGE_SUFFIXES))
    return tuple(sorted(LEGACY_SUFFIXES | ASSET_SUFFIXES))


def _json_asset(path, suffix):
    if path.stat().st_size > 24 * 1024 * 1024:
        raise ValueError('Plik projektu JSON jest za duży (limit 24 MB).')
    try:
        with path.open('r', encoding='utf-8-sig') as stream:
            content = json.load(stream)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('Nieprawidłowy JSON w projekcie modelu.') from exc
    if not isinstance(content, dict):
        raise ValueError('Projekt modelu powinien mieć strukturę JSON (obiekt).')
    if suffix == '.bbmodel' and not ('elements' in content or 'outliner' in content or 'meta' in content):
        raise ValueError('To nie wygląda na projekt Blockbench (.bbmodel).')
    if suffix == '.gltf' and not isinstance(content.get('asset'), dict):
        raise ValueError('To nie wygląda na model glTF.')
    if suffix == '.json' and not any(k in content for k in ('minecraft:geometry', 'geometry', 'bones', 'elements', 'parent', 'textures')):
        raise ValueError('Nie znaleziono geometrii Minecraft / Blockbench w JSON.')


def _check_zip(path):
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.infolist()
            if len(names) > 2500:
                raise ValueError('Archiwum zawiera zbyt wiele elementów.')
            if sum(info.file_size for info in names) > 700 * 1024 * 1024:
                raise ValueError('Archiwum jest zbyt duże po rozpakowaniu (limit 700 MB).')
            for info in names:
                item = info.filename.replace('\\', '/')
                if item.startswith('/') or '..' in item.split('/'):
                    raise ValueError('Archiwum zawiera niebezpieczną ścieżkę pliku.')
    except (zipfile.BadZipFile, zipfile.LargeZipFile) as exc:
        raise ValueError('Nieprawidłowe archiwum ZIP.') from exc


def validate_asset(filename, category):
    """Checks file availability, extensions and basic file signatures. Does not execute files."""
    path = Path(filename).expanduser()
    if not path.is_file():
        raise ValueError('Wybrany plik nie istnieje.')
    ext = path.suffix.casefold()
    if ext not in accepted_suffixes(category):
        raise ValueError('Format ' + (ext or '(brak)') + ' nie pasuje do kategorii „' + str(category) + '”. Dozwolone: ' + ', '.join(accepted_suffixes(category)))
    size = path.stat().st_size
    if size == 0:
        raise ValueError('Plik jest pusty.')
    if size > (MAX_IMAGE_SIZE if category == 'miniatura' else MAX_FILE_SIZE):
        raise ValueError('Plik jest za duży (limit 12 MB dla miniatur, 128 MB dla projektów).')
    with path.open('rb') as stream:
        header = stream.read(24)
    if category == 'miniatura':
        if ext == '.png' and not header.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Plik PNG nie ma poprawnej sygnatury.')
        if ext in ('.jpg', '.jpeg') and not header.startswith(b'\xff\xd8\xff'):
            raise ValueError('Plik JPEG nie ma poprawnej sygnatury.')
        if ext == '.webp' and not (header.startswith(b'RIFF') and header[8:12] == b'WEBP'):
            raise ValueError('Plik WebP nie ma poprawnej sygnatury.')
    if ext == '.blend' and not header.startswith(b'BLENDER'):
        raise ValueError('Nie rozpoznano pliku Blender (.blend).')
    if ext == '.glb' and not header.startswith(b'glTF'):
        raise ValueError('Nie rozpoznano pliku GLB.')
    if ext in ('.bbmodel', '.gltf', '.json') and category in MODEL_CATEGORIES:
        _json_asset(path, ext)
    if ext == '.zip':
        _check_zip(path)
    return ext


def store_project_asset(project_id, source_file, source_image, category):
    """Copies files to user's MINEVORA storage. Call before committing listing JSON.

    Returns paths usable across launcher restarts. On errors it deletes the new copy.
    """
    safe_id = str(UUID(str(project_id)))
    file_path = Path(source_file).expanduser() if source_file else None
    image_path = Path(source_image).expanduser() if source_image else None
    if file_path:
        validate_asset(file_path, category)
    if image_path:
        validate_asset(image_path, 'miniatura')
    target = ASSETS_DIR / safe_id
    if target.exists():
        raise ValueError('Projekt o takim identyfikatorze już istnieje.')
    try:
        target.mkdir(parents=True, exist_ok=False)
        stored = {'file': '', 'image': ''}
        if file_path:
            output = target / ('project' + file_path.suffix.lower())
            shutil.copy2(file_path, output)
            stored['file'] = str(output)
        if image_path:
            output = target / ('preview' + image_path.suffix.lower())
            shutil.copy2(image_path, output)
            stored['image'] = str(output)
        return stored
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        raise


def remove_project_asset(project_id):
    """Only removes own managed copies, never an arbitrary user-supplied file."""
    try:
        safe_id = str(UUID(str(project_id)))
    except (ValueError, TypeError, AttributeError):
        return
    shutil.rmtree(ASSETS_DIR / safe_id, ignore_errors=True)
