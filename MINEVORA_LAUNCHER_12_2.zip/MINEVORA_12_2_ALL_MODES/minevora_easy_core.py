"""Searchable feature catalogue for MINEVORA 10.7 EASY.

No GUI dependencies; safe to test without PySide6 or Minecraft.
"""
import unicodedata

CATEGORY_NAMES = ['Wszystkie', 'Gra i mody', 'Twórczość', 'Społeczność', 'Bezpieczeństwo', 'Narzędzia']
FEATURES = (
 {'category':'Gra i mody','title':'Minecraft — wybór wersji','description':'Wybierz wersję, profil i uruchom grę.','method':'instances'},
 {'category':'Gra i mody','title':'Zainstaluj Minecraft','description':'Wybierz stabilną wersję Minecraft Java.','method':'install_version'},
 {'category':'Gra i mody','title':'Zaloguj Microsoft','description':'Połącz legalne konto Minecraft przez oficjalne logowanie OAuth.','method':'login'},
 {'category':'Gra i mody','title':'Mody — Modrinth','description':'Szukaj i instaluj kompatybilne dodatki Minecraft.','method':'mods'},
 {'category':'Gra i mody','title':'Modpacki','description':'Sprawdź dostępne informacje o modpackach. Pełna instalacja jeszcze niedostępna.','method':'modpacks'},
 {'category':'Gra i mody','title':'Aktualizacje modów','description':'Sprawdź zgodne wersje i wykonaj kopie plików.','method':'mod_updates_dialog'},
 {'category':'Gra i mody','title':'Nakładka HUD','description':'Włącz licznik czasu gry i ustaw wygląd HUD. FPS wymagają moda.','method':'overlay_settings_dialog'},
 {'category':'Twórczość','title':'Marketplace','description':'Przeglądaj lokalne mapy, budowle, modele i rigi.','method':'market'},
 {'category':'Twórczość','title':'Dodaj projekt','description':'Przeciągnij plik Blender, Blockbench lub mapę.','method':'market_add_listing'},
 {'category':'Twórczość','title':'Moja biblioteka','description':'Znajdź zapisane i ulubione projekty.','method':'market_library'},
 {'category':'Twórczość','title':'Rangi twórcy i bonus XP ×2','description':'Odbieraj nagrody demo MVC i włącz mnożnik XP.','method':'creator_page'},
 {'category':'Twórczość','title':'Skiny Minecraft','description':'Otwórz edytor i podgląd skinów 3D.','method':'skins'},
 {'category':'Społeczność','title':'MINEVORA Together','description':'Hosting ze znajomymi przez oficjalny Essential, zapisywane serwery i screeny.','method':'together'},
 {'category':'Społeczność','title':'Serwery','description':'Zobacz panel serwerów Minecraft.','method':'servers'},
 {'category':'Społeczność','title':'Ranking graczy','description':'Lokalny ranking XP twórców i wygranych PvP. Eksport do strony HTML.','method':'leaderboard'},
 {'category':'Społeczność','title':'PvP Arena','description':'Tryby Sword, Crystal, Axe i dziennik treningów.','method':'pvp'},
 {'category':'Społeczność','title':'Czat MINEVORA','description':'Pokaż rozmowy i zgłoszenia użytkowników.','method':'chat'},
 {'category':'Społeczność','title':'Discord Hub','description':'Połącz aktywność Rich Presence i odwiedź społeczność.','method':'discord_page'},
 {'category':'Społeczność','title':'Discord — tickety','description':'Otwórz lokalny instalator prywatnych zgłoszeń.','method':'open_discord_tickets_tool'},
 {'category':'Społeczność','title':'Discord — język kanałów','description':'Zmień nazwy kanałów Discord PL ↔ EN.','method':'open_discord_language_tool'},
 {'category':'Bezpieczeństwo','title':'Profile graczy / Fair Play','description':'Wyszukaj gracza, sprawdź lokalne bany, zgłoszenia multikont, kolejkę Guard i rozpatrz raporty.','method':'fairplay'},
 {'category':'Bezpieczeństwo','title':'Panel reklam','description':'Zarządzaj lokalnymi banerami i zgłoszeniami sponsorów.','method':'ads_page'},
 {'category':'Narzędzia','title':'MINEVORA AI','description':'Pomoc offline, opcjonalny prywatny serwer AI.','method':'ai_page'},
 {'category':'Narzędzia','title':'Kopia zapasowa','description':'Zabezpiecz projekty i dane przed zmianą komputera.','method':'open_backup_tool'},
 {'category':'Narzędzia','title':'Diagnostyka błędów','description':'Sprawdź wersję Pythona i biblioteki, zapisz raport.','method':'show_logs'},
 {'category':'Narzędzia','title':'Ustawienia','description':'Język, wygląd, czat, nakładka i zaawansowane opcje.','method':'settings'},
 {'category':'Narzędzia','title':'Statystyki','description':'Zobacz lokalne liczniki i status profilu.','method':'stats'},
)
NAV_INDEX_TO_GROUP = {
 0:0, 1:1, 2:2, 3:2, 4:7, 5:7, 6:3, 7:7,
 8:7, 9:9, 10:7, 11:6, 12:7, 13:7, 14:4, 15:7,
 16:7, 17:7, 18:7, 19:5, 99:7,
}

def fold_text(value):
 text = unicodedata.normalize('NFKD', str(value).casefold().translate(str.maketrans({'ł':'l', 'Ł':'l', 'ø':'o', 'æ':'ae'})))
 return ''.join(c for c in text if not unicodedata.combining(c))

def filter_features(query='', category='Wszystkie', features=FEATURES):
 query = fold_text(query.strip())
 terms = query.split()
 return [item for item in features if (category in ('', 'Wszystkie') or item['category']==category)
         and all(term in fold_text(' '.join((item['title'],item['description'],item['category']))) for term in terms)]

def navigation_group(index):
 return NAV_INDEX_TO_GROUP.get(index, 6)


def version_sort_key(version):
 """Sort installed versions numerically (1.21 > 1.9), then by name."""
 import re
 name=str(version)
 match=re.search(r'(?<![0-9])(?:1\.)?([0-9]+)\.([0-9]+)(?:\.([0-9]+))?',name)
 if name.startswith('1.'):
  # regular Minecraft versions; unlike lexicographic sorting this handles 1.21.x
  parts=[int(x) for x in re.findall(r'\d+',name)[:3]]
 else:
  parts=[int(x) for x in (match.groups() if match else ()) if x is not None]
 parts=(parts+[0,0,0])[:3]
 release=not any(word in name.casefold() for word in ('snapshot','pre','rc','beta','alpha'))
 return (*parts, int(release), name.casefold())


def sanitize_preferences(raw):
 """Preserve known extra preferences while preventing broken JSON values crashing UI."""
 if not isinstance(raw,dict):return {}
 data=dict(raw)
 ranges={'font_size':(11,18,13),'chat_interval':(3,30,4),
         'hud_size':(10,18,12),'hud_opacity':(20,100,78)}
 for key,(minimum,maximum,default) in ranges.items():
  if key not in data:continue
  try:
   if isinstance(data[key],bool):raise ValueError('boolean')
   value=int(data[key]);data[key]=max(minimum,min(maximum,value))
  except (ValueError,TypeError,OverflowError):data[key]=default
 if data.get('motion_mode','smooth') not in ('smooth','eco','off'):data['motion_mode']='smooth'
 if data.get('language','pl') not in ('pl','en'):data['language']='pl'
 if data.get('theme','Fantasy') not in ('Fantasy','Szmaragdowy','Niebieski','Różowy'):data['theme']='Fantasy'
 for key in ('chat_visible','animations','auto_mod_updates','auto_install_missing_mods','hud_enabled'):
  if key in data and not isinstance(data[key],bool):data[key]=key in ('animations','hud_enabled')
 return data
