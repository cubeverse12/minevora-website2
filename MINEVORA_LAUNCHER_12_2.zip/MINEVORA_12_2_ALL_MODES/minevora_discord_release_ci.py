"""Run by GitHub Actions when a GitHub Release is published."""
import json
import os
from pathlib import Path
from minevora_discord_announcements_core import build_announcement, post_webhook


def main():
    webhook = os.getenv('MINEVORA_DISCORD_WEBHOOK', '')
    if not webhook:
        raise SystemExit('Missing GitHub Actions secret: MINEVORA_DISCORD_WEBHOOK')
    event_path = os.getenv('GITHUB_EVENT_PATH', '')
    if not event_path:
        raise SystemExit('Brak GITHUB_EVENT_PATH (uruchom z GitHub Actions).')
    obj = json.loads(Path(event_path).read_text(encoding='utf-8'))
    release = obj.get('release') or {}
    if obj.get('action') != 'published' or release.get('draft'):
        print('No published GitHub Release — skipped.')
        return
    if release.get('prerelease'):
        print('Pre-release — skipped.')
        return
    version = str(release.get('tag_name', '')).strip().lstrip('vV')[:40]
    title = str(release.get('name') or 'Nowa aktualizacja')[:180]
    notes = str(release.get('body') or 'Nowa wersja launchera MINEVORA jest już dostępna.')[:3600]
    url = str(release.get('html_url') or '')
    payload = build_announcement(version, title, notes, url)
    message_id = post_webhook(webhook, payload)
    print('Discord announcement published successfully' + (' (id: '+message_id+')' if message_id else ''))


if __name__ == '__main__':
    main()
