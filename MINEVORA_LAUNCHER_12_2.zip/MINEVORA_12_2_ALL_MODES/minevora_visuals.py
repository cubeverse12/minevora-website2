"""MINEVORA 10.9 — pure, unit-testable animation policy and timing helpers."""

MOTION_MODES = ('smooth','eco','off')


def valid_motion_mode(raw):
    """Prefer a safe default even for corrupted settings."""
    return raw if isinstance(raw,str) and raw in MOTION_MODES else 'smooth'


def animation_interval_ms(mode):
    """An adaptive cap on repaint frequency, not a promise of GPU FPS."""
    return {'smooth':50,'eco':125,'off':0}[valid_motion_mode(mode)]


def should_animate(enabled, visible, minimized, mode):
    return bool(enabled and visible and not minimized and valid_motion_mode(mode)!='off')


def ease_out_cubic(progress):
    t=max(0.,min(1.,float(progress)))
    return 1-(1-t)**3
