"""MINEVORA 9.3: local PvP training hub, saved servers, Java status ping.

No gameplay statistics are read from Minecraft. All match results are entered by
users and local PvP titles are demonstrational, not competitive rankings.
"""
import json
import re
import socket
import time
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QMessageBox, QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

DATA_PATH = Path.home() / '.minevora' / 'pvp_training.json'
MODES = [
    ('⚔', 'Sword PvP', 'Walki mieczem, wyczucie dystansu i celowanie.', '1.8.9 / nowsze'),
    ('💎', 'Crystal PvP 1v1', 'Pojedynek 1v1 z kryształami Endu — serwer MINEVORA.', '1.21.4'),
    ('💠', 'Crystal PvP FFA', 'Rundowa walka 2–12 graczy — serwer MINEVORA.', '1.21.4'),
    ('🪓', 'Axe PvP', 'Tarcze, topory i dobre wykorzystanie czasu ataku.', '1.16.5+'),
    ('🏹', 'UHC', 'Przetrwanie, łuk i strategiczne pojedynki.', 'Zależnie od serwera'),
    ('🛏', 'BedWars', 'Drużyny, obrona łóżka i walka na wyspach.', 'Zależnie od serwera'),
    ('☁', 'SkyWars', 'Pojedynki na latających wyspach i szybkie decyzje.', 'Zależnie od serwera'),
]
TIERS = [(0, 'Nowicjusz', '◇', '#88a7cf'), (5, 'Wojownik', '⚔', '#51cdd1'),
         (20, 'Weteran', '✦', '#b68cff'), (50, 'Mistrz Areny', '♛', '#f6c45f'),
         (100, 'Legenda PvP', '★', '#ff8da4')]


def initial_data():
    return {'servers': [], 'stats': {'kills': 0, 'deaths': 0, 'wins': 0, 'losses': 0,
                                    'training_seconds': 0}, 'history': [], 'selected_mode': 'Sword PvP'}


def load_data(path=DATA_PATH):
    try:
        raw = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return initial_data()
    if not isinstance(raw, dict):
        return initial_data()
    result = initial_data()
    stats = raw.get('stats', {})
    if isinstance(stats, dict):
        for key in result['stats']:
            val = stats.get(key, 0)
            if type(val) is int and 0 <= val <= 10**9:
                result['stats'][key] = val
    servers = raw.get('servers', [])
    if isinstance(servers, list):
        for item in servers[:150]:
            if isinstance(item, dict) and isinstance(item.get('name'), str) and isinstance(item.get('address'), str):
                try:
                    parse_address(item['address'])
                except ValueError:
                    continue
                result['servers'].append({'id': str(item.get('id', uuid4().hex))[:80],
                                          'name': item['name'][:64], 'address': item['address'][:255],
                                          'mode': str(item.get('mode', 'Sword PvP'))[:64]})
    history = raw.get('history', [])
    if isinstance(history, list):
        result['history'] = [x for x in history[-200:] if isinstance(x, dict) and x.get('kind') in ('kills', 'deaths', 'wins', 'losses')]
    if raw.get('selected_mode') in [m[1] for m in MODES]:
        result['selected_mode'] = raw['selected_mode']
    return result


def save_data(data, path=DATA_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def parse_address(address):
    """Validate host[:port] for a Minecraft Java server (no scheme)."""
    address = address.strip()
    if not address or len(address) > 255 or any(c.isspace() for c in address) or '/' in address or '@' in address:
        raise ValueError('Podaj adres serwera, np. serwer.example:25565 (bez https://).')
    if address.startswith('['):
        match = re.fullmatch(r'\[([0-9a-fA-F:.]+)\](?::([0-9]{1,5}))?', address)
        if not match:
            raise ValueError('Niepoprawny adres IPv6.')
        host, raw_port = match.groups()
    else:
        if address.count(':') > 1:
            raise ValueError('Adres IPv6 wpisz w nawiasach kwadratowych: [::1]:25565')
        parts = address.rsplit(':', 1)
        host = parts[0]
        raw_port = parts[1] if len(parts) == 2 else None
        if raw_port == '':
            raise ValueError('Po dwukropku podaj numer portu.')
        if not re.fullmatch(r'[A-Za-z0-9_.\-]+', host):
            raise ValueError('Adres serwera zawiera niedozwolone znaki.')
    if not host or host.startswith('-'):
        raise ValueError('Niepoprawna nazwa serwera.')
    port = int(raw_port) if raw_port else 25565
    if not 1 <= port <= 65535:
        raise ValueError('Port musi być w zakresie 1–65535.')
    return host, port


def _encode_varint(number):
    result = bytearray()
    while True:
        b = number & 0x7f
        number >>= 7
        result.append(b | (0x80 if number else 0))
        if not number:
            return bytes(result)


def _decode_varint(sock):
    num = 0
    for shift in range(0, 35, 7):
        b = sock.recv(1)
        if not b:
            raise ConnectionError('Serwer zamknął połączenie.')
        num |= (b[0] & 0x7f) << shift
        if not (b[0] & 0x80):
            return num
    raise ValueError('Nieprawidłowa odpowiedź serwera.')


def _read_exact(sock, count):
    data = bytearray()
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        if not chunk:
            raise ConnectionError('Połączenie zostało zamknięte.')
        data.extend(chunk)
    return bytes(data)


def query_java_status(address, timeout=3):
    """Uses vanilla Java status handshake; requires no additional dependencies."""
    host, port = parse_address(address)
    start = time.monotonic()
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        host_bytes = host.encode('utf-8')
        handshake = (_encode_varint(0) + _encode_varint(760) +
                     _encode_varint(len(host_bytes)) + host_bytes + port.to_bytes(2, 'big') + _encode_varint(1))
        sock.sendall(_encode_varint(len(handshake)) + handshake + b'\x01\x00')
        length = _decode_varint(sock)
        if length < 2 or length > 1048576:
            raise ValueError('Zbyt duża lub nieprawidłowa odpowiedź serwera.')
        packet = _read_exact(sock, length)
    from io import BytesIO
    buffer = BytesIO(packet)
    def read_varint():
        number = 0
        for shift in range(0, 35, 7):
            raw = buffer.read(1)
            if not raw:
                raise ValueError('Niekompletna odpowiedź serwera.')
            number |= (raw[0] & 0x7f) << shift
            if raw[0] & 0x80 == 0:
                return number
        raise ValueError('Niepoprawny pakiet.')
    if read_varint() != 0:
        raise ValueError('Niespodziewany typ pakietu serwera.')
    json_length = read_varint()
    if json_length < 2 or json_length > 1048576:
        raise ValueError('Nieprawidłowy format danych serwera.')
    doc = json.loads(buffer.read(json_length).decode('utf-8'))
    if not isinstance(doc, dict):
        raise ValueError('Nieprawidłowy format statusu.')
    players = doc.get('players', {}) if isinstance(doc.get('players', {}), dict) else {}
    version = doc.get('version', {}) if isinstance(doc.get('version', {}), dict) else {}
    return {'latency_ms': round((time.monotonic() - start) * 1000),
            'online': players.get('online', '?'), 'max_players': players.get('max', '?'),
            'version': str(version.get('name', 'nieznana'))[:80]}


class ServerStatusWorker(QThread):
    result = Signal(str, object)
    failed = Signal(str, str)

    def __init__(self, server_id, address, parent=None):
        super().__init__(parent)
        self.server_id = server_id
        self.address = address

    def run(self):
        try:
            self.result.emit(self.server_id, query_java_status(self.address))
        except (OSError, ValueError, ConnectionError, TimeoutError, json.JSONDecodeError) as exc:
            self.failed.emit(self.server_id, str(exc))


def label(content, size=12, bold=False, muted=False):
    el = QLabel(content)
    el.setWordWrap(True)
    el.setStyleSheet(f'background:transparent;color:{"#b9c6e4" if muted else "#fcf5ff"};font-size:{size}px;font-weight:{700 if bold else 400}')
    return el


def button(name, callback, main=False):
    b = QPushButton(name)
    b.setObjectName('primary' if main else 'normal')
    b.clicked.connect(callback)
    b.setCursor(Qt.PointingHandCursor)
    return b


class ServerDialog(QDialog):
    def __init__(self, data=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MINEVORA • Serwer PvP')
        self.resize(450,260)
        root = QVBoxLayout(self)
        root.addWidget(label('DODAJ SERWER PVP' if not data else 'EDYTUJ SERWER PVP', 20, True))
        form = QFormLayout()
        self.name = QLineEdit((data or {}).get('name', ''))
        self.name.setMaxLength(64)
        self.name.setPlaceholderText('np. Serwer treningowy')
        self.address = QLineEdit((data or {}).get('address', ''))
        self.address.setMaxLength(255)
        self.address.setPlaceholderText('play.example.net:25565')
        self.mode = QComboBox()
        self.mode.addItems([m[1] for m in MODES])
        self.mode.setCurrentText((data or {}).get('mode', 'Sword PvP'))
        form.addRow('Nazwa:', self.name)
        form.addRow('Adres Minecraft Java:', self.address)
        form.addRow('Tryb:', self.mode)
        root.addLayout(form)
        root.addWidget(label('Podawaj tylko adres serwera. Launcher nie wysyła tam danych logowania.', 11, muted=True))
        actions = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        actions.button(QDialogButtonBox.Save).setText('Zapisz serwer')
        actions.accepted.connect(self.validate)
        actions.rejected.connect(self.reject)
        root.addWidget(actions)

    def validate(self):
        try:
            if not self.name.text().strip():
                raise ValueError('Wpisz nazwę serwera.')
            parse_address(self.address.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'Serwer PvP', str(exc))
            return
        self.accept()

    def value(self):
        return {'name': self.name.text().strip(), 'address': self.address.text().strip(),
                'mode': self.mode.currentText()}


class PvpHub(QWidget):
    stats_changed = Signal()
    """PvP page for the launcher; no Minecraft mod or game telemetry is implied."""

    def __init__(self, launch_game, open_instances, get_version, parent=None):
        super().__init__(parent)
        self.data = load_data()
        self.launch_game = launch_game
        self.open_instances = open_instances
        self.get_version = get_version
        self._session_start = None
        self._workers = []
        self._statuses = {}
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh_session)
        self._timer.start(1000)
        self.build_ui()
        self.refresh_all()

    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():self._timer.start(1000)
        self.refresh_session()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        root.addWidget(scroll)
        content = QWidget()
        v = QVBoxLayout(content)
        v.setContentsMargins(27, 25, 28, 32)
        v.setSpacing(17)
        scroll.setWidget(content)
        v.addWidget(label('⚔  MINEVORA PVP ARENA', 28, True))
        v.addWidget(label('Twoje centrum treningu PvP — tryby walki, zapisane serwery i osobiste statystyki.', 12, muted=True))
        intro = QFrame()
        intro.setObjectName('hero')
        row = QHBoxLayout(intro)
        row.setContentsMargins(22, 17, 22, 17)
        left = QVBoxLayout()
        left.addWidget(label('✦  LOKALNA RANGA PVP', 12, True))
        self.rank = label('', 24, True)
        left.addWidget(self.rank)
        self.rank_hint = label('', 11, muted=True)
        left.addWidget(self.rank_hint)
        self.rank_progress = QProgressBar()
        self.rank_progress.setRange(0, 100)
        self.rank_progress.setFixedHeight(20)
        self.rank_progress.setStyleSheet('QProgressBar {border:1px solid #8269ac;border-radius:9px;background:#11162e;color:white;text-align:center} QProgressBar::chunk {background:#9974f2;border-radius:7px}')
        left.addWidget(self.rank_progress)
        row.addLayout(left, 1)
        right = QVBoxLayout()
        self.kdr = label('', 18, True)
        right.addWidget(self.kdr)
        self.wlr = label('', 14, True)
        right.addWidget(self.wlr)
        row.addLayout(right)
        v.addWidget(intro)
        v.addWidget(label('✦  TRYBY PVP', 20, True))
        grid = QGridLayout()
        grid.setSpacing(10)
        self.mode_buttons = {}
        for i, (glyph, title, detail, version) in enumerate(MODES):
            panel = QFrame()
            panel.setObjectName('card')
            lay = QVBoxLayout(panel)
            lay.setContentsMargins(15, 12, 15, 12)
            lay.setSpacing(6)
            lay.addWidget(label(f'{glyph}  {title}', 16, True))
            lay.addWidget(label(detail, 11, muted=True))
            lay.addWidget(label('Wersja: ' + version, 10, muted=True))
            b = button('Wybierz tryb', lambda checked=False, value=title: self.select_mode(value))
            self.mode_buttons[title] = b
            lay.addWidget(b)
            grid.addWidget(panel, i // 2, i % 2)
        v.addLayout(grid)
        self.mode_selected = label('', 12, True)
        v.addWidget(self.mode_selected)
        self.game_version = label('', 11, muted=True)
        v.addWidget(self.game_version)
        v.addWidget(label('🌐  TWOJE SERWERY PVP', 20, True))
        servers = QFrame()
        servers.setObjectName('panel')
        sl = QVBoxLayout(servers)
        self.server_list = QListWidget()
        self.server_list.setMinimumHeight(136)
        self.server_list.setMaximumHeight(210)
        self.server_list.currentRowChanged.connect(self.refresh_selected_server)
        sl.addWidget(self.server_list)
        controls = QHBoxLayout()
        for title, fn in [('＋ Dodaj', self.add_server), ('✎ Edytuj', self.edit_server),
                          ('✕ Usuń', self.delete_server), ('◉ Sprawdź ping', self.ping_server)]:
            controls.addWidget(button(title, fn))
        sl.addLayout(controls)
        self.server_status = label('Wybierz serwer, aby sprawdzić jego status.', 11, muted=True)
        self.server_status.setTextFormat(Qt.PlainText)
        sl.addWidget(self.server_status)
        shortcuts = QHBoxLayout()
        shortcuts.addWidget(button('📋 Kopiuj adres', self.copy_server))
        shortcuts.addWidget(button('▶  Kopiuj adres i uruchom Minecraft', self.launch_selected, True))
        sl.addLayout(shortcuts)
        sl.addWidget(label('Minecraft otwiera się standardowo. Adres jest kopiowany do schowka — wklej go w Multiplayer → Połącz bezpośrednio. Status dotyczy serwerów Java.', 10, muted=True))
        v.addWidget(servers)
        v.addWidget(label('📊  TRENING I STATYSTYKI', 20, True))
        training = QFrame()
        training.setObjectName('panel')
        tl = QVBoxLayout(training)
        self.session_display = label('', 14, True)
        tl.addWidget(self.session_display)
        session_row = QHBoxLayout()
        self.start_button = button('▶ Rozpocznij trening', self.start_session, True)
        self.stop_button = button('■ Zakończ trening', self.stop_session)
        session_row.addWidget(self.start_button)
        session_row.addWidget(self.stop_button)
        tl.addLayout(session_row)
        stats_grid = QGridLayout()
        self.stat_labels = {}
        for i, (key, title) in enumerate([('kills', '⚔ Trafienia eliminujące'), ('deaths', '☠ Zgony'),
                                           ('wins', '🏆 Wygrane walki'), ('losses', '◇ Przegrane walki')]):
            cell = QFrame()
            cell.setObjectName('card')
            cl = QVBoxLayout(cell)
            self.stat_labels[key] = label('0', 24, True)
            cl.addWidget(self.stat_labels[key])
            cl.addWidget(label(title, 11, muted=True))
            cl.addWidget(button('＋1', lambda checked=False, k=key: self.add_stat(k)))
            stats_grid.addWidget(cell, i // 2, i % 2)
        tl.addLayout(stats_grid)
        misc = QHBoxLayout()
        misc.addWidget(button('↶ Cofnij ostatni wpis', self.undo_stat))
        misc.addWidget(button('▣ Otwórz instancje', self.open_instances))
        tl.addLayout(misc)
        tl.addWidget(label('Statystyki wpisujesz ręcznie. Nie są odczytywane z serwerów i nie przyznają MineCoins ani oficjalnych rang. To prywatny dziennik treningowy.', 11, muted=True))
        v.addWidget(training)
        v.addWidget(label('✦  WSKAZÓWKI TRENINGOWE', 20, True))
        tips = QFrame()
        tips.setObjectName('panel')
        tip_v = QVBoxLayout(tips)
        tip_v.addWidget(label('Ćwicz celowanie, ruch i wyczucie dystansu. Zapisuj wyniki, aby obserwować postępy. Graj fair — bez niedozwolonych wspomagaczy.', 12))
        v.addWidget(tips)
        v.addStretch()

    def persist(self, previous=None):
        try:
            save_data(self.data)
            self.stats_changed.emit()
            return True
        except OSError as exc:
            if previous is not None:
                self.data = previous
            QMessageBox.warning(self, 'Zapis PvP', f'Nie można zapisać danych: {exc}')
            self.refresh_all()
            return False

    def select_mode(self, mode):
        before = deepcopy(self.data)
        self.data['selected_mode'] = mode
        if self.persist(before):
            self.refresh_all()

    def selected_server(self):
        index = self.server_list.currentRow()
        if 0 <= index < len(self.data['servers']):
            return self.data['servers'][index]
        return None

    def refresh_servers(self, selected_id=None):
        if selected_id is None:
            selected = self.selected_server()
            selected_id = selected['id'] if selected else None
        self.server_list.blockSignals(True)
        self.server_list.clear()
        selection = -1
        for i, server in enumerate(self.data['servers']):
            self.server_list.addItem(f"⚔  {server['name']}  •  {server['address']}  •  {server['mode']}")
            if server['id'] == selected_id:
                selection = i
        if selection < 0 and self.data['servers']:
            selection = 0
        self.server_list.setCurrentRow(selection)
        self.server_list.blockSignals(False)
        self.refresh_selected_server()

    def refresh_selected_server(self, *_):
        server = self.selected_server()
        if server is None:
            self.server_status.setText('Brak zapisanych serwerów. Dodaj własny adres, aby sprawdzić ping.')
            return
        status = self._statuses.get(server['id'])
        self.server_status.setText(status or f"{server['name']} • status jeszcze niesprawdzony")

    def add_server(self):
        dialog = ServerDialog(parent=self)
        dialog.mode.setCurrentText(self.data['selected_mode'])
        if dialog.exec() != QDialog.Accepted:
            return
        if len(self.data['servers']) >= 150:
            QMessageBox.warning(self, 'PvP', 'Maksymalnie 150 serwerów.')
            return
        before = deepcopy(self.data)
        server = dialog.value()
        server['id'] = uuid4().hex
        self.data['servers'].append(server)
        if self.persist(before):
            self.refresh_servers(server['id'])

    def edit_server(self):
        server = self.selected_server()
        if not server:
            return
        dialog = ServerDialog(server, parent=self)
        if dialog.exec() != QDialog.Accepted:
            return
        before = deepcopy(self.data)
        server.update(dialog.value())
        self._statuses.pop(server['id'], None)
        if self.persist(before):
            self.refresh_servers(server['id'])

    def delete_server(self):
        server = self.selected_server()
        if not server:
            return
        if QMessageBox.question(self, 'Usuń serwer PvP', f"Usunąć serwer „{server['name']}” z listy?") != QMessageBox.Yes:
            return
        before = deepcopy(self.data)
        self.data['servers'] = [x for x in self.data['servers'] if x['id'] != server['id']]
        if self.persist(before):
            self.refresh_servers()

    def ping_server(self):
        server = self.selected_server()
        if not server:
            QMessageBox.information(self, 'PvP', 'Najpierw dodaj i wybierz serwer.')
            return
        if any(w.isRunning() and w.server_id == server['id'] for w in self._workers):
            return
        self._statuses[server['id']] = 'Sprawdzanie statusu serwera…'
        self.refresh_selected_server()
        worker = ServerStatusWorker(server['id'], server['address'], self)
        worker.result.connect(self.ping_ok)
        worker.failed.connect(self.ping_error)
        worker.finished.connect(lambda w=worker: self.cleanup_worker(w))
        self._workers.append(worker)
        worker.start()

    def cleanup_worker(self, worker):
        if worker in self._workers:
            self._workers.remove(worker)
        worker.deleteLater()

    def ping_ok(self, server_id, result):
        self._statuses[server_id] = (f"● ONLINE  •  Ping {result['latency_ms']} ms  •  "
                                     f"Gracze {result['online']}/{result['max_players']}  •  "
                                     f"Wersja {result['version']}")
        self.refresh_selected_server()

    def ping_error(self, server_id, message):
        self._statuses[server_id] = f'○ Brak odpowiedzi Java Status: {message[:180]}'
        self.refresh_selected_server()

    def copy_server(self):
        server = self.selected_server()
        if not server:
            QMessageBox.information(self, 'PvP', 'Wybierz serwer do skopiowania.')
            return False
        QApplication.clipboard().setText(server['address'])
        self.server_status.setText(f"Adres {server['address']} skopiowany. Wklej go w Multiplayer.")
        return True

    def launch_selected(self):
        if self.copy_server():
            self.launch_game()

    def start_session(self):
        if self._session_start is not None:
            return
        self._session_start = time.monotonic()
        self.refresh_session()

    def stop_session(self):
        if self._session_start is None:
            return
        seconds = max(1, round(time.monotonic() - self._session_start))
        before = deepcopy(self.data)
        self.data['stats']['training_seconds'] += seconds
        self._session_start = None
        self.persist(before)
        self.refresh_all()

    def refresh_session(self):
        total = self.data['stats']['training_seconds']
        active = self._session_start is not None
        if active:
            total += int(time.monotonic() - self._session_start)
        hours, rest = divmod(total, 3600)
        minutes, seconds = divmod(rest, 60)
        self.session_display.setText(f"⏱  Czas treningu: {hours:02d}:{minutes:02d}:{seconds:02d}" +
                                     ('  ● TRENING TRWA' if active else ''))
        self.start_button.setEnabled(not active)
        self.stop_button.setEnabled(active)

    def add_stat(self, kind):
        if kind not in ('kills', 'deaths', 'wins', 'losses'):
            return
        before = deepcopy(self.data)
        self.data['stats'][kind] += 1
        self.data['history'].append({'kind': kind, 'at': datetime.now().isoformat(timespec='seconds')})
        self.data['history'] = self.data['history'][-200:]
        if self.persist(before):
            self.refresh_all()

    def undo_stat(self):
        history = self.data['history']
        if not history:
            QMessageBox.information(self, 'PvP', 'Brak ostatnich wpisów do cofnięcia.')
            return
        before = deepcopy(self.data)
        item = history.pop()
        kind = item['kind']
        self.data['stats'][kind] = max(0, self.data['stats'][kind] - 1)
        if self.persist(before):
            self.refresh_all()

    def refresh_all(self):
        stats = self.data['stats']
        wins = stats['wins']
        idx = max(i for i, (required, *_rest) in enumerate(TIERS) if wins >= required)
        required, title, badge, color = TIERS[idx]
        self.rank.setText(f'{badge}  {title}')
        self.rank.setStyleSheet(f'background:transparent;color:{color};font-size:24px;font-weight:800')
        if idx + 1 < len(TIERS):
            next_wins = TIERS[idx + 1][0]
            self.rank_progress.setValue(round((wins - required) / (next_wins - required) * 100))
            self.rank_hint.setText(f'{wins}/{next_wins} wygranych do następnej rangi')
        else:
            self.rank_progress.setValue(100)
            self.rank_hint.setText('Najwyższa lokalna ranga odblokowana')
        kd = stats['kills'] / max(1, stats['deaths'])
        winrate = (100 * wins / (wins + stats['losses'])) if (wins + stats['losses']) else 0
        self.kdr.setText(f'K/D: {kd:.2f}')
        self.wlr.setText(f'Wygrane: {wins}  •  Skuteczność: {winrate:.0f}%')
        self.mode_selected.setText('Wybrany tryb: ' + self.data['selected_mode'])
        self.game_version.setText('Aktywna wersja w launcherze: ' + str(self.get_version() or 'brak — wybierz instalację Minecraft'))
        for name, b in self.mode_buttons.items():
            b.setText('✓  Wybrany' if name == self.data['selected_mode'] else 'Wybierz tryb')
            b.setEnabled(name != self.data['selected_mode'])
        for key, el in self.stat_labels.items():
            el.setText(str(stats[key]))
        self.refresh_servers()
        self.refresh_session()
