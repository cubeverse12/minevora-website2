package pl.minevora.guard;

public final class GuardMathSelfTest {
    public static void main(String[] args) {
        require(close(GuardMath.horizontalSpeed(0, 0, 5, 0, 250), 1.0), "speed 5 blocks / 5 ticks");
        require(close(GuardMath.horizontalSpeed(2, 3, 2, 3, 250), 0.0), "stationary");
        require(close(GuardMath.horizontalSpeed(2, 3, 2, 3, 0), 0.0), "bad elapsed");
        require(close(GuardMath.pointToBox(5, 0.5, 0, 0, 0, -1, 1, 1, 1), 4.0), "distance to box edge");
        require(close(GuardMath.pointToBox(0.5, 0.5, 0.5, 0, 0, 0, 1, 1, 1), 0.0), "inside box");
        require(GuardMath.json("a\"\\\n").equals("\"a\\\"\\\\\\n\""), "JSON escaping");
        System.out.println("PASS: 6 GuardMath self-tests");
    }
    private static boolean close(double a, double b) { return Math.abs(a - b) < 0.000001; }
    private static void require(boolean valid, String name) { if (!valid) throw new AssertionError(name); }
}
