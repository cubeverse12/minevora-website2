"""MINEVORA 11.7: Minecraft account skin upload, pixel editor and 3D preview."""
import json
import math
from minevora_skin_core import LAYER_NAMES, AREAS, PRESETS, allowed_pixel, rects_for_layer, generate_preset, flood_fill_points, pixels_on_line, safe_preset_name
from pathlib import Path
from datetime import datetime
from uuid import uuid4
from minevora_skin_upload_qt import SkinUploadWorker
from PySide6.QtCore import Qt, QTimer, QPointF, QRectF, Signal, QUrl
from PySide6.QtGui import QPainter, QColor, QPen, QPolygonF, QImage, QDesktopServices, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFileDialog, QWidget,
    QMessageBox, QCheckBox, QListWidget, QListWidgetItem, QSlider, QFrame, QGridLayout,
    QColorDialog, QComboBox, QInputDialog, QLineEdit, QScrollArea, QSizePolicy
)

SETTINGS_DIR = Path.home() / '.minevora'
RECENT_PATH = SETTINGS_DIR / 'skin_studio_recent.json'
SKINS_EXPORT_DIR = SETTINGS_DIR / 'skins'
CUSTOM_PRESETS_DIR = SETTINGS_DIR / 'skin_presets'

PARTS = [
    (-4,-16,-2,8,8,4, (8,8,8,8),(0,8,8,8),(16,8,8,8),(24,8,8,8),(8,0,8,8),(16,0,8,8)),
    (-4,-8,-2,8,12,4,(20,20,8,12),(16,20,4,12),(28,20,4,12),(32,20,8,12),(20,16,8,4),(28,16,8,4)),
    (-8,-8,-2,4,12,4,(44,20,4,12),(40,20,4,12),(48,20,4,12),(52,20,4,12),(44,16,4,4),(48,16,4,4)),
    (4,-8,-2,4,12,4,(36,52,4,12),(32,52,4,12),(40,52,4,12),(44,52,4,12),(36,48,4,4),(40,48,4,4)),
    (-4,4,-2,4,12,4,(4,20,4,12),(0,20,4,12),(8,20,4,12),(12,20,4,12),(4,16,4,4),(8,16,4,4)),
    (0,4,-2,4,12,4,(20,52,4,12),(16,52,4,12),(24,52,4,12),(28,52,4,12),(20,48,4,4),(24,48,4,4)),
]

THEMES = {
    'night': ('#0a1020', '#101a2c', '#7b6cff', '#9fddff'),
    'portal': ('#100d23', '#171432', '#8d63ff', '#f5b8ff'),
    'forest': ('#0d1b19', '#152626', '#54c08b', '#b7ffe2'),
}


def panel_frame():
    box = QFrame()
    box.setObjectName('panel')
    box.setStyleSheet(
        'QFrame#panel{background:#10192c;border:1px solid #2b3e65;border-radius:18px;}'
        'QLabel{background:transparent;color:#f5f7ff}'
    )
    return box


class Figure(QWidget):
    def __init__(self):
        super().__init__()
        self.angle = 0.25
        self.skin = None
        self.cape = None
        self.rotating = True
        self.show_overlays = True
        self.zoom = 1.0
        self.theme = 'night'
        self.setMinimumSize(290, 355)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.step)
        self.timer.start(70)

    def step(self):
        if self.rotating:
            self.angle = (self.angle + 0.045) % (2 * math.pi)
            self.update()

    def set_zoom(self, value):
        self.zoom = max(0.55, min(1.65, float(value)))
        self.update()

    def set_theme(self, name):
        if name in THEMES:
            self.theme = name
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        bg0, bg1, glow, glow2 = THEMES[self.theme]
        p.fillRect(self.rect(), QColor(bg0))
        p.fillRect(0, 0, self.width(), int(self.height() * 0.52), QColor(bg1))

        # decorative glow
        center = QPointF(self.width() * 0.5, self.height() * 0.42)
        for radius, alpha in ((190, 20), (145, 35), (110, 55)):
            p.setBrush(QColor(glow))
            color = QColor(glow)
            color.setAlpha(alpha)
            p.setBrush(color)
            p.drawEllipse(center, radius, radius)
        accent = QColor(glow2)
        accent.setAlpha(60)
        p.setBrush(accent)
        p.drawRoundedRect(18, self.height()-78, self.width()-36, 44, 18, 18)

        scale = min(self.width()/26, self.height()/40) * self.zoom
        cx = self.width()/2
        cy = self.height() * 0.44
        a = self.angle

        def project(x, y, z):
            X = x*math.cos(a) + z*math.sin(a)
            Z = -x*math.sin(a) + z*math.cos(a)
            return QPointF(cx + X*scale, cy + (y - Z*.22) * scale)

        def quad(corners, color):
            p.setPen(Qt.NoPen)
            p.setBrush(color)
            p.drawPolygon(QPolygonF([project(*pt) for pt in corners]))

        faces = []
        for idx, part in enumerate(PARTS):
            x, y, z, w, h, d, *uvs = part
            if self.skin is not None and self.skin.height() == 32 and idx in (3, 5):
                src = PARTS[2 if idx == 3 else 4]
                uvs = src[6:]
            surfaces = [
                ([(x,y,z+d),(x+w,y,z+d),(x+w,y+h,z+d),(x,y+h,z+d)],0),
                ([(x,y,z),(x,y,z+d),(x,y+h,z+d),(x,y+h,z)],1),
                ([(x+w,y,z+d),(x+w,y,z),(x+w,y+h,z),(x+w,y+h,z+d)],2),
                ([(x+w,y,z),(x,y,z),(x,y+h,z),(x+w,y+h,z)],3),
                ([(x,y,z),(x+w,y,z),(x+w,y,z+d),(x,y,z+d)],4),
                ([(x,y+h,z+d),(x+w,y+h,z+d),(x+w,y+h,z),(x,y+h,z)],5),
            ]
            for corners, side in surfaces:
                depth = sum(-px*math.sin(a)+pz*math.cos(a) for px, py, pz in corners)/4
                faces.append((depth, corners, uvs[side], side))
            # 64x64 second layers are separate UV islands and should draw above base.
            overlay_uvs = [
                ((40,8,8,8),(32,8,8,8),(48,8,8,8),(56,8,8,8),(40,0,8,8),(48,0,8,8)),
                ((20,36,8,12),(16,36,4,12),(28,36,4,12),(32,36,8,12),(20,32,8,4),(28,32,8,4)),
                ((44,36,4,12),(40,36,4,12),(48,36,4,12),(52,36,4,12),(44,32,4,4),(48,32,4,4)),
                ((52,52,4,12),(48,52,4,12),(56,52,4,12),(60,52,4,12),(52,48,4,4),(56,48,4,4)),
                ((4,36,4,12),(0,36,4,12),(8,36,4,12),(12,36,4,12),(4,32,4,4),(8,32,4,4)),
                ((4,52,4,12),(0,52,4,12),(8,52,4,12),(12,52,4,12),(4,48,4,4),(8,48,4,4)),
            ]
            if self.show_overlays and self.skin is not None and self.skin.height()==64:
                e=0.15
                xx=x-e; yy=y-e; zz=z-e; ww=w+2*e; hh=h+2*e; dd=d+2*e
                shell=[
                    ([(xx,yy,zz+dd),(xx+ww,yy,zz+dd),(xx+ww,yy+hh,zz+dd),(xx,yy+hh,zz+dd)],0),
                    ([(xx,yy,zz),(xx,yy,zz+dd),(xx,yy+hh,zz+dd),(xx,yy+hh,zz)],1),
                    ([(xx+ww,yy,zz+dd),(xx+ww,yy,zz),(xx+ww,yy+hh,zz),(xx+ww,yy+hh,zz+dd)],2),
                    ([(xx+ww,yy,zz),(xx,yy,zz),(xx,yy+hh,zz),(xx+ww,yy+hh,zz)],3),
                    ([(xx,yy,zz),(xx+ww,yy,zz),(xx+ww,yy,zz+dd),(xx,yy,zz+dd)],4),
                    ([(xx,yy+hh,zz+dd),(xx+ww,yy+hh,zz+dd),(xx+ww,yy+hh,zz),(xx,yy+hh,zz)],5),
                ]
                for corners,side in shell:
                    depth=sum(-px*math.sin(a)+pz*math.cos(a) for px,py,pz in corners)/4
                    faces.append((depth,corners,overlay_uvs[idx][side],side))
        if self.cape is not None:
            corners = [(-5,-8,-2.8),(5,-8,-2.8),(5,8,-2.8),(-5,8,-2.8)]
            depth = sum(-x*math.sin(a)+z*math.cos(a) for x,y,z in corners)/4
            faces.append((depth, corners, (1,1,10,16), 6))
        faces.sort(key=lambda item: item[0])

        for _, corners, uv, side in faces:
            image = self.cape if side == 6 else self.skin
            if image is None:
                fill = QColor('#6b63ff' if side != 4 else '#96baff')
                if side in (1, 3):
                    fill = QColor('#5167c5')
                quad(corners, fill)
                continue
            ux, uy, uw, uh = uv
            for py in range(uh):
                for px in range(uw):
                    if ux+px >= image.width() or uy+py >= image.height():
                        continue
                    color = QColor(image.pixel(ux+px, uy+py))
                    if color.alpha() == 0:
                        continue
                    u0 = px/uw; u1 = (px+1)/uw; v0 = py/uh; v1 = (py+1)/uh
                    def interp(u, v):
                        a0,b0,c0,d0 = corners
                        return tuple(a0[i]*(1-u)*(1-v)+b0[i]*u*(1-v)+c0[i]*u*v+d0[i]*(1-u)*v for i in range(3))
                    quad([interp(u0,v0), interp(u1,v0), interp(u1,v1), interp(u0,v1)], color)

        p.setPen(QColor('#dfe9ff'))
        p.drawText(28, self.height()-48, 'PREMIUM SKIN STUDIO')
        p.end()



class SkinCanvas(QWidget):
    """Pixel-perfect editable Minecraft UV atlas. A stroke is one undo entry."""
    changed = Signal()
    selectedColor = Signal(QColor)
    historyChanged = Signal(bool, bool)
    cursorMoved = Signal(int, int)

    def __init__(self):
        super().__init__()
        self.skin = QImage(64, 64, QImage.Format_RGBA8888)
        self.skin.fill(Qt.transparent)
        self.layer = 'Wszystko'
        self.tool = 'Pędzel'
        self.color = QColor('#6b63ff')
        self.pixel_size = 9
        self.left = 18
        self.top = 48
        self.undo_stack = []
        self.redo_stack = []
        self.dragging = False
        self.last_pixel = None
        self.show_grid = True
        self.setMouseTracking(True)
        self.setCursor(Qt.CrossCursor)
        self.adjust_dimensions()

    def adjust_dimensions(self):
        self.setFixedSize(self.left*2+64*self.pixel_size, self.top+64*self.pixel_size+20)
        self.update()

    def set_scale(self, value):
        self.pixel_size=max(6, min(16, int(value)))
        self.adjust_dimensions()

    def replace_skin(self, image):
        self.skin=image.convertToFormat(QImage.Format_RGBA8888).copy()
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.historyChanged.emit(False, False)
        self.changed.emit()
        self.update()

    def begin_history(self):
        self.undo_stack.append(self.skin.copy())
        if len(self.undo_stack)>35:self.undo_stack.pop(0)
        self.redo_stack.clear()
        self.historyChanged.emit(True, False)

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(self.skin.copy())
            self.skin=self.undo_stack.pop()
            self.historyChanged.emit(bool(self.undo_stack), True)
            self.changed.emit()
            self.update()

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(self.skin.copy())
            self.skin=self.redo_stack.pop()
            self.historyChanged.emit(True, bool(self.redo_stack))
            self.changed.emit()
            self.update()

    def _coord(self, pos):
        x=int((pos.x()-self.left)//self.pixel_size)
        y=int((pos.y()-self.top)//self.pixel_size)
        if 0<=x<64 and 0<=y<self.skin.height():
            return x,y
        return None

    def get_rgba(self,x,y):
        color=self.skin.pixelColor(x,y)
        return color.red(),color.green(),color.blue(),color.alpha()

    def paint_pixel(self,x,y):
        if not allowed_pixel(self.layer,x,y,self.skin.height()):return
        self.skin.setPixelColor(x,y,QColor(0,0,0,0) if self.tool=='Gumka' else self.color)

    def draw_segment(self,a,b):
        for x,y in pixels_on_line(a[0],a[1],b[0],b[1]):self.paint_pixel(x,y)
        self.changed.emit()
        self.update()

    def _bucket(self,x,y):
        color=QColor(0,0,0,0) if self.tool=='Gumka' else self.color
        target=(color.red(),color.green(),color.blue(),color.alpha())
        points=flood_fill_points(self.get_rgba,x,y,target,self.layer,self.skin.height())
        if points:
            self.begin_history()
            for px,py in points:self.skin.setPixelColor(px,py,color)
            self.changed.emit()
            self.update()

    def mousePressEvent(self,event):
        if event.button()!=Qt.LeftButton:return
        pos=self._coord(event.position())
        if pos is None:return
        x,y=pos
        if not allowed_pixel(self.layer,x,y,self.skin.height()):return
        if self.tool=='Pipeta':
            color=self.skin.pixelColor(x,y)
            if color.alpha():
                self.color=color
                self.selectedColor.emit(color)
            return
        if self.tool=='Wypełnienie':
            self._bucket(x,y)
            return
        self.begin_history()
        self.dragging=True
        self.last_pixel=pos
        self.paint_pixel(x,y)
        self.changed.emit()
        self.update()

    def mouseMoveEvent(self,event):
        pos=self._coord(event.position())
        if pos:self.cursorMoved.emit(*pos)
        if not self.dragging or pos is None or self.last_pixel is None:return
        if self.tool not in ('Pędzel','Gumka'):return
        self.draw_segment(self.last_pixel,pos)
        self.last_pixel=pos

    def mouseReleaseEvent(self,event):
        if event.button()==Qt.LeftButton:
            self.dragging=False
            self.last_pixel=None

    def paintEvent(self,event):
        p=QPainter(self)
        p.setRenderHint(QPainter.Antialiasing,False)
        p.fillRect(self.rect(),QColor('#10192c'))
        p.setPen(QColor('#e3ecff'))
        p.drawText(18,26,'ATLAS UV   /   PNG 64 × '+str(self.skin.height()))
        l,t,s=self.left,self.top,self.pixel_size
        # Checkerboard is displayed behind transparent skin pixels.
        for y in range(64):
            for x in range(64):
                p.fillRect(l+x*s,t+y*s,s,s,QColor('#1f2e48' if ((x//4+y//4)%2) else '#34445f'))
        p.setRenderHint(QPainter.SmoothPixmapTransform, False)
        p.drawImage(QRectF(l,t,64*s,self.skin.height()*s),self.skin)
        if self.skin.height()==32:
            p.fillRect(l,t+32*s,64*s,32*s,QColor(10,16,30,190))
            p.setPen(QColor('#d4dbf3'))
            p.drawText(l+16,t+32*s+28,'Starszy format 64×32 — nakładki 64×64 niedostępne')
        # Darken pixels not belonging to the currently editable layer.
        if self.layer!='Wszystko':
            shade=QColor(7,13,28,165)
            for y in range(self.skin.height()):
                for x in range(64):
                    if not allowed_pixel(self.layer,x,y,self.skin.height()):
                        p.fillRect(l+x*s,t+y*s,s,s,shade)
            p.setPen(QPen(QColor('#9ba4ff'),1.5))
            for x0,y0,x1,y1 in rects_for_layer(self.layer):
                if y0<self.skin.height():
                    p.drawRect(l+x0*s,t+y0*s,(x1-x0)*s,(min(y1,self.skin.height())-y0)*s)
        if self.show_grid:
            p.setPen(QPen(QColor(183,203,234,55),0.5))
            for n in range(65):
                p.drawLine(l+n*s,t,l+n*s,t+64*s)
                p.drawLine(l,t+n*s,l+64*s,t+n*s)
            p.setPen(QPen(QColor('#8ba3d6'),1))
            for n in (0,8,16,32,48,64):
                p.drawLine(l+n*s,t,l+n*s,t+64*s)
                p.drawLine(l,t+n*s,l+64*s,t+n*s)
        p.setPen(QPen(QColor('#5b72a4'),2))
        p.drawRect(l,t,64*s,64*s)
        p.end()


class SkinDialog(QDialog):
    """Skin creator: upload happens only after explicit player confirmation."""
    def __init__(self,parent=None,session_getter=None):
        super().__init__(parent)
        self.setWindowTitle('MINEVORA 11.7  •  SKIN CREATOR & UŻYJ W MINECRAFT')
        self.resize(1450,860)
        self.setMinimumSize(1080,680)
        self.current_skin_path=None
        self.session_getter=session_getter or (lambda: None)
        self.skin_upload_worker=None
        self.current_cape_path=None
        self.has_changes=False
        self.accent=QColor('#6b63ff')
        self.setStyleSheet('''
        QDialog{background:#09101d;color:#edf2ff;font-family:'Segoe UI';font-size:12px}
        QLabel{background:transparent;color:#e4ecff}
        QLabel#title{font-size:24px;font-weight:800;color:#ffffff}
        QLabel#sub{font-size:12px;color:#afbfdf}
        QFrame#panel{background:#10192c;border:1px solid #2a3d63;border-radius:18px}
        QPushButton{background:#1b2a46;border:1px solid #34517d;color:#eef3ff;border-radius:10px;padding:9px 12px;font-size:12px;font-weight:700}
        QPushButton:hover{background:#253a60;border-color:#9cafff}
        QPushButton:disabled{color:#627493;background:#10192a;border-color:#25334e}
        QPushButton#primary{background:#6866f2;border:1px solid #c1c5ff;color:#ffffff}
        QPushButton#primary:hover{background:#8986ff}
        QComboBox,QLineEdit,QListWidget{background:#101c34;color:#f6f8ff;border:1px solid #3a5077;border-radius:9px;padding:7px}
        QSlider{background:transparent}
        QCheckBox{color:#e1e8fb}
        QScrollArea{border:0;background:#0d172b}
        QScrollBar:vertical{background:#10192a;width:10px}
        QScrollBar::handle:vertical{background:#5468b7;border-radius:5px}
        QScrollBar:horizontal{background:#10192a;height:10px}
        QScrollBar::handle:horizontal{background:#5468b7;border-radius:5px}
        ''')
        root=QVBoxLayout(self)
        root.setContentsMargins(18,14,18,14)
        root.setSpacing(10)
        title=QLabel('◆  MINEVORA SKIN CREATOR  <span style="color:#9d9cff">11.7</span>')
        title.setObjectName('title')
        root.addWidget(title)
        tagline=QLabel('Rysuj skina  •  podgląd 3D  •  zapisz PNG  •  ustaw jako aktywny skin Minecraft Java')
        tagline.setObjectName('sub')
        root.addWidget(tagline)
        main=QHBoxLayout()
        main.setSpacing(12)
        root.addLayout(main,1)

        # Left side: drawing tools, UV layers and palette.
        toolpanel=panel_frame()
        toolpanel.setMinimumWidth(196)
        toolpanel.setMaximumWidth(232)
        tv=QVBoxLayout(toolpanel)
        tv.setContentsMargins(12,15,12,12)
        tv.setSpacing(9)
        tv.addWidget(self._heading('NARZĘDZIA'))
        self.tools={}
        toolsgrid=QGridLayout()
        toolsgrid.setSpacing(6)
        for i,(name,icon) in enumerate((('Pędzel','✎'),('Gumka','⌫'),('Pipeta','◈'),('Wypełnienie','▣'))):
            b=QPushButton(icon+'  '+name)
            b.clicked.connect(lambda checked=False,n=name:self.select_tool(n))
            toolsgrid.addWidget(b,i//2,i%2)
            self.tools[name]=b
        tv.addLayout(toolsgrid)
        undo_row=QHBoxLayout()
        self.undo_button=self._button('↶ Cofnij',self.undo)
        self.redo_button=self._button('↷ Ponów',self.redo)
        self.undo_button.setEnabled(False);self.redo_button.setEnabled(False)
        undo_row.addWidget(self.undo_button);undo_row.addWidget(self.redo_button)
        tv.addLayout(undo_row)
        tv.addWidget(self._heading('WARSTWA EDYCJI'))
        self.layer=QComboBox()
        self.layer.addItems(LAYER_NAMES)
        self.layer.currentTextChanged.connect(self.select_layer)
        tv.addWidget(self.layer)
        self.layer_explain=QLabel('Edytujesz cały atlas UV.')
        self.layer_explain.setWordWrap(True)
        self.layer_explain.setObjectName('sub')
        tv.addWidget(self.layer_explain)
        tv.addWidget(self._heading('KOLOR'))
        self.color_button=self._button('#6B63FF  •  Wybierz kolor',self.pick_color)
        tv.addWidget(self.color_button)
        swatches=QGridLayout()
        for i,hexval in enumerate(('#6b63ff','#9fddff','#f5b8ff','#f7f9ff','#0c1930','#273b64','#56be9e','#e5bb80','#d7679f','#bfc8dc','#5838a9','#8cc3ff')):
            swatch=QPushButton(' ')
            swatch.setFixedHeight(26)
            swatch.setStyleSheet(f'background:{hexval};border:1px solid #506286;border-radius:7px;')
            swatch.setToolTip(hexval)
            swatch.clicked.connect(lambda checked=False,c=hexval:self.set_color(QColor(c)))
            swatches.addWidget(swatch,i//4,i%4)
        tv.addLayout(swatches)
        tv.addWidget(self._heading('SKALA EDYTORA'))
        self.scale_slider=QSlider(Qt.Horizontal)
        self.scale_slider.setRange(6,16)
        self.scale_slider.setValue(9)
        tv.addWidget(self.scale_slider)
        self.grid_check=QCheckBox('Pokaż siatkę UV')
        self.grid_check.setChecked(True)
        tv.addWidget(self.grid_check)
        tv.addStretch()
        tv.addWidget(self._button('＋ Nowy pusty skin',self.new_blank))
        tv.addWidget(self._button('📂 Wczytaj PNG',self.open_skin))
        save_btn=self._button('↓ Eksportuj PNG',self.export_skin,True)
        tv.addWidget(save_btn)
        main.addWidget(toolpanel)

        # Center: real editable image with scrolling and zoom.
        center=panel_frame()
        cv=QVBoxLayout(center)
        cv.setContentsMargins(10,12,10,12)
        cv.setSpacing(8)
        cv.addWidget(self._heading('EDYTOR SKINA   /   UV 2D'))
        self.canvas=SkinCanvas()
        self.scroll=QScrollArea()
        self.scroll.setWidget(self.canvas)
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignCenter)
        cv.addWidget(self.scroll,1)
        self.position=QLabel('X: —   Y: —    •    Rozmiar: 64×64')
        self.position.setObjectName('sub')
        cv.addWidget(self.position)
        main.addWidget(center,4)

        # Right: 3D character, preset generators, files.
        # Keep every tool reachable on smaller Windows screens.
        right_scroll=QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_widget=QWidget()
        side=QVBoxLayout(right_widget)
        side.setContentsMargins(0,0,0,0)
        side.setSpacing(10)
        main.addWidget(right_scroll,2)
        three=panel_frame()
        vv=QVBoxLayout(three)
        vv.setContentsMargins(12,12,12,10)
        vv.setSpacing(6)
        vv.addWidget(self._heading('PODGLĄD POSTACI 3D'))
        self.figure=Figure()
        vv.addWidget(self.figure,1)
        controls=QHBoxLayout()
        self.rotate_check=QCheckBox('Obracaj')
        self.rotate_check.setChecked(True)
        self.rotate_check.toggled.connect(lambda checked:setattr(self.figure,'rotating',checked))
        controls.addWidget(self.rotate_check)
        self.overlay_check=QCheckBox('Pokaż nakładki')
        self.overlay_check.setChecked(True)
        self.overlay_check.toggled.connect(self.set_overlay_visible)
        controls.addWidget(self.overlay_check)
        vv.addLayout(controls)
        three.setMinimumHeight(365)
        side.addWidget(three,5)

        presetbox=panel_frame()
        pv=QVBoxLayout(presetbox)
        pv.setContentsMargins(12,11,12,12)
        pv.setSpacing(7)
        pv.addWidget(self._heading('GENERATOR PRESETÓW'))
        presetrow=QHBoxLayout()
        self.preset_combo=QComboBox()
        self.preset_combo.addItems(PRESETS)
        presetrow.addWidget(self.preset_combo,1)
        self.accent_btn=self._button('Akcent',self.pick_accent)
        presetrow.addWidget(self.accent_btn)
        pv.addLayout(presetrow)
        pv.addWidget(self._button('✧ Generuj nowy skin',self.generate_current_preset,True))
        row=QHBoxLayout()
        row.addWidget(self._button('Zapisz jako preset',self.save_custom_preset))
        row.addWidget(self._button('Wczytaj preset',self.load_custom_preset))
        pv.addLayout(row)
        side.addWidget(presetbox)

        files=panel_frame()
        fv=QVBoxLayout(files)
        fv.setContentsMargins(12,11,12,12)
        fv.setSpacing(7)
        fv.addWidget(self._heading('PLIKI I HISTORIA'))
        self.info=QLabel('')
        self.info.setObjectName('sub')
        self.info.setWordWrap(True)
        fv.addWidget(self.info)
        file_buttons=QHBoxLayout()
        file_buttons.addWidget(self._button('Pelerynka',self.open_cape))
        file_buttons.addWidget(self._button('Usuń pelerynkę',self.clear_cape))
        fv.addLayout(file_buttons)
        self.recent_list=QListWidget()
        self.recent_list.setToolTip('Dwuklik w plik na liście otwiera skin.')
        self.recent_list.setMaximumHeight(88)
        self.recent_list.itemDoubleClicked.connect(self.open_recent_item)
        fv.addWidget(self.recent_list)
        fv.addWidget(self._button('Otwórz folder skinów',self.open_skin_folder))

        # Account skin upload: player confirms the operation, no automatic sends.
        account=panel_frame()
        av=QVBoxLayout(account)
        av.setContentsMargins(12,11,12,12)
        av.setSpacing(7)
        av.addWidget(self._heading('UŻYJ SKINA W MINECRAFT JAVA'))
        self.skin_account=QLabel('Zaloguj konto Microsoft w MINEVORA, aby ustawić skin.')
        self.skin_account.setWordWrap(True)
        self.skin_account.setObjectName('sub')
        av.addWidget(self.skin_account)
        av.addWidget(QLabel('Model postaci:'))
        self.skin_variant=QComboBox()
        self.skin_variant.addItem('Classic — standardowe ramiona (Steve)', 'classic')
        self.skin_variant.addItem('Slim — węższe ramiona (Alex)', 'slim')
        av.addWidget(self.skin_variant)
        self.skin_use_button=self._button('✓ UŻYJ SKINA W MINECRAFT',self.use_skin_in_minecraft,True)
        self.skin_use_button.setToolTip('Ustaw skin na zalogowanym koncie Minecraft Java Edition')
        av.addWidget(self.skin_use_button)
        av.addWidget(self._button('Zapisz PNG do oficjalnego launchera',self.save_skin_for_official_launcher))
        side.addWidget(account)
        side.addWidget(files)
        right_scroll.setWidget(right_widget)

        # Connect all transformations after the interface is built.
        self.canvas.changed.connect(self.canvas_changed)
        self.canvas.selectedColor.connect(self.set_color)
        self.canvas.historyChanged.connect(self.history_changed)
        self.canvas.cursorMoved.connect(self.show_cursor)
        self.scale_slider.valueChanged.connect(self.canvas.set_scale)
        self.grid_check.toggled.connect(self.set_grid)
        QShortcut(QKeySequence.Undo,self,activated=self.undo)
        QShortcut(QKeySequence.Redo,self,activated=self.redo)
        self.select_tool('Pędzel')
        self.set_color(QColor('#6b63ff'))
        self.canvas.replace_skin(self._from_bytes(generate_preset('Cyber Wilk')))
        self.has_changes=False
        self.refresh_recent_list()
        self.refresh_info()
        self.refresh_account_status()

    @staticmethod
    def _from_bytes(rgba):
        return QImage(rgba,64,64,QImage.Format_RGBA8888).copy()

    @staticmethod
    def _heading(value):
        w=QLabel(value)
        w.setStyleSheet('font-weight:800;color:#c7d2ff;font-size:12px;letter-spacing:1px')
        return w

    @staticmethod
    def _button(label,callback,primary=False):
        button=QPushButton(label)
        if primary:button.setObjectName('primary')
        button.clicked.connect(callback)
        return button

    def show_cursor(self,x,y):
        self.position.setText(f'X: {x}    Y: {y}    •    Rozmiar: 64×{self.canvas.skin.height()}    •    {self.canvas.layer}')

    def select_tool(self,tool):
        self.canvas.tool=tool
        for name,button in self.tools.items():
            button.setStyleSheet('background:#4c5ce0;border:1px solid #aab7ff;' if name==tool else '')

    def select_layer(self,name):
        self.canvas.layer=name
        self.canvas.update()
        self.layer_explain.setText('Malowanie ograniczone do: '+name+'. Niewybrane obszary są przyciemnione.' if name!='Wszystko' else 'Edytujesz cały atlas UV. Wybierz warstwę, aby ograniczyć rysowanie.')

    def set_color(self,color):
        if not isinstance(color,QColor) or not color.isValid():return
        self.canvas.color=color
        self.canvas.tool='Pędzel' if self.canvas.tool=='Pipeta' else self.canvas.tool
        self.color_button.setText(color.name().upper()+'  •  Wybierz kolor')
        self.color_button.setStyleSheet(f'border:2px solid {color.name()};')
        self.select_tool(self.canvas.tool)

    def pick_color(self):
        color=QColorDialog.getColor(self.canvas.color,self,'Wybierz kolor pędzla')
        if color.isValid():self.set_color(color)

    def pick_accent(self):
        color=QColorDialog.getColor(self.accent,self,'Kolor akcentu generatora')
        if color.isValid():
            self.accent=color
            self.accent_btn.setStyleSheet(f'background:{color.name()};color:#ffffff;border:1px solid #c5c8ff')

    def set_grid(self,enabled):
        self.canvas.show_grid=enabled
        self.canvas.update()

    def set_overlay_visible(self,visible):
        self.figure.show_overlays=visible
        self.figure.update()

    def canvas_changed(self):
        self.figure.skin=self.canvas.skin
        self.figure.update()
        self.has_changes=True
        self.refresh_info()

    def history_changed(self,can_undo,can_redo):
        self.undo_button.setEnabled(can_undo)
        self.redo_button.setEnabled(can_redo)

    def undo(self):self.canvas.undo()
    def redo(self):self.canvas.redo()

    def confirm_replace(self):
        if not self.has_changes:return True
        answer=QMessageBox.question(self,'MINEVORA • Niezapisane zmiany',
             'Bieżące zmiany nie zostały wyeksportowane do PNG. Zastąpić skin?',
             QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        return answer==QMessageBox.Yes

    def new_blank(self):
        if not self.confirm_replace():return
        blank=QImage(64,64,QImage.Format_RGBA8888)
        blank.fill(Qt.transparent)
        self.canvas.replace_skin(blank)
        self.current_skin_path=None
        self.has_changes=False
        self.refresh_info()

    def load_skin_file(self,path,confirm=True):
        if confirm and not self.confirm_replace():return False
        image=QImage(path)
        if image.isNull() or (image.width(),image.height()) not in ((64,64),(64,32)):
            QMessageBox.warning(self,'Skin','Wymagany plik PNG 64×64 lub 64×32.')
            return False
        self.canvas.replace_skin(image)
        self.current_skin_path=str(path)
        self.has_changes=False
        self.push_recent(path)
        self.refresh_info()
        return True

    def open_skin(self):
        path,_=QFileDialog.getOpenFileName(self,'Wczytaj skin Minecraft','','Skórki PNG (*.png)')
        if path:self.load_skin_file(path)

    def open_cape(self):
        path,_=QFileDialog.getOpenFileName(self,'Wczytaj pelerynkę','','PNG (*.png)')
        if not path:return
        image=QImage(path)
        if image.isNull() or (image.width(),image.height()) not in ((64,32),(64,64)):
            QMessageBox.warning(self,'Pelerynka','Wymagany PNG 64×32 lub 64×64.')
            return
        self.figure.cape=image.convertToFormat(QImage.Format_RGBA8888)
        self.current_cape_path=path
        self.figure.update()
        self.refresh_info()

    def clear_cape(self):
        self.figure.cape=None
        self.current_cape_path=None
        self.figure.update()
        self.refresh_info()

    def export_skin(self):
        SKINS_EXPORT_DIR.mkdir(parents=True,exist_ok=True)
        default=Path(self.current_skin_path).name if self.current_skin_path else 'minevora_skin.png'
        target,_=QFileDialog.getSaveFileName(self,'Eksportuj skin Minecraft',str(SKINS_EXPORT_DIR/default),'PNG (*.png)')
        if not target:return False
        if not target.lower().endswith('.png'):target+='.png'
        if not self.canvas.skin.save(target,'PNG'):
            QMessageBox.warning(self,'Błąd zapisu','Nie udało się zapisać skina.')
            return False
        self.current_skin_path=target
        self.has_changes=False
        self.push_recent(target)
        self.refresh_info()
        QMessageBox.information(self,'MINEVORA','Skin zapisany jako plik PNG.\n'+target)
        return True

    def generate_current_preset(self):
        if not self.confirm_replace():return
        png=generate_preset(self.preset_combo.currentText(),self.accent.name())
        self.canvas.replace_skin(self._from_bytes(png))
        self.current_skin_path=None
        self.has_changes=True
        self.refresh_info()

    def save_custom_preset(self):
        name,ok=QInputDialog.getText(self,'Zapisz własny preset','Nazwa presetu:')
        if not ok or not name.strip():return
        CUSTOM_PRESETS_DIR.mkdir(parents=True,exist_ok=True)
        target=CUSTOM_PRESETS_DIR/(safe_preset_name(name)+'.png')
        if target.is_file():
            answer=QMessageBox.question(self,'Preset istnieje','Zastąpić zapisany preset?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
            if answer!=QMessageBox.Yes:return
        if not self.canvas.skin.save(str(target),'PNG'):
            QMessageBox.warning(self,'Preset','Nie udało się zapisać presetu.')
            return
        QMessageBox.information(self,'MINEVORA',f'Zapisano własny preset:\n{target.name}')

    def load_custom_preset(self):
        CUSTOM_PRESETS_DIR.mkdir(parents=True,exist_ok=True)
        files=sorted(CUSTOM_PRESETS_DIR.glob('*.png'),key=lambda x:x.name.lower())
        if not files:
            QMessageBox.information(self,'Presety','Nie masz jeszcze własnych presetów. Użyj „Zapisz jako preset”.')
            return
        options=[f.stem for f in files]
        picked,ok=QInputDialog.getItem(self,'Własne presety','Wybierz preset:',options,0,False)
        if ok and picked:
            self.load_skin_file(str(files[options.index(picked)]))

    def refresh_info(self):
        file=Path(self.current_skin_path).name if self.current_skin_path else 'Nowy / niezapisany'
        cape=Path(self.current_cape_path).name if self.current_cape_path else 'Brak'
        mark=' • zmodyfikowany' if self.has_changes else ''
        if hasattr(self,'info'):
            self.info.setText(f'Skin: {file}{mark}\nFormat: 64×{self.canvas.skin.height()}\nPelerynka: {cape}')

    def _load_recent(self):
        try:
            data=json.loads(RECENT_PATH.read_text(encoding='utf8'))
            return [str(item) for item in data if isinstance(item,str) and Path(item).is_file()][:12]
        except (OSError,ValueError,TypeError):return []

    def push_recent(self,path):
        path=str(Path(path))
        items=[x for x in self._load_recent() if x!=path]
        items.insert(0,path)
        SETTINGS_DIR.mkdir(parents=True,exist_ok=True)
        try:RECENT_PATH.write_text(json.dumps(items[:12],ensure_ascii=False,indent=2),encoding='utf8')
        except OSError:pass
        self.refresh_recent_list()

    def refresh_recent_list(self):
        self.recent_list.clear()
        for path in self._load_recent():
            item=QListWidgetItem(Path(path).name)
            item.setData(Qt.UserRole,path)
            item.setToolTip(path)
            self.recent_list.addItem(item)

    def open_recent_item(self,item):
        path=item.data(Qt.UserRole)
        if path:self.load_skin_file(path)

    def open_skin_folder(self):
        SKINS_EXPORT_DIR.mkdir(parents=True,exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(SKINS_EXPORT_DIR)))

    def refresh_account_status(self):
        session=self.session_getter()
        if isinstance(session,dict) and session.get('access_token') and session.get('name'):
            self.skin_account.setText('Konto Minecraft: '+str(session['name'])+'\nSkin zostanie przypisany do tego konta.')
        else:
            self.skin_account.setText('Brak zalogowanego konta Minecraft Java.\nZaloguj się przez Microsoft w launcherze.')

    def _save_snapshot(self):
        """Keep a PNG copy even if the Minecraft service fails to apply it."""
        SKINS_EXPORT_DIR.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        path=SKINS_EXPORT_DIR/('minevora_'+stamp+'_'+uuid4().hex[:6]+'.png')
        if not self.canvas.skin.save(str(path),'PNG'):
            raise OSError('Nie udało się zapisać pliku PNG skina.')
        self.current_skin_path=str(path)
        self.has_changes=False
        self.push_recent(path)
        self.refresh_info()
        return path

    def save_skin_for_official_launcher(self):
        """Always-available offline route for playing with a local skin file."""
        try:
            saved=self._save_snapshot()
        except OSError as exc:
            QMessageBox.warning(self,'MINEVORA • Skin',str(exc))
            return
        QMessageBox.information(self,'MINEVORA • Użyj skina',
             'Skin zapisano do:\n'+str(saved)+'\n\n'
             'W oficjalnym Minecraft Launcher otwórz: Java Edition → Skins → New Skin.\n'
             'Wybierz zapisany plik PNG, model Classic albo Slim, a następnie Save & Use.\n\n'
             'To ustawienie zmieni wygląd Twojej postaci na koncie Java Edition.')
        self.open_skin_folder()

    def use_skin_in_minecraft(self):
        if self.skin_upload_worker and self.skin_upload_worker.isRunning():
            return
        session=self.session_getter()
        if not isinstance(session,dict) or not session.get('access_token') or not session.get('name'):
            QMessageBox.information(self,'MINEVORA • Zaloguj konto',
                 'Najpierw zaloguj konto Microsoft w MINEVORA.\n'
                 'Możesz też użyć opcji „Zapisz PNG do oficjalnego launchera”.')
            self.refresh_account_status()
            return
        username=str(session['name'])
        variant=self.skin_variant.currentData()
        variant_name='Slim (Alex)' if variant=='slim' else 'Classic (Steve)'
        result=QMessageBox.question(self,'MINEVORA • Potwierdź zmianę skina',
               f'Ustawić ten skin na koncie Minecraft Java: {username}?\n\n'
               f'Model: {variant_name}\n\n'
               'Zastąpi to obecny skin tego konta. Wysłana zostanie wyłącznie tekstura PNG '
               'do usługi Minecraft. Zapisz poprzedni skin osobno, jeśli chcesz go zachować.',
               QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if result!=QMessageBox.Yes:
            return
        try:
            saved=self._save_snapshot()
            png=saved.read_bytes()
        except OSError as exc:
            QMessageBox.warning(self,'MINEVORA • Skin',str(exc))
            return
        self.skin_use_button.setEnabled(False)
        self.skin_use_button.setText('⏳ Wysyłanie skina…')
        self.skin_upload_worker=SkinUploadWorker(png,str(session['access_token']),variant,self)
        self.skin_upload_worker.success.connect(self.skin_upload_success)
        self.skin_upload_worker.failed.connect(self.skin_upload_failed)
        self.skin_upload_worker.finished.connect(self.skin_upload_finished)
        self.skin_upload_worker.start()

    def skin_upload_success(self):
        QMessageBox.information(self,'MINEVORA • Sukces',
             'Skin został ustawiony na zalogowanym koncie Minecraft Java Edition.\n'
             'Jeżeli gra jest już uruchomiona, zmiana może wymagać ponownego uruchomienia gry.')

    def skin_upload_failed(self,message):
        QMessageBox.warning(self,'MINEVORA • Nie udało się ustawić skina',
              message+'\n\nKopia PNG jest zapisana lokalnie. '
              'Możesz wczytać ją w oficjalnym Minecraft Launcher → Java Edition → Skins.')

    def skin_upload_finished(self):
        self.skin_use_button.setEnabled(True)
        self.skin_use_button.setText('✓ UŻYJ SKINA W MINECRAFT')
        # Wait for worker lifecycle to finish before dropping our reference.
        self.skin_upload_worker=None
        self.refresh_account_status()

    def closeEvent(self,event):
        if self.skin_upload_worker and self.skin_upload_worker.isRunning():
            QMessageBox.information(self,'MINEVORA • Wysyłanie',
                                   'Trwa zmiana skina na koncie Minecraft. Poczekaj na zakończenie.')
            event.ignore()
            return
        if self.has_changes:
            result=QMessageBox.question(self,'MINEVORA • Skin Creator',
                 'Skin nie został zapisany. Zamknąć edytor bez eksportu?',
                 QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
            if result!=QMessageBox.Yes:
                event.ignore()
                return
        super().closeEvent(event)
