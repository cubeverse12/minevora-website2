"""Player profile view model for locally entered Fair Play moderation reports.

It intentionally does NOT infer alternate accounts, fetch third-party bans, or assign
any cheating score. The report sources are shown to moderators as recorded.
"""
from minevora_fairplay_core import summary


def profile_snapshot(player):
    """Prepare the local moderation history for presentation, without inventing facts."""
    records = [r for r in player.get('records', []) if isinstance(r, dict)]
    groups = {
        'ban': [r for r in records if r.get('kind') == 'ban'],
        'linked': [r for r in records if r.get('kind') == 'linked'],
        'alert': [r for r in records if r.get('kind') == 'alert'],
    }
    verified_locally = [r for r in groups['linked'] if r.get('status') == 'sprawdzone lokalnie']
    reported = [r for r in groups['linked'] if r.get('status') == 'zgłoszone']
    return {
        'name': str(player.get('name', '')),
        'uuid': str(player.get('uuid', '')),
        'stats': summary(player),
        'groups': groups,
        'links_reported': len(reported),
        'links_checked_locally': len(verified_locally),
        'ban_servers': sorted({r.get('server', '').strip() for r in groups['ban'] if r.get('server', '').strip()},key=str.casefold),
    }
