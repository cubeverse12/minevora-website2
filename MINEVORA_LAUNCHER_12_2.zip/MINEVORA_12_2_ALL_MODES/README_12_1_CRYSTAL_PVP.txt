MINEVORA LAUNCHER 12.1 — CRYSTAL PVP (wersja testowa)

NOWE: dwa osobne kafelki Crystal PvP w zakładce MINIGRY i osobne opcje w zakładce PvP.

Ważne: wybór nie wysyła automatycznie polecenia do serwera. Po dołączeniu do właściwej instancji Paper wpisz:
  /mm join crystal_1v1
  /mm join crystal_ffa

Serwer wymaga MinevoraMinigames 0.2.0 i skonfigurowanych aren.

Pozostałe funkcje launchera pochodzą z MINEVORA 12.0. Ta aktualizacja nie zmienia systemu logowania, pobierania modów ani automatycznie nie publikuje serwera.
