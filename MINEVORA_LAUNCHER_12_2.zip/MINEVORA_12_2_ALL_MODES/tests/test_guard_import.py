import json
import tempfile
import unittest
from pathlib import Path
from minevora_guard_import import SOURCE, import_guard_log
from minevora_fairplay_core import empty_data, save_data, load_data


def event(**changes):
    d = {'schema': 'minevora.guard.v1', 'event_id': 'event1', 'timestamp': '2026-10-19T10:00:00Z',
         'server': 'MINEVORA Official', 'player_uuid': '123e4567-e89b-12d3-a456-426614174000',
         'player_name': 'TestMinecraft', 'check': 'SPEED', 'evidence': 'speed=2.4b/t',
         'classification': 'UNVERIFIED_SIGNAL'}
    d.update(changes)
    return d


class GuardImportTests(unittest.TestCase):
    def test_import_duplicate_reload(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'data.jsonl'
            path.write_text('\n'.join([json.dumps(event()), json.dumps(event()), json.dumps(event(event_id='event2', check='REACH'))]), encoding='utf-8')
            database = empty_data()
            stats = import_guard_log(database, path)
            self.assertEqual((stats['imported'], stats['duplicate'], stats['created_players']), (2, 1, 1))
            self.assertEqual(len(database['players'][0]['records']), 2)
            save_data(database, Path(temp) / 'state.json')
            loaded = load_data(Path(temp) / 'state.json')
            self.assertEqual(loaded['players'][0]['records'][0]['source'], SOURCE)
            stats2 = import_guard_log(loaded, path)
            self.assertEqual(stats2['imported'], 0)
            self.assertEqual(stats2['duplicate'], 3)

    def test_different_uuid_same_name_is_not_merged(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'data.jsonl'
            path.write_text('\n'.join([json.dumps(event()), json.dumps(event(event_id='event3', player_uuid='123e4567-e89b-12d3-a456-426614174111'))]), encoding='utf-8')
            database = empty_data()
            stats = import_guard_log(database, path)
            self.assertEqual(stats['imported'], 1)
            self.assertEqual(stats['ignored'], 1)

    def test_non_guard_file_ignored(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'data.jsonl'
            path.write_text('{"hello":true}\nnot JSON\n', encoding='utf-8')
            database = empty_data()
            stats = import_guard_log(database, path)
            self.assertEqual(stats['imported'], 0)
            self.assertEqual(stats['ignored'], 2)

    def test_file_too_big(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'data.jsonl'
            path.write_bytes(b' ' * 5_000_001)
            with self.assertRaises(ValueError):import_guard_log(empty_data(), path)

if __name__ == '__main__': unittest.main()
