"""Run with: python -m unittest discover -s tests -p test_discord_core.py"""
import unittest
from minevora_discord_core import valid_application_id, normalize_invite, presence_payload, should_publish


class DiscordCoreTest(unittest.TestCase):
    def test_application_id(self):
        self.assertTrue(valid_application_id('123456789012345678'))
        self.assertFalse(valid_application_id('user@example.com'))
        self.assertFalse(valid_application_id('123'))
        self.assertFalse(valid_application_id('１２３４５６７８９０１２３４５６７８'))

    def test_invites(self):
        self.assertEqual(normalize_invite('discord.gg/Example123'), 'https://discord.gg/Example123')
        self.assertEqual(normalize_invite('https://discord.com/invite/aBc-3'), 'https://discord.gg/aBc-3')
        self.assertEqual(normalize_invite(''), '')
        for malicious in ('https://discord.gg.evil.test/abc', 'http://discord.gg/abc',
                          'https://discord.gg@evil.test/abc', 'https://discord.com/channels/1',
                          'https://discord.gg/abc def', 'https://discord.gg:443/abc'):
            with self.subTest(malicious=malicious):
                with self.assertRaises(ValueError):
                    normalize_invite(malicious)

    def test_game_privacy_and_timestamps(self):
        self.assertEqual(presence_payload({}, False)['details'], 'Przegląda launcher MINEVORA')
        self.assertNotIn('start', presence_payload({}, False, None, None))
        prefs={'discord_show_version':True}
        state=presence_payload(prefs, True, '1.21.4', 1729000000)
        self.assertEqual(state['details'], 'Gra w Minecraft Java')
        self.assertEqual(state['state'], 'Minecraft 1.21.4')
        self.assertEqual(state['start'], 1729000000)
        self.assertNotIn('127.0.0.1', str(state))
        self.assertEqual(presence_payload(prefs, True, '1.21.4 \n IP:1.2.3.4')['state'], 'MINEVORA')
        self.assertEqual(presence_payload({'discord_show_version':False}, True, '1.21.4')['state'], 'MINEVORA')

    def test_game_only_mode(self):
        prefs={'discord_enabled':True,'discord_app_id':'123456789012345678','discord_only_in_game':True}
        self.assertTrue(should_publish(prefs, True))
        self.assertFalse(should_publish(prefs, False))
        prefs['discord_only_in_game']=False
        self.assertTrue(should_publish(prefs, False))
        prefs['discord_enabled']=False
        self.assertFalse(should_publish(prefs, True))


if __name__ == '__main__':
    unittest.main()
