import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from minevora_mod_updates import (
    MAX_MOD_BYTES, ModUpdateError, file_hash, is_safe_filename,
    jar_files, parse_candidates, query_updates, scan_updates, install_update,
    download_verified,
)
from minevora_i18n import translate
from DISCORD_SETUP.discord_languages import CATEGORY_EN, CHANNELS_EN


class Response(io.BytesIO):
    def __init__(self, blob, url='https://cdn.modrinth.com/data/a/b/mod-new.jar'):
        super().__init__(blob)
        self.url = url
    def geturl(self):
        return self.url
    def __enter__(self):
        return self
    def __exit__(self, *_):
        self.close()

class ModTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.mods = self.root / 'mods'
        self.mods.mkdir()
        self.old = self.mods / 'old.jar'
        self.old.write_bytes(b'old jar content')
        self.h = file_hash(self.old)
        self.payload = b'new jar content'
        self.nh = hashlib.sha512(self.payload).hexdigest()
        self.url = 'https://cdn.modrinth.com/data/a/b/mod-new.jar'
        self.item = {
            'path': str(self.old), 'old_sha512': self.h,
            'filename': 'mod-new.jar', 'url': self.url,
            'sha512': self.nh, 'size': len(self.payload),
            'name': 'New mod', 'version': '1.1', 'dependencies': []
        }
    def tearDown(self):
        self.tmp.cleanup()
    def test_file_scan_jar_only(self):
        (self.mods / 'skip.txt').write_text('no')
        self.assertEqual(jar_files(self.root), [self.old])
    def test_filename_safety(self):
        self.assertFalse(is_safe_filename('../../hack.jar'))
        self.assertFalse(is_safe_filename('other.jar.exe'))
        self.assertTrue(is_safe_filename('mod-1.21+new.jar'))
    def test_query_matching_version_and_loader(self):
        def opener(req, timeout=None):
            body = json.loads(req.data)
            self.assertEqual(body['loaders'], ['fabric'])
            self.assertEqual(body['game_versions'], ['1.21.1'])
            return Response(json.dumps({self.h: 'ok'}).encode())
        self.assertEqual(query_updates([self.h], '1.21.1', 'fabric', opener), {self.h:'ok'})
    def test_reject_invalid_loader(self):
        with self.assertRaises(ModUpdateError):
            query_updates([self.h], '1.21.1', 'unknown')
    def test_candidates_match_sha_and_release(self):
        item = dict(self.item)
        version = {'name':'New mod', 'version_number':'1.1', 'project_id':'xyz',
                   'game_versions':['1.21.1'],'loaders':['fabric'],
                   'files':[{'primary':True,'filename':item['filename'], 'url':item['url'],
                             'size':item['size'],'hashes':{'sha512':item['sha512']}}]}
        found = parse_candidates([self.old], {self.h:version}, {self.old:self.h}, '1.21.1','fabric')
        self.assertEqual(len(found),1)
        self.assertEqual(found[0]['sha512'],self.nh)
        self.assertEqual(parse_candidates([self.old], {self.h:version}, {self.old:self.h}, '1.20.1','fabric'),[])
    def test_update_and_backup(self):
        backup=install_update(self.item, self.root, backup_root=self.root/'backup',
                              opener=lambda req, timeout=None:Response(self.payload))
        self.assertEqual((self.mods/'mod-new.jar').read_bytes(),self.payload)
        self.assertFalse(self.old.exists())
        self.assertEqual(Path(backup).read_bytes(),b'old jar content')
    def test_hash_mismatch_rolls_back(self):
        with self.assertRaises(ModUpdateError):
            install_update(self.item,self.root,backup_root=self.root/'backup',
                           opener=lambda req,timeout=None:Response(b'corrupted'))
        self.assertEqual(self.old.read_bytes(),b'old jar content')
    def test_wrong_download_host_rejected(self):
        candidate=dict(self.item, url='https://other.invalid/file.jar')
        with self.assertRaises(ModUpdateError):
            download_verified(candidate,self.mods)
    def test_prevent_filename_collision(self):
        (self.mods/'mod-new.jar').write_bytes(b'existing')
        with self.assertRaises(ModUpdateError):
            install_update(self.item,self.root,backup_root=self.root/'backup')
        self.assertEqual(self.old.read_bytes(),b'old jar content')
    def test_localization_switch(self):
        self.assertEqual(translate('🏠  Strona główna','en'),'🏠  Home')
        self.assertEqual(translate('🏠  Strona główna','pl'),'🏠  Strona główna')
    def test_discord_mapping_count(self):
        self.assertEqual(len(CATEGORY_EN),6)
        self.assertEqual(sum(map(len, CHANNELS_EN)),27)

if __name__=='__main__':
    unittest.main()
