"""Pure policy, malformed profile and integration smoke tests for 10.9."""
import ast
import importlib.util
import json
import pathlib
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from minevora_visuals import animation_interval_ms, valid_motion_mode, should_animate, ease_out_cubic
from minevora_easy_core import sanitize_preferences


class MotionTests(unittest.TestCase):
    def test_modes_have_different_intervals(self):
        self.assertEqual(animation_interval_ms('smooth'),50)
        self.assertEqual(animation_interval_ms('eco'),125)
        self.assertEqual(animation_interval_ms('off'),0)
    def test_off_or_hidden_stops_refresh(self):
        for value in (('off', True, False, False),('smooth',False,False,False),('smooth',True,True,False)):
            mode, visible, minimized, expected=value
            self.assertEqual(should_animate(True,visible,minimized,mode),expected)
        self.assertFalse(should_animate(False,True,False,'smooth'))
        self.assertTrue(should_animate(True,True,False,'smooth'))
    def test_corrupted_settings_fallback(self):
        for invalid in (None,{'bad':1},['smooth'],123,'blazing',''):
            self.assertEqual(valid_motion_mode(invalid),'smooth')
            self.assertEqual(animation_interval_ms(invalid),50)
    def test_sanitize_prefs(self):
        self.assertEqual(sanitize_preferences({'motion_mode':'eco'})['motion_mode'],'eco')
        self.assertEqual(sanitize_preferences({'motion_mode':'bad'})['motion_mode'],'smooth')
    def test_easing(self):
        self.assertEqual(ease_out_cubic(-3),0)
        self.assertEqual(ease_out_cubic(0),0)
        self.assertEqual(ease_out_cubic(1),1)
        self.assertEqual(ease_out_cubic(3),1)
        self.assertGreater(ease_out_cubic(.5),.5)
    def test_runtime_ui_entry_points_are_present(self):
        tree=ast.parse((ROOT/'minevora_qt.py').read_text(encoding='utf-8'))
        window=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Window')
        hero=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='LandscapeHero')
        w={n.name for n in window.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        h={n.name for n in hero.body if isinstance(n,ast.FunctionDef)}
        for name in ('animate_page_transition','finish_page_transition','changeEvent','apply_prefs','refresh','closeEvent'):
            self.assertIn(name,w)
        for name in ('_build_backdrop','showEvent','hideEvent','refresh_animation_state','set_motion_mode'):
            self.assertIn(name,h)


class ProfilePersistenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Import profiles without Qt; its MC_DIR import is not used by persistence.
        engine=types.ModuleType('minevora_engine')
        engine.MC_DIR=pathlib.Path(tempfile.gettempdir())/'.minecraft_test_only'
        cls.engine=engine
        with patch.dict(sys.modules,{'minevora_engine':engine}):
            spec=importlib.util.spec_from_file_location('_minevora_profiles_test',ROOT/'minevora_profiles.py')
            cls.profiles=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(cls.profiles)

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        folder=pathlib.Path(self.tmp.name)
        self.profiles.STORE=folder/'profiles.json'
        self.profiles.ROOT=folder/'instances'

    def test_malformed_entries_do_not_crash_launcher(self):
        path=self.profiles.STORE
        entries=[None,[],{'name':'test'}, {'id':'id','name':'ok','version':'1.21.4','game_dir':'/tmp/foo'},
                 {'id':'id','name':1,'version':'1.21.4','game_dir':'/tmp/foo'}, 'raw']
        path.write_text(json.dumps(entries),encoding='utf-8')
        valid=self.profiles.load()
        self.assertEqual(len(valid),1)
        self.assertEqual(valid[0]['name'],'ok')
        self.assertEqual(json.loads(path.read_text()),entries)  # untouched original

    def test_corrupted_json(self):
        self.profiles.STORE.write_text('{broken',encoding='utf-8')
        self.assertEqual(self.profiles.load(),[])

    def test_atomic_profile_creation(self):
        created=self.profiles.create('WorldOne','1.21.4')
        self.assertEqual(self.profiles.load()[0]['id'],created['id'])
        self.assertTrue(self.profiles.ROOT.joinpath(created['id']).is_dir())
        self.assertFalse(self.profiles.STORE.with_suffix('.tmp').exists())

if __name__=='__main__':unittest.main()
