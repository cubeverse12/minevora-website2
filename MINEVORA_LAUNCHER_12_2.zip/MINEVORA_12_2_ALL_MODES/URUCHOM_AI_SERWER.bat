@echo off
cd /d "%~dp0"
py MINEVORA_AI_LOCAL_SERVER.py
pause
