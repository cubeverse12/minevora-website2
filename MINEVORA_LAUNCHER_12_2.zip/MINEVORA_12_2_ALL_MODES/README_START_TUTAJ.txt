MINEVORA 11.7 — UŻYJ SKINA W MINECRAFT

Nowy przycisk w Skin Studio wysyła skin na zalogowane konto Java Edition.
Szczegóły w README_11_7_SKIN_W_MINECRAFT.txt.

MINEVORA 11.6 — Skin Creator Edition
Uruchom URUCHOM_MINEVORA.bat; w programie otwórz zakładkę Skiny.

MINEVORA 11.5 — Premium Skin Studio

MINEVORA 10.9 — COMPLETE EDITION
===============================

AKTUALIZACJA DLA MINEVORA 10.7

NOWOŚCI
1. Profile graczy / Fair Play:
   - Przycisk „Profil gracza” w górnym pasku oraz skrót na stronie głównej.
   - Lokalna kolejka nierozpatrzonych sygnałów antycheat i zgłoszeń powiązanych kont.
   - Wyszukiwanie profili, filtr „tylko wymagające uwagi”.
   - Zmiana statusu raportu bez konieczności usuwania historii.
   - Historia decyzji moderatora z datą i opcjonalną krótką notatką.
   - Wciąż można usuwać pojedyncze raporty i lokalny profil po potwierdzeniu.
2. MINEVORA Guard:
   - Generowanie config.yml: profil ostrożny albo standardowy.
   - Sprawdzanie zgodności progów z istniejącym pluginem Guard 1.0.
   - Raporty nadal są sygnałami wymagającymi weryfikacji, brak automatycznych banów.
   - Istniejący MINEVORAGuard.jar pochodzi z poprzedniej wersji; pluginu NIE przebudowywano w tej aktualizacji.
3. Interfejs:
   - Wyróżniony skrót do Fair Play z licznikiem nierozpatrzonych zgłoszeń.
   - Nowe skróty: Fair Play i Kopia danych na stronie głównej.
   - Czytelniejsze stany focus/disabled przycisków i podpowiedzi.
   - Dodatkowe testy plików graficznych i skryptów w diagnostyce.

INSTALACJA
1. Zamknij MINEVORA, grę oraz serwer czatu.
2. Jeśli masz ważne dane: utwórz kopię %USERPROFILE%\.minevora
   (najlepiej przez narzędzie „Kopia danych” w starej MINEVORA).
3. Rozpakuj paczkę do NOWEGO folderu — nie nadpisuj ręcznie starych plików przy uruchomionym launcherze.
4. Uruchom INSTALUJ_ZALEZNOSCI.bat, następnie URUCHOM_MINEVORA.bat.
5. Kliknij w górnym pasku „Profil gracza”, wybierz nick i otwórz profil.
6. Kliknij „Guard: ustawienia”, aby wygenerować config.yml. Przed zastosowaniem zrób kopię konfiguracji serwera Paper.
7. Jeśli program nie startuje: SPRAWDZ_LAUNCHER.bat.

DANE I ZASADY
- Dotychczasowe dane lokalne w %USERPROFILE%\.minevora pozostają na miejscu.
- Żaden nick, ban ani sygnał nie jest automatycznie potwierdzany w innych serwerach.
- Informacje z raportów są lokalne, wprowadzone ręcznie lub zaimportowane.
- Nie ma procentowego „prawdopodobieństwa cheatów”, skanowania IP ani automatycznych banów.
- Oficjalne logowanie Microsoft wymaga sprawdzenia na komputerze użytkownika.
- Marketplace, MVC i rangi pozostają lokalnymi funkcjami demonstracyjnymi.
- Serwer Paper i launcher nie są automatycznie połączone przez internet.

WERYFIKACJA
- Wszystkie pliki Python przeszły kontrolę składni.
- 71 testów automatycznych unittest przeszło.
- Kontrola archiwum ZIP przeszła.
- Środowisko nie ma PySide6 ani Windows — GUI i logowanie Microsoft nie były testowane na żywo.
