@echo off
cd /d "%~dp0"
title MINEVORA 12.0 - THE ENCHANTED LAUNCHER
python minevora_start.py
if errorlevel 1 (
 echo.
 echo Nie udalo sie uruchomic. Uruchom INSTALUJ_ZALEZNOSCI.bat.
 pause
)
