"""Upload a Minecraft Java Edition skin to the logged-in player's Mojang profile.

Uses only the Minecraft Services HTTPS endpoint. Access tokens are passed in memory,
never written or logged. The upload is always initiated by an explicit user click.
"""
from __future__ import annotations

import struct
import urllib.error
import urllib.request
import uuid

SKIN_API_URL = 'https://api.minecraftservices.com/minecraft/profile/skins'
PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
MAX_PNG_BYTES = 1024 * 1024


class SkinUploadError(Exception):
    """An error safe to display to a player without exposing credentials."""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Do not forward Minecraft bearer tokens to redirect destinations."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def validate_skin_png(png: bytes) -> tuple[int, int]:
    if not isinstance(png, bytes) or not (45 <= len(png) <= MAX_PNG_BYTES):
        raise SkinUploadError('Plik skina jest pusty lub zbyt duży (limit 1 MB).')
    if not png.startswith(PNG_SIGNATURE) or png[12:16] != b'IHDR':
        raise SkinUploadError('Wymagany prawidłowy plik PNG skina Minecraft.')
    if struct.unpack('>I', png[8:12])[0] != 13:
        raise SkinUploadError('Nieprawidłowy nagłówek pliku PNG.')
    width, height = struct.unpack('>II', png[16:24])
    if (width, height) not in {(64, 64), (64, 32)}:
        raise SkinUploadError('Skin musi mieć 64×64 lub 64×32 piksele.')
    if b'IDAT' not in png or b'IEND' not in png:
        raise SkinUploadError('Plik PNG wygląda na uszkodzony.')
    return width, height


def build_multipart(png: bytes, variant: str, boundary: str) -> bytes:
    if variant not in ('classic', 'slim'):
        raise SkinUploadError('Nieprawidłowy typ modelu. Wybierz Classic albo Slim.')
    if not boundary.isascii() or not boundary.isalnum():
        raise SkinUploadError('Nieprawidłowa granica formularza.')
    marker = boundary.encode('ascii')
    return (
        b'--' + marker + b'\r\n'
        b'Content-Disposition: form-data; name="variant"\r\n\r\n' + variant.encode('ascii') + b'\r\n'
        b'--' + marker + b'\r\n'
        b'Content-Disposition: form-data; name="file"; filename="minevora_skin.png"\r\n'
        b'Content-Type: image/png\r\n\r\n' + png + b'\r\n'
        b'--' + marker + b'--\r\n'
    )


def friendly_status_error(code: int) -> str:
    return {
        400: 'Serwer Minecraft odrzucił plik skina. Sprawdź format PNG oraz wariant modelu.',
        401: 'Sesja konta Minecraft wygasła. Zaloguj się ponownie do konta Microsoft w MINEVORA.',
        403: 'To konto nie ma uprawnień do zmiany skina Minecraft Java Edition. Sprawdź, czy posiadasz grę.',
        404: 'Nie odnaleziono profilu Minecraft Java Edition dla tego konta.',
        413: 'Plik skina jest zbyt duży.',
        429: 'Zbyt wiele zmian skina. Odczekaj chwilę przed kolejną próbą.',
    }.get(code, 'Usługa Minecraft jest chwilowo niedostępna lub zwróciła błąd HTTP '+str(code)+'.')


def upload_skin(png: bytes, access_token: str, variant: str='classic', *, urlopen=None) -> None:
    """Upload skin bytes on behalf of a logged in Java player, no token persistence.

    Dependency injection for urlopen permits offline tests. Never put token data
    in raised exception messages or diagnostic logs.
    """
    validate_skin_png(png)
    if not isinstance(access_token, str) or not access_token.strip():
        raise SkinUploadError('Najpierw zaloguj się na konto Microsoft w MINEVORA.')
    if variant not in ('classic', 'slim'):
        raise SkinUploadError('Wybierz model Classic albo Slim.')
    boundary = 'Minevora' + uuid.uuid4().hex
    payload = build_multipart(png, variant, boundary)
    request = urllib.request.Request(
        SKIN_API_URL,
        data=payload,
        headers={
            'Authorization': 'Bearer '+access_token.strip(),
            'Content-Type': 'multipart/form-data; boundary='+boundary,
            'Accept': 'application/json',
            'User-Agent': 'MINEVORA-SkinStudio/11.7',
        },
        method='POST',
    )
    opener = urlopen or urllib.request.build_opener(_NoRedirect()).open
    try:
        with opener(request, timeout=30) as response:
            status = response.getcode()
            if status not in (200, 201, 204):
                raise SkinUploadError(friendly_status_error(status))
    except urllib.error.HTTPError as error:
        raise SkinUploadError(friendly_status_error(error.code)) from None
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
        raise SkinUploadError('Błąd połączenia z serwerami Minecraft. Sprawdź internet i spróbuj ponownie.') from None
