MINEVORA 9.7 — DISCORD SPOŁECZNOŚCI
===================================

NOWOŚĆ
- Przyciski „DOŁĄCZ DO NASZEGO DISCORDA” i „Kopiuj link” w zakładce Discord.
- Adres otrzymany od twórcy: https://discord.gg/8teEpYvzRd
- Stały przycisk do społeczności niezależny od Discord Rich Presence i Application ID.
- Możliwość zapisania innego serwera w dodatkowym polu (opcjonalna).
- Zachowano MINEVORA 9.6 oraz pozostałe moduły launchera.

JAK URUCHOMIĆ
1. Rozpakuj całe ZIP do NOWEGO katalogu.
2. Kliknij INSTALUJ_ZALEZNOSCI.bat, jeżeli biblioteki nie są zainstalowane.
3. Kliknij URUCHOM_MINEVORA.bat.
4. W menu wybierz Discord.
5. Kliknij „DOŁĄCZ DO NASZEGO DISCORDA”. Zostaniesz przeniesiony do przeglądarki / aplikacji Discord.

Ważne: nie potrzebujesz Application ID, by otworzyć zaproszenie. Application ID jest używany tylko dla Rich Presence.
Dostępność i ważność zaproszenia zależy od ustawień serwera Discord.
Nie zweryfikowano połączenia na Windows; przeprowadzono kontrole składni, archiwum i stałego adresu.
