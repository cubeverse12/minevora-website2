"""Modrinth mod-update UI; operations on QThreads, never block the GUI."""
import re
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QLineEdit, QPushButton, QListWidget, QListWidgetItem, QCheckBox, QMessageBox, QInputDialog)

from minevora_mod_updates import scan_updates, run_updates
from minevora_modpack_core import create_pack, list_packs, check_pack, PackError

WORDS = {
 'pl': {
  'title': 'MINEVORA • Aktualizacje modów', 'head':'🔄  AKTUALIZACJE MODÓW (MODRINTH)',
  'info':'Aktualizacje wyłącznie w utworzonej paczce MINEVORA; folder .minecraft/mods pozostaje bez zmian.',
  'version':'Wersja Minecraft (np. 1.21.1)', 'check':'Sprawdź aktualizacje',
  'apply':'Zaktualizuj zaznaczone', 'auto':'Aktualizuj tylko wybraną paczkę (bez aktualizacji w tle)',
  'starting':'Wybierz paczkę lub utwórz nową. Pliki .jar dodaj do folderu mods wybranej paczki.',
  'scanning':'Sprawdzanie plików .jar i Modrinth…', 'working':'Instalowanie aktualizacji…',
  'found':'Modów w folderze: {total} • aktualizacji: {count}',
  'none':'Nie znaleziono aktualizacji (nieobsługiwane pliki są pomijane).',
  'error':'Błąd: {error}', 'confirm':'Zainstalować {count} aktualizacji?\nPrzed wymianą zostaną utworzone kopie .jar.',
  'complete':'Zaktualizowano: {ok}. Błędy: {errors}.\nKopie: ~/.minevora/mod_backups.\nSprawdź zależności modów przed grą.',
  'running':'Zamknij Minecraft przed aktualizacją modów.',
  'selected':'Zaznacz aktualizacje na liście.', 'dependencies':'Wymagane zależności: {count} (sprawdź ręcznie)',
 },
 'en': {
  'title':'MINEVORA • Mod updates', 'head':'🔄  MOD UPDATES (MODRINTH)',
  'info':'Updates only inside a registered MINEVORA modpack; global .minecraft/mods stays unchanged.',
  'version':'Minecraft version (e.g. 1.21.1)', 'check':'Check updates',
  'apply':'Update selected', 'auto':'Update selected pack only (no background updates)',
  'starting':'Choose or create a modpack. Put .jar mods into its mods folder.',
  'scanning':'Checking .jar files and Modrinth…', 'working':'Installing updates…',
  'found':'Mods in folder: {total} • updates: {count}',
  'none':'No updates found (unrecognized files are skipped).',
  'error':'Error: {error}', 'confirm':'Install {count} updates?\nA backup of each .jar will be made first.',
  'complete':'Updated: {ok}. Errors: {errors}.\nBackups: ~/.minevora/mod_backups.\nCheck mod dependencies before playing.',
  'running':'Close Minecraft before updating mods.',
  'selected':'Select updates from the list.', 'dependencies':'Required dependencies: {count} (check manually)',
 }
}

class UpdateWorker(QThread):
    done = Signal(object)
    error = Signal(str)
    progress = Signal(str)
    def __init__(self, action, **kwargs):
        super().__init__()
        self.action, self.kwargs = action, kwargs
    def run(self):
        try:
            if self.action == 'scan':
                result = scan_updates(self.kwargs['mc_dir'], self.kwargs['version'], self.kwargs['loader'])
            else:
                result = run_updates(self.kwargs['candidates'], self.kwargs['mc_dir'], progress=self.progress.emit)
            self.done.emit(result)
        except Exception as exc:
            self.error.emit(str(exc))

class ModUpdatesDialog(QDialog):
    def __init__(self, mc_dir, selected_version='', language='pl', prefs=None, save_pref=None, game_running=None, parent=None):
        super().__init__(parent)
        self.mc_dir = Path(mc_dir)
        self.tr = WORDS.get(language, WORDS['pl'])
        self.prefs = prefs or {}
        self.save_pref = save_pref
        self.game_running = game_running or (lambda: False)
        self.candidates = []
        self.worker = None
        self.setWindowTitle(self.tr['title'])
        self.resize(750, 540)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(self.tr['head']))
        info = QLabel(self.tr['info']); info.setWordWrap(True); layout.addWidget(info)
        pack_row=QHBoxLayout()
        self.pack=QComboBox()
        self.pack.setToolTip('Aktualizacje działają tylko wewnątrz paczek z manifestem MINEVORA.')
        pack_row.addWidget(self.pack,1)
        create_button=QPushButton('＋ Utwórz paczkę')
        create_button.clicked.connect(self.new_pack)
        pack_row.addWidget(create_button)
        layout.addLayout(pack_row)
        self.version=QLineEdit();self.version.setReadOnly(True)
        self.loader=QComboBox();self.loader.addItem('— loader —','')
        for x in ('fabric','forge','neoforge','quilt'):self.loader.addItem(x,x)
        self.loader.setEnabled(False)
        row=QHBoxLayout();row.addWidget(self.version,2);row.addWidget(self.loader,1)
        self.check=QPushButton(self.tr['check']);self.check.clicked.connect(self.start_scan)
        row.addWidget(self.check);layout.addLayout(row)
        self.pack.currentIndexChanged.connect(self.pack_changed)
        self.list = QListWidget()
        layout.addWidget(self.list, 1)
        self.status = QLabel(self.tr['starting'])
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.apply_button = QPushButton(self.tr['apply'])
        self.apply_button.clicked.connect(self.start_apply)
        self.apply_button.setEnabled(False)
        layout.addWidget(self.apply_button)
        self.load_packs()

    def load_packs(self, selected=None):
        self.pack.blockSignals(True)
        self.pack.clear();self.pack.addItem('— Wybierz paczkę —',None)
        for folder,info in list_packs():
            self.pack.addItem(info['name']+' • '+info['minecraft_version']+' / '+info['loader'],str(folder))
        for i in range(self.pack.count()):
            if self.pack.itemData(i)==selected:self.pack.setCurrentIndex(i);break
        self.pack.blockSignals(False)
        self.pack_changed()

    def pack_changed(self,*_):
        chosen=self.pack.currentData()
        self.candidates=[]
        self.list.clear()
        if chosen:
            try:info=check_pack(chosen)
            except (ValueError,OSError) as exc:
                self.status.setText(str(exc));self.check.setEnabled(False);return
            self.version.setText(info['minecraft_version'])
            self.loader.setCurrentText(info['loader'])
        else:
            self.version.clear();self.loader.setCurrentIndex(0)
        self.check.setEnabled(bool(chosen))
        self.apply_button.setEnabled(False) if hasattr(self,'apply_button') else None

    def new_pack(self):
        name,ok=QInputDialog.getText(self,'Nowa paczka','Nazwa paczki:')
        if not ok:return
        version,ok=QInputDialog.getText(self,'Nowa paczka','Wersja Minecraft (np. 1.21.1):')
        if not ok:return
        loader,ok=QInputDialog.getItem(self,'Nowa paczka','Loader:', ['fabric','forge','neoforge','quilt'],0,False)
        if not ok:return
        try:folder=create_pack(name,version,loader)
        except (OSError,ValueError) as exc:
            QMessageBox.warning(self,'Paczka modów',str(exc));return
        self.load_packs(str(folder))
        QMessageBox.information(self,'Paczka modów','Utworzono paczkę. Skopiuj swoje pliki .jar do folderu:\n'+str(folder/'mods'))

    def busy(self, working):
        self.check.setEnabled(not working and bool(self.pack.currentData()))
        self.apply_button.setEnabled(not working and bool(self.candidates))
        self.pack.setEnabled(not working)

    def start_scan(self):
        if self.worker and self.worker.isRunning():
            return
        if self.game_running():
            QMessageBox.warning(self, self.tr['title'], self.tr['running'])
            return
        try:
            chosen=self.pack.currentData()
            info=check_pack(chosen) if chosen else None
        except (ValueError,OSError,TypeError) as exc:
            QMessageBox.warning(self,'Paczka',str(exc));return
        if not info:
            QMessageBox.information(self,'Paczka','Najpierw wybierz zarejestrowaną paczkę.');return
        self.mc_dir=Path(chosen)
        self.candidates=[]
        self.list.clear()
        self.busy(True)
        self.status.setText(self.tr['scanning'])
        self.worker = UpdateWorker('scan', mc_dir=self.mc_dir, version=info['minecraft_version'], loader=info['loader'])
        self.worker.done.connect(self.scan_done)
        self.worker.error.connect(self.failed)
        self.worker.finished.connect(lambda: self.busy(False))
        self.worker.start()

    def scan_done(self, result):
        self.candidates, total = result
        self.status.setText(self.tr['found'].format(total=total, count=len(self.candidates)) if self.candidates else self.tr['none'])
        for candidate in self.candidates:
            msg = f"{Path(candidate['path']).name}  →  {candidate['filename']}  ({candidate['version']})"
            if candidate['dependencies']:
                msg += '  ⚠ ' + self.tr['dependencies'].format(count=len(candidate['dependencies']))
            item = QListWidgetItem(msg)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
            self.list.addItem(item)
        self.apply_button.setEnabled(bool(self.candidates))

    def start_apply(self, automatic=False):
        if self.worker and self.worker.isRunning():
            # The scan result can arrive slightly before its worker finishes.
            from PySide6.QtCore import QTimer
            QTimer.singleShot(180, self.start_apply)
            return
        if self.game_running():
            QMessageBox.warning(self, self.tr['title'], self.tr['running'])
            return
        selected = [candidate for i,candidate in enumerate(self.candidates)
                    if self.list.item(i).checkState() == Qt.Checked]
        if not selected:
            if not automatic: QMessageBox.information(self, self.tr['title'], self.tr['selected'])
            return
        try:check_pack(self.mc_dir)
        except (ValueError,OSError,TypeError) as exc:
            QMessageBox.warning(self,'Paczka',str(exc));return
        if QMessageBox.question(self, self.tr['title'], self.tr['confirm'].format(count=len(selected))) != QMessageBox.Yes:
            return
        self.busy(True)
        self.status.setText(self.tr['working'])
        self.worker = UpdateWorker('apply', mc_dir=self.mc_dir, candidates=selected)
        self.worker.progress.connect(self.status.setText)
        self.worker.done.connect(self.apply_done)
        self.worker.error.connect(self.failed)
        self.worker.finished.connect(lambda: self.busy(False))
        self.worker.start()

    def apply_done(self, result):
        successes, errors = result
        msg = self.tr['complete'].format(ok=len(successes), errors=len(errors))
        if errors:
            msg += '\n' + '\n'.join(f'{name}: {error}' for name,error in errors[:5])
        self.status.setText(msg)
        QMessageBox.information(self, self.tr['title'], msg)
        self.candidates = []
        self.list.clear()
        self.apply_button.setEnabled(False)

    def failed(self, msg):
        self.status.setText(self.tr['error'].format(error=msg))
        QMessageBox.warning(self, self.tr['title'], self.status.text())

    def closeEvent(self, event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore()
            self.status.setText(self.tr['working'])
        else:
            super().closeEvent(event)
