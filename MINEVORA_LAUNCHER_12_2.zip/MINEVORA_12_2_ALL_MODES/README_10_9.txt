MINEVORA 10.9 — Smooth Edition
========================================

CO SIĘ ZMIENIŁO:
• Magiczny portal i świetliki są rysowane płynniej. Góry, las i tło są buforowane: nie przeliczają się przy każdej klatce.
• Animacja zatrzymuje się po opuszczeniu strony głównej oraz przy zminimalizowanym oknie.
• Nowe ustawienie Ustawienia → Podstawowe → Płynność:
    Płynne (~20 FPS) / Oszczędne (~8 FPS) / Wyłączone.
• Krótkie (165 ms) przejścia między stronami w trybie Płynne.
• Poprawki kolorów, wyglądu przycisków, kart, pól i zakładek.
• Zmiana aktywnej pozycji menu odświeża tylko dwa przyciski, nie całe menu.
• Biblioteka Minecraft nie przebudowuje listy kart, gdy lista wersji/profili nie uległa zmianie.
• Dodatkowy lokalny dziennik wyjątków z funkcji UI: %USERPROFILE%\.minevora\ostatni_blad_runtime.txt.
• Serwis Discord Rich Presence uruchamiany dopiero chwilę po otwarciu okna.

INSTALACJA:
1. Zrób kopię folderu %USERPROFILE%\.minevora.
2. Rozpakuj ZIP do nowego katalogu, NIE nadpisuj działającej wersji.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat (jeśli brakuje bibliotek), potem URUCHOM_MINEVORA.bat.
4. Przy problemach uruchom SPRAWDZ_LAUNCHER.bat i zajrzyj do lokalnych dzienników.

UWAGA: Nie zmieniono formatu zapisywanych światów, XP, rang ani profili.
To aktualizacja UI i stabilności, nie nowe online API ani antycheat.
Testy statyczne można wykonać w środowisku bez Qt. Pełny test graficzny wymaga Windows z PySide6.

Jeśli używasz bardzo nowej wersji Python 3.15 i PySide6 nie daje się zainstalować, możesz zainstalować obok Python 3.13. Upewnij się, że instalacja zależności i uruchamianie korzystają z tej samej wersji Pythona.
