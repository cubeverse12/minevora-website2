"""Background worker: keep network transfers off the Qt GUI thread."""
from PySide6.QtCore import QThread, Signal
from minevora_skin_upload import upload_skin, SkinUploadError


class SkinUploadWorker(QThread):
    success = Signal()
    failed = Signal(str)

    def __init__(self, png: bytes, token: str, variant: str, parent=None):
        super().__init__(parent)
        self._png = png
        self._token = token
        self._variant = variant

    def run(self):
        try:
            upload_skin(self._png, self._token, self._variant)
            self.success.emit()
        except SkinUploadError as exc:
            self.failed.emit(str(exc))
        except Exception:
            # Do not print/log exceptions; some clients include authorization values.
            self.failed.emit('Nie udało się zmienić skina. Spróbuj później albo użyj pliku PNG w oficjalnym launcherze.')
        finally:
            self._token = ''
            self._png = b''
