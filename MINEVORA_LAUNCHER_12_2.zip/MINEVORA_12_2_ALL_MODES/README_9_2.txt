MINEVORA 9.2 — ANIMOWANE RANGI (WINDOWS / PySide6)

INSTALACJA
1. Rozpakuj ZIP do nowego folderu MINEVORA 9.2 (lub skopiuj do poprzedniego, nadpisując pliki).
2. Nie pomijaj folderu rank_icons ani pliku minevora_rank_animation.py.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat, następnie URUCHOM_MINEVORA.bat.

CO NOWEGO
- Automatyczna animacja awansu poziomu lub rangi po zdobyciu XP za dodanie projektu w lokalnym Marketplace.
- Wypełnianie magicznego pierścienia XP, animowane promienie i błyski, obracające się kryształy, powiększany herb rangi.
- Nowy ekran: ODBLOKOWANA RANGA z nazwą, symbolem rangi i poziomem.
- Przycisk ODBIERZ MVC (demo) wykorzystuje dotychczasowy system nagród bez podwójnego naliczania.
- W Rangi twórcy jest przycisk 'Podgląd animacji', który niczego nie dodaje do portfela ani XP.
- Możliwość wyłączenia automatycznych animacji; ustawienie jest zachowywane.
- Pomiń animację — od razu zobaczysz odblokowaną rangę.

JAK SPRAWDZIĆ
1. Otwórz Rangi twórcy -> Podgląd animacji, aby zobaczyć efekt.
2. Dodaj mapę lub budowlę w Marketplace — gdy zdobędziesz nowy poziom/rangę, animacja uruchomi się automatycznie.

UWAGI
- Animacja działa w oknie launchera, a nie jako nakładka w Minecraft.
- XP i MVC są wyłącznie lokalną demonstracją. Nie są to prawdziwe pieniądze.
- Nagrody zapisywane są w ~/.minevora/market_demo.json; zachowaj ten plik.
- Nadal wymagane są testy graficzne na Windows / PySide6.
