"""Self-contained tests: python -m unittest TESTY_RANKING -v"""
import unittest
import tempfile
import json
from pathlib import Path
from minevora_leaderboard_core import (normalize,clean_nick,clean_player,put_player,delete_player,
                                      ranked,save_local,load_local,public_snapshot,export_public)

A={'nick':'Gracz_1','xp':750,'wins':2,'losses':1,'kills':8,'deaths':2}
B={'nick':'Gracz_2','xp':200,'wins':10,'losses':6,'kills':15,'deaths':0}

class RankingTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(normalize({})['players'],[])
    def test_nick_validation(self):
        for nick in ('', 'xx', 'space nick', '<script>', 'A'*17):
            with self.assertRaises(ValueError):clean_nick(nick)
        self.assertEqual(clean_nick('Gracz_12'),'Gracz_12')
    def test_non_integer_scores(self):
        for value in (True,-1,1.1,'42'):
            with self.assertRaises(ValueError):clean_player({**A,'xp':value})
    def test_duplicates_casefold(self):
        self.assertEqual(len(normalize({'players':[A,{**A,'nick':'gRaCz_1'}]})['players']),1)
    def test_manual_update(self):
        data=put_player({'players':[]},A)
        data=put_player(data,{**A,'xp':1000})
        self.assertEqual(len(data['players']),1)
        self.assertEqual(data['players'][0]['xp'],1000)
    def test_sorted_xp_vs_pvp(self):
        data={'players':[B,A]}
        self.assertEqual(ranked(data,'xp')[0]['nick'],A['nick'])
        self.assertEqual(ranked(data,'pvp')[0]['nick'],B['nick'])
    def test_delete(self):
        self.assertEqual(delete_player({'players':[A,B]},'gracz_1')['players'],[B])
    def test_storage_roundtrip(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'ranking.json'
            save_local({'players':[A]},path)
            self.assertEqual(load_local(path)['players'],[A])
    def test_public_snapshot_private_keys(self):
        dirty={**A,'bans':['yes'],'ip':'127.0.0.1','token':'secret'}
        out=public_snapshot({'players':[dirty]})
        self.assertEqual(set(out['players'][0]),{'nick','xp','wins','losses','kills','deaths'})
        self.assertNotIn('secret',json.dumps(out))
    def test_export(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'ranking.json'
            self.assertEqual(export_public({'players':[A,B]},path),2)
            self.assertEqual(len(json.loads(path.read_text())['players']),2)

if __name__=='__main__':unittest.main()
