"""MINEVORA 8.8: katalog Modrinth w stylu fantasy; pobieranie modów z weryfikacją SHA-512."""
import json, re, urllib.parse, urllib.request
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QPushButton,
 QScrollArea,QWidget,QFrame,QMessageBox,QButtonGroup,QCheckBox,QGridLayout)
from minevora_modrinth_legacy import ModrinthWorker
from minevora_auto_dependencies_qt import AutoDependenciesWorker
from minevora_i18n import translate_widget_tree
API='https://api.modrinth.com/v2'
HEADERS={'User-Agent':'MINEVORA/8.8 (Minecraft launcher)','Accept':'application/json'}
CATEGORIES={'Mody':'mod','Modpacki':'modpack','Tekstury':'resourcepack','Shadery':'shader','Datapacki':'datapack','Pluginy':'plugin'}
COLORS='''
QDialog {background:#0b1021;color:#f2edff;font-family:'Segoe UI';font-size:13px}
QFrame#toolbar,QFrame#filterbar {background:#161c35;border:1px solid #3d3b68;border-radius:13px}
QFrame#result {background:#18213c;border:1px solid #414d76;border-radius:13px}
QFrame#result:hover {border-color:#ad90f8;background:#222b4b}
QLineEdit,QComboBox {background:#10182e;border:1px solid #53618a;border-radius:9px;padding:10px;color:white}
QPushButton {background:#303b61;border:1px solid #56618e;border-radius:9px;padding:10px;color:#f5efff;font-weight:600}
QPushButton:hover {background:#4b427c;border-color:#b8a3ff}
QPushButton#active {background:#7653b9;border:1px solid #bda6fa}
QPushButton#install {background:#8862d5;border:1px solid #bda6fa;font-weight:800}
QScrollArea {border:0;background:transparent}
QLabel#muted {color:#aab5d5}
'''
class SearchWorker(QThread):
 done=Signal(object); error=Signal(str)
 def __init__(self,query,kind,version,loader,sort):
  super().__init__();self.query=query;self.kind=kind;self.version=version;self.loader=loader;self.sort=sort
 def run(self):
  try:
   facets=[['project_type:'+self.kind]]
   if self.version:facets.append(['versions:'+self.version])
   if self.kind=='mod' and self.loader!='dowolny':facets.append(['categories:'+self.loader])
   params={'query':self.query,'limit':30,'index':self.sort,'facets':json.dumps(facets)}
   req=urllib.request.Request(API+'/search?'+urllib.parse.urlencode(params),headers=HEADERS)
   with urllib.request.urlopen(req,timeout=22) as resp:data=json.load(resp)
   self.done.emit(data)
  except Exception as exc:self.error.emit(str(exc))
class IconWorker(QThread):
 done=Signal(str,bytes)
 def __init__(self,url):super().__init__();self.url=url
 def run(self):
  try:
   if not self.url.startswith('https://'):return
   with urllib.request.urlopen(urllib.request.Request(self.url,headers=HEADERS),timeout=9) as r:
    if int(r.headers.get('Content-Length','0'))>300000:return
    data=r.read(300001)
   if len(data)<=300000:self.done.emit(self.url,data)
  except Exception:pass
class ModrinthDialog(QDialog):
 def __init__(self,mc_dir,selected_version=None,parent=None,language="pl",update_callback=None,
              auto_dependencies=True,game_running=None):
  super().__init__(parent);self.language=language;self.update_callback=update_callback;self.mc_dir=mc_dir;self.worker=None;self.deps_worker=None;self.auto_dependencies=auto_dependencies;self.game_running=game_running or (lambda: False);self.icon_workers=[];self.pending_search=False;self.hits=[];self.kind='Mody';self.selected_version=selected_version or ''
  self.setWindowTitle('MINEVORA • Odkrywaj dodatki');self.resize(1050,750);self.setMinimumSize(800,560);self.setStyleSheet(COLORS)
  root=QVBoxLayout(self);root.setContentsMargins(18,15,18,12);root.setSpacing(12)
  title=QLabel('✦  MINEVORA  /  ODKRYWAJ');title.setStyleSheet('font-size:20px;font-weight:900;color:#d3b8ff');root.addWidget(title)
  top=QFrame();top.setObjectName('toolbar');t=QHBoxLayout(top)
  self.query=QLineEdit();self.query.setPlaceholderText('Szukaj modów, modpacków, shaderów i dodatków…');self.query.returnPressed.connect(self.search);t.addWidget(self.query,5)
  self.version=QLineEdit();self.version.setPlaceholderText('Wersja MC');self.version.setMaximumWidth(120)
  match=re.search(r'\d+\.\d+(?:\.\d+)?',self.selected_version);self.version.setText(match.group() if match else '');t.addWidget(self.version)
  self.loader=QComboBox();self.loader.addItems(['dowolny','fabric','forge','neoforge','quilt']);self.loader.setMaximumWidth(120)
  for i in range(self.loader.count()):
   if self.loader.itemText(i)!='dowolny' and self.loader.itemText(i) in self.selected_version.lower():self.loader.setCurrentIndex(i);break
  t.addWidget(self.loader)
  self.loader.currentIndexChanged.connect(self.search)
  self.version.editingFinished.connect(self.search)
  go=QPushButton('⌕  Szukaj');go.clicked.connect(self.search);t.addWidget(go);self.go=go;root.addWidget(top)
  updates=QPushButton('🔄  Sprawdź aktualizacje modów')
  updates.clicked.connect(lambda checked=False: self.open_updates())
  root.addWidget(updates)
  tabs=QHBoxLayout();self.tab_buttons={}
  for label in CATEGORIES:
   b=QPushButton(label);b.clicked.connect(lambda checked=False,k=label:self.choose(k));tabs.addWidget(b);self.tab_buttons[label]=b
  root.addLayout(tabs)
  filters=QFrame();filters.setObjectName('filterbar');fr=QHBoxLayout(filters)
  fr.addWidget(QLabel('Sortowanie:'));self.sort=QComboBox();self.sort.addItem('Popularne','downloads');self.sort.addItem('Trafność','relevance');self.sort.addItem('Najnowsze','newest');self.sort.addItem('Ostatnio aktualizowane','updated');self.sort.currentIndexChanged.connect(self.search);fr.addWidget(self.sort)
  fr.addStretch();self.count=QLabel('Wybierz kategorię i wyszukaj projekty');self.count.setObjectName('muted');fr.addWidget(self.count);root.addWidget(filters)
  self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);self.holder=QWidget();self.items=QVBoxLayout(self.holder);self.items.setAlignment(Qt.AlignTop);self.items.setSpacing(10);self.scroll.setWidget(self.holder);root.addWidget(self.scroll,1)
  self.status=QLabel('Źródło: Modrinth API • Instalowanie plików obsługiwane dla modów • Pozostałe kategorie: przeglądanie');self.status.setObjectName('muted');self.status.setWordWrap(True);root.addWidget(self.status)
  self.choose('Mody',False)
  translate_widget_tree(self,self.language)
  # Display popular mods immediately, rather than an empty results panel.
  QTimer.singleShot(0,self.search)
 def open_updates(self):
  if self.update_callback:
   self.update_callback(self.version.text().strip(),self.loader.currentText())
  else:
   QMessageBox.information(self,'MINEVORA','Aktualizator modów działa z launcherem MINEVORA 10.5.')
 def choose(self,kind,refresh=True):
  self.kind=kind
  for k,b in self.tab_buttons.items():b.setObjectName('active' if k==kind else '');b.style().unpolish(b);b.style().polish(b)
  self.loader.setEnabled(kind=='Mody')
  if refresh:self.search()
 def clear(self):
  while self.items.count():
   child=self.items.takeAt(0)
   if child.widget():child.widget().deleteLater()
 def search(self):
  version=self.version.text().strip()
  if version and not re.fullmatch(r'\d+\.\d+(?:\.\d+)?',version):
   QMessageBox.warning(self,'Wersja Minecraft','Wpisz np. 1.21.1 albo zostaw pole puste.');return
  if self.worker and self.worker.isRunning():
   self.pending_search=True
   return
  self.pending_search=False
  self.go.setEnabled(False);self.status.setText('Loading projects from Modrinth…' if self.language=='en' else 'Ładowanie projektów z Modrinth…');self.clear()
  self.worker=SearchWorker(self.query.text().strip(),CATEGORIES[self.kind],version,self.loader.currentText(),self.sort.currentData())
  self.worker.done.connect(self.show_results);self.worker.error.connect(self.failed);self.worker.finished.connect(self.search_finished);self.worker.start()
 def search_finished(self):
  self.go.setEnabled(True)
  if self.pending_search:
   self.pending_search=False
   QTimer.singleShot(0,self.search)

 def show_results(self,data):
  self.hits=data.get('hits',[]);self.count.setText((f'Results: {data.get("total_hits",len(self.hits)):,}' if self.language=='en' else f'Wyników: {data.get("total_hits",len(self.hits)):,}').replace(',',' '));self.status.setText('Select a project. Direct installation is available for mods.' if self.language=='en' else 'Wybierz projekt. Instalowanie bezpośrednie dostępne dla modów.')
  if not self.hits:self.items.addWidget(QLabel('No projects found. Change version or filters.' if self.language=='en' else 'Nie znaleziono projektów. Zmień wersję lub filtry.'))
  for index,hit in enumerate(self.hits):
   frame=QFrame();frame.setObjectName('result');r=QHBoxLayout(frame);r.setContentsMargins(14,12,14,12)
   icon=QLabel('✦');icon.setAlignment(Qt.AlignCenter);icon.setFixedSize(76,76);icon.setStyleSheet('background:#343058;border-radius:12px;color:#e0caff;font-size:30px');r.addWidget(icon)
   body=QVBoxLayout();name=QLabel(hit.get('title','Project' if self.language=='en' else 'Projekt'));name.setWordWrap(True);name.setStyleSheet('font-size:15px;font-weight:800');body.addWidget(name)
   author=QLabel(('Author: ' if self.language=='en' else 'Autor: ')+hit.get('author','?')+'  •  ↓ '+str(hit.get('downloads',0))+'  •  '+', '.join(hit.get('categories',[])[:3]));author.setObjectName('muted');body.addWidget(author)
   desc=QLabel(hit.get('description','')[:220]);desc.setWordWrap(True);desc.setObjectName('muted');body.addWidget(desc);r.addLayout(body,1)
   actions=QVBoxLayout();install=QPushButton(('⬇  Install' if self.language=='en' else '⬇  Instaluj') if self.kind=='Mody' else ('↗  Open' if self.language=='en' else '↗  Otwórz'));install.setObjectName('install');install.clicked.connect(lambda checked=False,h=hit:self.action(h));actions.addWidget(install);actions.addStretch();r.addLayout(actions)
   self.items.addWidget(frame)
   url=hit.get('icon_url') or ''
   # Cap simultaneous image downloads for a responsive search view.
   if url.startswith('https://') and index<8:
    w=IconWorker(url);w.done.connect(lambda u,data,label=icon:self.set_icon(label,data));self.icon_workers.append(w);w.start()
  self.items.addStretch()
 def set_icon(self,label,data):
  if not label.isVisible():return
  p=QPixmap();
  if p.loadFromData(data):label.setPixmap(p.scaled(70,70,Qt.KeepAspectRatio,Qt.SmoothTransformation))
 def action(self,hit):
  if self.kind!='Mody':
   from PySide6.QtGui import QDesktopServices
   from PySide6.QtCore import QUrl
   project=hit.get('slug','');kind=CATEGORIES[self.kind]
   if re.fullmatch('[a-zA-Z0-9_-]+',project):QDesktopServices.openUrl(QUrl('https://modrinth.com/'+kind+'/'+project))
   return
  if self.game_running():
   QMessageBox.warning(self,'MINEVORA','Zamknij grę przed instalowaniem modów.');return
  version=self.version.text().strip()
  if not version:
   QMessageBox.information(self,'Instalowanie','Podaj wersję Minecraft, aby zainstalować zgodnego moda.');return
  if self.loader.currentText()=='dowolny':
   QMessageBox.information(self,'Instalowanie','Wybierz loader: Fabric, Forge, NeoForge albo Quilt.');return
  if QMessageBox.question(self,'Instalacja',f'Pobrać „{hit.get("title","mod")}” do folderu mods?\nMINEVORA sprawdzi wymagane zależności automatycznie, jeśli opcja jest włączona.')!=QMessageBox.Yes:return
  self.status.setText('Pobieranie i weryfikacja pliku…')
  self.install_worker=ModrinthWorker('install',project=hit['project_id'],version=version,loader=self.loader.currentText(),mc_dir=self.mc_dir)
  self.install_worker.done.connect(lambda path:self.installed(path));self.install_worker.error.connect(self.failed);self.install_worker.start()
 def installed(self,path):
  self.status.setText('Zapisano: '+Path(path).name)
  if not self.auto_dependencies:
   QMessageBox.information(self,'Pobrano','Zapisano: '+path+'\nAutomatyczna instalacja zależności jest wyłączona w ustawieniach.')
   return
  if self.deps_worker and self.deps_worker.isRunning():return
  version=self.version.text().strip();loader=self.loader.currentText()
  self.deps_worker=AutoDependenciesWorker(str(self.mc_dir),version,loader,self)
  self.deps_worker.progress.connect(self.status.setText)
  self.deps_worker.done.connect(self.dependencies_installed)
  self.deps_worker.error.connect(self.dependencies_failed)
  self.status.setText('Sprawdzam wymagane biblioteki moda…')
  self.deps_worker.start()
 def dependencies_installed(self,result):
  count=len(result.get('installed',[]))
  info=('Zainstalowano brakujące zależności: ' if self.language=='pl' else 'Installed missing dependencies: ')+str(count)
  self.status.setText(info)
  QMessageBox.information(self,'MINEVORA • Modrinth',info)
 def dependencies_failed(self,message):
  self.status.setText('Nie udało się zainstalować zależności: '+message)
  QMessageBox.warning(self,'MINEVORA • Modrinth','Mod został pobrany, ale nie udało się doinstalować jego zależności:\n'+message)
 def closeEvent(self,event):
  if (self.deps_worker and self.deps_worker.isRunning()) or (getattr(self,'install_worker',None) and self.install_worker.isRunning()):
   event.ignore()
   self.status.setText('Instalacja w toku — nie zamykaj okna.')
   return
  super().closeEvent(event)
 def failed(self,message):self.status.setText('Błąd: '+message);QMessageBox.warning(self,'Modrinth',message)
